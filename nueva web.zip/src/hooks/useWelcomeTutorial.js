import { useState, useEffect } from 'react';
import WelcomeTutorial from '@/components/onboarding/WelcomeTutorial';

/**
 * Returns [shouldShow, dismiss] — true on first launch only.
 * Reads/writes localStorage under WelcomeTutorial.STORAGE_KEY.
 */
export function useWelcomeTutorial() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    try {
      const seen = localStorage.getItem(WelcomeTutorial.STORAGE_KEY);
      if (!seen) setShow(true);
    } catch {}
  }, []);

  return [show, () => setShow(false)];
}