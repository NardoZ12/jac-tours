import { useEffect, useState } from 'react';

/**
 * Returns true when the viewport is >= the given breakpoint (default 1024px / lg).
 * SSR-safe, listens to matchMedia changes.
 */
export default function useBreakpoint(minWidth = 1024) {
  const query = `(min-width: ${minWidth}px)`;
  const [matches, setMatches] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.matchMedia(query).matches;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mql = window.matchMedia(query);
    const handler = (e) => setMatches(e.matches);
    setMatches(mql.matches);
    mql.addEventListener('change', handler);
    return () => mql.removeEventListener('change', handler);
  }, [query]);

  return matches;
}

export const useIsDesktop = () => useBreakpoint(768);