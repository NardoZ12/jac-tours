import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { RadarProvider } from '@/lib/RadarContext';

// Page imports
import Today from './pages/Today';
import Eat from './pages/Eat';
import Stay from './pages/Stay';
import HotelPage from './pages/HotelPage';
import Do from './pages/Do';
import ExperiencePage from './pages/ExperiencePage';
import Traslado from './pages/Traslado';
import Yates from './pages/Yates';
import PlacePage from './pages/PlacePage';
import Cart from './pages/Cart';
import Profile from './pages/Profile';
import PrivacyPolicy from './pages/PrivacyPolicy';
import AccessibilityStatement from './pages/AccessibilityStatement';
import Terms from './pages/Terms';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import PaypalReturn from './pages/PaypalReturn';
import ResponsiveLayout from './components/layout/ResponsiveLayout';
import ScrollToTop from './components/layout/ScrollToTop';
import { CartProvider } from '@/lib/CartContext';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={{ background: '#F8F7F4' }}>
        <div className="text-center">
          <h1 className="font-poppins font-extrabold mb-2" style={{ fontSize: '36px', color: '#141413' }}>JAC</h1>
          <div className="w-6 h-6 border-2 border-roam-border border-t-roam-text rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      {/* PayPal return (no nav bar) */}
      <Route path="/paypal/return" element={<PaypalReturn />} />

      {/* Profile (no nav bar) */}
      <Route path="/profile" element={<Profile />} />

      {/* Footer pages */}
      <Route path="/privacy-policy" element={<PrivacyPolicy />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/accessibility-statement" element={<AccessibilityStatement />} />

      {/* Main app — responsive shell (bottom nav on mobile, top nav on desktop) */}
      <Route element={<ResponsiveLayout />}>
        <Route path="/" element={<Today />} />
        <Route path="/eat" element={<Eat />} />
        <Route path="/eat/:id" element={<PlacePage />} />
        <Route path="/stay" element={<Stay />} />
        <Route path="/stay/:id" element={<HotelPage />} />
        <Route path="/favourites" element={<Cart />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/place/:id" element={<PlacePage />} />
        <Route path="/do" element={<Do />} />
        <Route path="/do/:id" element={<ExperiencePage />} />
        <Route path="/traslado" element={<Traslado />} />
        <Route path="/yates" element={<Yates />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:slug" element={<BlogPost />} />
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <RadarProvider>
        <QueryClientProvider client={queryClientInstance}>
          <CartProvider>
            <Router>
              <ScrollToTop />
              <AuthenticatedApp />
            </Router>
            <Toaster />
          </CartProvider>
        </QueryClientProvider>
      </RadarProvider>
    </AuthProvider>
  );
}

export default App;