import { useState } from 'react';
import { X, MapPin, Sparkles, StickyNote, Tag } from 'lucide-react';

const ACTIVITY_OPTIONS = [
  { value: 'dining', label: '🍽️ Dining' },
  { value: 'hiking', label: '🥾 Hiking' },
  { value: 'beach', label: '🏖️ Beach' },
  { value: 'city_tour', label: '🏛️ City Tour' },
  { value: 'museum', label: '🖼️ Museum' },
  { value: 'shopping', label: '🛍️ Shopping' },
  { value: 'nightlife', label: '🎶 Nightlife' },
  { value: 'spa', label: '💆 Spa & Wellness' },
  { value: 'adventure', label: '🪂 Adventure Sports' },
  { value: 'cooking_class', label: '👨‍🍳 Cooking Class' },
  { value: 'wine_tasting', label: '🍷 Wine Tasting' },
  { value: 'water_sports', label: '🏄 Water Sports' },
];

const EMPTY = { title: '', destination_city: '', planned_activity: '', notes: '', start_date: '', end_date: '' };

export default function NewTripDrawer({ open, onClose, onCreated }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleSubmit = async () => {
    if (!form.title || !form.destination_city) return;
    setSaving(true);
    try {
      await onCreated({ ...form, status: 'planning' });
      setForm(EMPTY);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-[29999]"
        style={{ background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(2px)' }}
        onClick={onClose}
      />

      {/* Drawer */}
      <div
        className="fixed right-0 top-0 bottom-0 z-[30000] flex flex-col overflow-hidden"
        style={{
          width: 'min(420px, 100vw)',
          background: '#FAFAF7',
          boxShadow: '-4px 0 40px rgba(0,0,0,0.12)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-10 pb-5" style={{ borderBottom: '1px solid #EBEBDF' }}>
          <h2 className="font-poppins font-bold" style={{ fontSize: '22px', color: '#141413', letterSpacing: '-0.4px' }}>
            Create a trip
          </h2>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-full"
            style={{ background: '#F0EFE9' }}
            aria-label="Close"
          >
            <X size={16} color="#141413" />
          </button>
        </div>

        {/* Form */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-5">

          {/* Trip name */}
          <div>
            <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>
              Trip name
            </label>
            <input
              type="text"
              placeholder="e.g. Summer vacation in Greece"
              value={form.title}
              maxLength={80}
              onChange={e => set('title', e.target.value)}
              className="w-full font-inter outline-none"
              style={{ height: '48px', background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '14px', padding: '0 16px', fontSize: '14px', color: '#141413' }}
            />
            <p className="font-inter mt-1 text-right" style={{ fontSize: '12px', color: '#B0AEA5' }}>{form.title.length}/80 max characters</p>
          </div>

          {/* Destination */}
          <div>
            <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>
              Destination
            </label>
            <div className="relative">
              <MapPin size={16} color="#B0AEA5" className="absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Where to?"
                value={form.destination_city}
                onChange={e => set('destination_city', e.target.value)}
                className="w-full font-inter outline-none"
                style={{ height: '48px', background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '14px', padding: '0 16px 0 42px', fontSize: '14px', color: '#141413' }}
              />
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>Start date</label>
              <input
                type="date"
                value={form.start_date}
                onChange={e => set('start_date', e.target.value)}
                className="w-full font-inter outline-none"
                style={{ height: '48px', background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '14px', padding: '0 14px', fontSize: '14px', color: '#141413' }}
              />
            </div>
            <div>
              <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>End date</label>
              <input
                type="date"
                value={form.end_date}
                onChange={e => set('end_date', e.target.value)}
                className="w-full font-inter outline-none"
                style={{ height: '48px', background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '14px', padding: '0 14px', fontSize: '14px', color: '#141413' }}
              />
            </div>
          </div>

          {/* Planned activity */}
          <div>
            <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>
              Planned activity
            </label>
            <div className="relative">
              <Sparkles size={16} color="#B0AEA5" className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                value={form.planned_activity}
                onChange={e => set('planned_activity', e.target.value)}
                className="w-full font-inter outline-none appearance-none"
                style={{ height: '48px', background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '14px', padding: '0 40px 0 42px', fontSize: '14px', color: form.planned_activity ? '#141413' : '#B0AEA5' }}
              >
                <option value="" disabled>Select an activity…</option>
                {ACTIVITY_OPTIONS.map(a => (
                  <option key={a.value} value={a.value}>{a.label}</option>
                ))}
              </select>
              <Tag size={14} color="#B0AEA5" className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>
              Notes
            </label>
            <div className="relative">
              <StickyNote size={16} color="#B0AEA5" className="absolute left-4 top-4 pointer-events-none" />
              <textarea
                placeholder="Add notes, ideas, or links…"
                value={form.notes}
                onChange={e => set('notes', e.target.value)}
                rows={4}
                className="w-full font-inter outline-none resize-none"
                style={{ background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '14px', padding: '14px 16px 14px 42px', fontSize: '14px', color: '#141413' }}
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-5 flex gap-3" style={{ borderTop: '1px solid #EBEBDF' }}>
          <button
            onClick={onClose}
            className="flex-1 font-poppins font-semibold"
            style={{ height: '50px', borderRadius: '14px', border: '1.5px solid #E8E6DC', fontSize: '15px', color: '#141413', background: '#FFF' }}
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving || !form.title || !form.destination_city}
            className="flex-1 font-poppins font-semibold text-white transition-opacity"
            style={{
              height: '50px',
              borderRadius: '14px',
              background: '#141413',
              fontSize: '15px',
              opacity: (saving || !form.title || !form.destination_city) ? 0.45 : 1,
            }}
          >
            {saving ? 'Creating…' : 'Create trip'}
          </button>
        </div>
      </div>
    </>
  );
}