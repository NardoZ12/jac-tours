import { useState } from 'react';
import { X, Copy, Check, Share2, Mail, Users, Send } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';

/**
 * Invite friends to a trip — shows the shareable URL, copy/native-share buttons,
 * email invites via Core.SendEmail, and the current member list.
 */
export default function InviteFriendsSheet({ trip, inviteUrl, onClose }) {
  const [copied, setCopied] = useState(false);
  const [email, setEmail] = useState('');
  const [sending, setSending] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopied(true);
      toast.success('Invite link copied!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Could not copy link');
    }
  };

  const nativeShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: trip?.title || 'Join my trip',
          text: `Join my trip to ${trip?.destination_city || 'somewhere amazing'} on Roam`,
          url: inviteUrl,
        });
      } else {
        copy();
      }
    } catch {
      // user cancelled — ignore
    }
  };

  const sendEmail = async () => {
    const trimmed = email.trim();
    if (!trimmed || !/.+@.+\..+/.test(trimmed)) {
      toast.error('Please enter a valid email');
      return;
    }
    setSending(true);
    try {
      await base44.integrations.Core.SendEmail({
        to: trimmed,
        subject: `You're invited to "${trip.title}" on Roam`,
        body: `Hey!\n\nYou're invited to join the trip "${trip.title}" to ${trip.destination_city || ''}.\n\nTap the link below to view the itinerary and join:\n${inviteUrl}\n\nSee you there ✈️`,
      });
      toast.success(`Invite sent to ${trimmed}`);
      setEmail('');
    } catch {
      toast.error('Could not send invite. Try copying the link instead.');
    }
    setSending(false);
  };

  const memberNames = trip?.member_names || [];

  return (
    <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
      {/* Drag handle */}
      <div className="flex justify-center pt-3 pb-2 flex-shrink-0 lg:hidden">
        <div className="w-10 h-1 rounded-full" style={{ background: '#E8E6DC' }} />
      </div>

      {/* Header */}
      <div className="flex items-start justify-between px-5 pt-3 pb-4 flex-shrink-0">
        <div>
          <h2 className="font-poppins font-bold" style={{ fontSize: '20px', color: '#141413', letterSpacing: '-0.3px' }}>
            Invite friends
          </h2>
          <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>
            Anyone with the link can join <span style={{ color: '#141413', fontWeight: 600 }}>{trip?.title}</span> and see the itinerary.
          </p>
        </div>
        <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full flex-shrink-0" style={{ background: '#F0EFE9' }}>
          <X size={16} color="#141413" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-5">
        {/* Invite link */}
        <div>
          <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '12px', color: '#141413' }}>
            Invite link
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={inviteUrl}
              readOnly
              onFocus={(e) => e.target.select()}
              className="flex-1 font-inter outline-none"
              style={{
                height: '46px', padding: '0 14px', borderRadius: '12px',
                border: '1.5px solid #E8E6DC', fontSize: '13px',
                background: '#FAF9F5', color: '#141413',
              }}
            />
            <button
              onClick={copy}
              className="flex items-center gap-1.5 font-poppins font-semibold flex-shrink-0"
              style={{
                height: '46px', padding: '0 16px', borderRadius: '12px',
                background: copied ? '#16A34A' : '#141413',
                color: '#FFFFFF', fontSize: '13px',
              }}
            >
              {copied ? <><Check size={14} /> Copied</> : <><Copy size={14} /> Copy</>}
            </button>
          </div>

          <button
            onClick={nativeShare}
            className="w-full mt-3 flex items-center justify-center gap-2 font-poppins font-semibold"
            style={{
              height: '46px', borderRadius: '12px',
              background: 'linear-gradient(135deg,#FF385C,#E61E4D)',
              color: '#FFFFFF', fontSize: '14px',
              boxShadow: '0 8px 22px rgba(255,56,92,0.30)',
            }}
          >
            <Share2 size={16} /> Share with friends
          </button>
        </div>

        {/* Email invite */}
        <div>
          <label className="block font-poppins font-semibold mb-2" style={{ fontSize: '12px', color: '#141413' }}>
            Send by email
          </label>
          <div className="flex items-center gap-2">
            <div className="flex-1 flex items-center gap-2 px-3" style={{ height: '46px', borderRadius: '12px', border: '1.5px solid #E8E6DC', background: '#FAF9F5' }}>
              <Mail size={15} color="#B0AEA5" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="friend@example.com"
                className="flex-1 font-inter outline-none bg-transparent"
                style={{ fontSize: '13px', color: '#141413' }}
              />
            </div>
            <button
              onClick={sendEmail}
              disabled={sending}
              className="flex items-center gap-1.5 font-poppins font-semibold flex-shrink-0"
              style={{
                height: '46px', padding: '0 16px', borderRadius: '12px',
                background: sending ? '#B0AEA5' : '#141413',
                color: '#FFFFFF', fontSize: '13px',
              }}
            >
              <Send size={14} /> {sending ? 'Sending…' : 'Send'}
            </button>
          </div>
        </div>

        {/* Current members */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Users size={14} color="#141413" />
            <p className="font-poppins font-semibold" style={{ fontSize: '13px', color: '#141413' }}>
              Going ({memberNames.length || 1})
            </p>
          </div>
          {memberNames.length === 0 ? (
            <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>
              Just you for now — invite people to start planning together.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {memberNames.map((name, i) => (
                <div key={i} className="flex items-center gap-2 rounded-full px-2 py-1" style={{ background: '#F0EFE9' }}>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center font-poppins font-bold text-white" style={{ background: '#141413', fontSize: '12px' }}>
                    {(name || 'U').charAt(0).toUpperCase()}
                  </div>
                  <span className="font-inter pr-2" style={{ fontSize: '12px', color: '#141413' }}>{name}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </ResponsiveSheetShell>
  );
}