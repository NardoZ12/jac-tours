import { Star, ShieldCheck } from 'lucide-react';

/**
 * Customer feedback panel for venue owners.
 * Aggregates avg rating + distribution from VERIFIED-BOOKING reviews
 * and lists the most recent verified reviews.
 */
export default function CustomerFeedback({ reviews = [], venueIds = [] }) {
  // Filter to verified, on-venue reviews
  const verified = reviews.filter(r =>
    r.visit_verified && (venueIds.length === 0 || venueIds.includes(r.venue_id))
  );

  const count = verified.length;
  const avg = count
    ? verified.reduce((sum, r) => sum + (r.rating || 0), 0) / count
    : 0;

  const distribution = [5, 4, 3, 2, 1].map(stars => ({
    stars,
    count: verified.filter(r => Math.round(r.rating) === stars).length,
  }));

  const latest = [...verified]
    .sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0))
    .slice(0, 5);

  return (
    <div className="mb-5">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>
          Customer feedback
        </h2>
        <div className="flex items-center gap-1">
          <ShieldCheck size={13} color="#16A34A" />
          <span className="font-inter" style={{ fontSize: '12px', color: '#16A34A' }}>From verified bookings</span>
        </div>
      </div>

      {/* Summary card */}
      <div className="rounded-2xl bg-white card-shadow p-4 mb-3">
        <div className="flex items-center gap-4">
          <div className="text-center flex-shrink-0">
            <p className="font-poppins font-bold" style={{ fontSize: '32px', color: '#141413', lineHeight: 1 }}>
              {avg.toFixed(1)}
            </p>
            <div className="flex items-center justify-center gap-0.5 my-1">
              {[1, 2, 3, 4, 5].map(i => (
                <Star
                  key={i}
                  size={12}
                  style={{
                    fill: i <= Math.round(avg) ? '#D97757' : '#E8E6DC',
                    color: i <= Math.round(avg) ? '#D97757' : '#E8E6DC',
                  }}
                />
              ))}
            </div>
            <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
              {count} review{count === 1 ? '' : 's'}
            </p>
          </div>

          <div className="flex-1 space-y-1">
            {distribution.map(({ stars, count: c }) => {
              const pct = count ? (c / count) * 100 : 0;
              return (
                <div key={stars} className="flex items-center gap-2">
                  <span className="font-inter w-3" style={{ fontSize: '12px', color: '#72706A' }}>{stars}</span>
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: '#E8E6DC' }}>
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: '#D97757' }} />
                  </div>
                  <span className="font-inter w-5 text-right" style={{ fontSize: '12px', color: '#72706A' }}>{c}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Latest feedback */}
      {latest.length === 0 ? (
        <div className="rounded-xl bg-white card-shadow p-4 text-center">
          <p style={{ fontSize: '28px' }}>💬</p>
          <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>
            No verified reviews yet. They'll appear here after guests complete a booking.
          </p>
        </div>
      ) : (
        latest.map(r => (
          <div key={r.id} className="rounded-xl bg-white card-shadow p-3 mb-3">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>
                  {r.reviewer_name || 'Guest'}
                </span>
                <span className="flex items-center gap-1 font-inter" style={{ fontSize: '12px', color: '#16A34A', background: '#F0FDF4', padding: '2px 6px', borderRadius: '99px' }}>
                  <ShieldCheck size={10} /> Verified
                </span>
              </div>
              <span className="font-poppins font-semibold" style={{ fontSize: '13px', color: '#D97757' }}>⭐ {r.rating}</span>
            </div>
            {r.title && (
              <p className="font-poppins font-semibold mb-0.5" style={{ fontSize: '13px', color: '#141413' }}>{r.title}</p>
            )}
            <p className="font-inter" style={{ fontSize: '13px', color: '#72706A', lineHeight: 1.5 }}>
              {r.body || 'Great experience!'}
            </p>
            <button className="font-inter mt-1" style={{ fontSize: '12px', color: '#2A6DB5' }}>Reply →</button>
          </div>
        ))
      )}
    </div>
  );
}