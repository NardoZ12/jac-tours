import { useState, useMemo } from 'react';
import { X, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import ConfettiEffect from '../ui/ConfettiEffect';
import BookingConfirmation from '../booking/BookingConfirmation';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';
import PickupMapSelector from './PickupMapSelector';
import PaypalCardForm from '@/components/payment/PaypalCardForm';

function genCode() {
  return 'E' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

const DEFAULT_TIMES = ['09:00', '11:00', '14:00', '16:00'];
const COCO_BONGO_TIMES = ['19:00'];

/**
 * Experience-specific booking flow → creates a Booking with booking_type='do'.
 * Steps: 0 = pick date + time, 1 = confirm + price.
 */
export default function ExperienceBookingSheet({ venue, groupSize, pricePerPerson, tier = 'private', totalPrice, priceNote, onClose }) {
  const today = new Date();
  const [step, setStep] = useState(0);
  const [date, setDate] = useState(null);
  const hasTicketTiers = Array.isArray(venue?.ticket_tiers) && venue.ticket_tiers.length > 0;
  const TIMES = hasTicketTiers ? COCO_BONGO_TIMES : DEFAULT_TIMES;
  const [time, setTime] = useState(TIMES[0]);
  const [showCal, setShowCal] = useState(false);
  const [pickup, setPickup] = useState(null);
  const [confetti, setConfetti] = useState(false);
  const [code] = useState(genCode);
  const [bookingId] = useState(null);
  const [success, setSuccess] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [flightNumber, setFlightNumber] = useState('');
  const [luggageCount, setLuggageCount] = useState('');
  const [paymentOption, setPaymentOption] = useState('deposit');

  const total = useMemo(() => (totalPrice != null ? totalPrice : pricePerPerson * groupSize), [totalPrice, pricePerPerson, groupSize]);
  const depositAmount = useMemo(() => Math.round(total * 0.3 * 100) / 100, [total]);
  const dueAtPickup = useMemo(() => Math.round((total - depositAmount) * 100) / 100, [total, depositAmount]);
  const payNow = paymentOption === 'deposit' ? depositAmount : total;

  const onPaid = () => {
    setConfetti(true);
    setSuccess(true);
  };

  const buildBooking = () => {
    const confirmationCode = code;
    return {
      confirmationCode,
      venueName: venue.name,
      tier: tier === 'private' ? 'Private' : tier === 'regular' ? 'Regular' : tier,
      dateLabel: format(date, 'EEE, MMM d'),
      timeLabel: time,
      partyLabel: `${groupSize} ${groupSize > 1 ? 'people' : 'person'}`,
      pickupLabel: pickup ? `${pickup.name}${pickup.area ? ` · ${pickup.area}` : ''}` : '',
      total,
      currency: 'USD',
      customerName,
      customerPhone,
      customerEmail,
      flightNumber,
      luggageCount,
      paymentOption,
      depositAmount,
      dueAtPickup,
      payNow,
    };
  };

  return (
    <>
      <ConfettiEffect active={confetti} />
      <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
        <div className="flex justify-center pt-3 pb-3 flex-shrink-0">
          <div className="w-10 h-1 rounded-full" style={{ background: '#E8E6DC' }} />
        </div>
        <button onClick={onClose} className="absolute top-4 right-5 z-10 w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>
          <X size={16} color="#141413" />
        </button>

        <div className="flex-1 overflow-y-auto px-5" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 32px)' }}>
          {success ? (
            <BookingConfirmation
              booking={{
                confirmationCode: code,
                bookingId,
                venue,
                type: 'do',
                tier: tier === 'private' ? 'Private' : tier === 'regular' ? 'Regular' : tier,
                dateLabel: format(date, 'EEE, MMM d'),
                timeLabel: time,
                partyLabel: `${groupSize} ${groupSize > 1 ? 'people' : 'person'}`,
                pickupLabel: pickup ? `${pickup.name}${pickup.area ? ` · ${pickup.area}` : ''}` : '',
                total,
                currency: 'USD',
                customerName,
                customerPhone,
                customerEmail,
                flightNumber,
                luggageCount,
                paymentOption,
                depositAmount,
                dueAtPickup,
                payNow,
              }}
              onClose={onClose}
            />
          ) : step === 0 ? (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>{'Pick a date & time'}</h2>

              <button
                onClick={() => setShowCal(s => !s)}
                className="w-full rounded-2xl p-4 mb-3 flex items-center gap-3 text-left"
                style={{ background: '#F0EFE9' }}
              >
                <CalendarIcon size={20} color="#1F1B2E" />
                <div className="flex-1">
                  <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Date</p>
                  <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{date ? format(date, 'EEE, MMM d') : 'Select date'}</p>
                </div>
                <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#4A7A35' }}>{showCal ? 'Done' : 'Edit'}</span>
              </button>

              {showCal && (
                <div className="rounded-2xl mb-3" style={{ background: '#FFF', border: '1.5px solid #E8E6DC' }}>
                  <div className="flex justify-center">
                    <Calendar mode="single" selected={date || undefined} onSelect={d => d && setDate(d)} disabled={{ before: today }} numberOfMonths={1} />
                  </div>
                  {date && <button type="button" onClick={() => setDate(null)} className="mx-3 mb-3 w-[calc(100%-24px)] rounded-full border border-[#E8E6DC] bg-white px-4 py-2 font-inter text-xs font-semibold transition-colors hover:bg-[#F7F4FF]" style={{ color: '#571AFF' }}>Clear date</button>}
                </div>
              )}

              <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Ubicación de recogida</p>
              <div className="mb-2">
                <PickupMapSelector value={pickup} onChange={setPickup} />
              </div>
              <input
                type="text"
                placeholder="O escribe tu hotel o dirección aquí…"
                value={pickup?.name || ''}
                onChange={(e) => setPickup({ name: e.target.value, area: '', address: e.target.value, lat: null, lng: null, type: 'manual' })}
                className="w-full rounded-2xl px-4 py-3 font-inter mb-4"
                style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }}
              />

              <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Available times</p>
              <div className={hasTicketTiers ? 'mb-4' : 'grid grid-cols-4 gap-2 mb-4'}>
                {TIMES.map(t => {
                  const label = hasTicketTiers ? '7:00 PM' : t;
                  return (
                    <button
                      key={t}
                      onClick={() => setTime(t)}
                      className="font-poppins font-semibold w-full"
                      style={{
                        height: '40px', borderRadius: '10px', fontSize: '13px',
                        background: t === time ? '#141413' : '#FFF',
                        color: t === time ? '#FFF' : '#141413',
                        border: '1.5px solid ' + (t === time ? '#141413' : '#E8E6DC'),
                      }}
                    >{label}</button>
                  );
                })}
              </div>

              <p className="font-inter mb-2 mt-4" style={{ fontSize: '13px', color: '#72706A' }}>Tus datos</p>
              <div className="space-y-3 mb-4">
                <input type="text" placeholder="Nombre completo" value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                <input type="tel" placeholder="Teléfono" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                <input type="email" placeholder="Correo electrónico" value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" placeholder="N° de vuelo (opcional)" value={flightNumber} onChange={(e) => setFlightNumber(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                  <input type="number" placeholder="Equipaje (opcional)" value={luggageCount} onChange={(e) => setLuggageCount(e.target.value)} min="0" className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                </div>
              </div>

              <div className="rounded-2xl p-4 mb-4" style={{ background: '#FFF1EC' }}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>{priceNote || `${pricePerPerson} × ${groupSize} ${groupSize > 1 ? 'people' : 'person'}`}</span>
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>${total}</span>
                </div>
              </div>

              <button onClick={() => setStep(1)} disabled={!date || !pickup || !customerName || !customerPhone || !customerEmail} className="btn-primary">
                Continue →
              </button>
            </>
          ) : (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Confirm booking</h2>
              <div className="rounded-2xl p-4 mb-3" style={{ background: '#F0EFE9' }}>
                <div className="space-y-2">
                  {[
                    ['Experience', venue.name],
                    ['Tier', tier === 'private' ? 'Private' : tier === 'regular' ? 'Regular' : tier],
                    ['Date', format(date, 'EEE, MMM d')],
                    ['Time', time],
                    ['Group', `${groupSize} ${groupSize > 1 ? 'people' : 'person'}`],
                    ['Pickup', pickup ? `${pickup.name}${pickup.area ? ` · ${pickup.area}` : ''}` : '—'],
                    ['Nombre', customerName || '—'],
                    ['Teléfono', customerPhone || '—'],
                    ['Correo', customerEmail || '—'],
                    ['Vuelo', flightNumber || '—'],
                    ['Equipaje', luggageCount || '—'],
                  ].map(([l, v]) => (
                    <div key={l} className="flex items-center justify-between">
                      <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{l}</span>
                      <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{v}</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between pt-2" style={{ borderTop: '1px solid #E8E6DC' }}>
                    <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>Total</span>
                    <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>${total}</span>
                  </div>
                </div>
              </div>

              {/* Payment option */}
              <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Opción de pago</p>
              <div className="space-y-2 mb-3">
                <button
                  type="button"
                  onClick={() => setPaymentOption('deposit')}
                  className="w-full rounded-2xl p-4 text-left transition-all"
                  style={{
                    background: paymentOption === 'deposit' ? '#141413' : '#FFF',
                    border: '2px solid ' + (paymentOption === 'deposit' ? '#141413' : '#E8E6DC'),
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-poppins font-bold" style={{ fontSize: '14px', color: paymentOption === 'deposit' ? '#FFFFFF' : '#141413' }}>Pagar 30% ahora</span>
                      <p className="font-inter" style={{ fontSize: '11px', color: paymentOption === 'deposit' ? 'rgba(255,255,255,0.7)' : '#72706A' }}>Restante ${dueAtPickup} al ser recogido</p>
                    </div>
                    <span className="font-poppins font-bold" style={{ fontSize: '16px', color: paymentOption === 'deposit' ? '#B6F02D' : '#141413' }}>${depositAmount}</span>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentOption('full')}
                  className="w-full rounded-2xl p-4 text-left transition-all"
                  style={{
                    background: paymentOption === 'full' ? '#141413' : '#FFF',
                    border: '2px solid ' + (paymentOption === 'full' ? '#141413' : '#E8E6DC'),
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-poppins font-bold" style={{ fontSize: '14px', color: paymentOption === 'full' ? '#FFFFFF' : '#141413' }}>Pagar total ahora</span>
                      <p className="font-inter" style={{ fontSize: '11px', color: paymentOption === 'full' ? 'rgba(255,255,255,0.7)' : '#72706A' }}>Pago completo al reservar</p>
                    </div>
                    <span className="font-poppins font-bold" style={{ fontSize: '16px', color: paymentOption === 'full' ? '#B6F02D' : '#141413' }}>${total}</span>
                  </div>
                </button>
              </div>

              <p className="font-inter mb-3 text-center" style={{ fontSize: '12px', color: '#72706A' }}>
                ✓ Free cancellation up to 24h before
              </p>
              <PaypalCardForm
                amount={payNow}
                description={`${venue.name} · ${tier === 'private' ? 'Private' : tier === 'regular' ? 'Regular' : tier} · ${code}`}
                booking={buildBooking()}
                onPaid={onPaid}
              />
            </>
          )}
        </div>
      </ResponsiveSheetShell>
    </>
  );
}