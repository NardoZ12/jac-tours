import { useEffect, useRef, useState, useCallback } from 'react';
import { MapPin, Search, X, LocateFixed, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import MapsAuthNotice from '@/components/traslado/MapsAuthNotice';

let mapsLoaderPromise = null;

function loadGoogleMaps(apiKey) {
  if (window.google?.maps) return Promise.resolve(window.google.maps);
  if (mapsLoaderPromise) return mapsLoaderPromise;
  mapsLoaderPromise = new Promise((resolve, reject) => {
    const cb = '__gmaps_cb_' + Date.now();
    window[cb] = () => { resolve(window.google.maps); delete window[cb]; };
    const s = document.createElement('script');
    s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&v=weekly&callback=${cb}`;
    s.async = true;
    s.defer = true;
    s.onerror = () => { mapsLoaderPromise = null; reject(new Error('No se pudo cargar Google Maps')); };
    document.head.appendChild(s);
  });
  return mapsLoaderPromise;
}

/**
 * Pickup-location selector backed by Google Places Autocomplete.
 * The user can search any place on Google Maps; selecting one resolves its
 * coordinates and address and calls onChange({ name, area, address, lat, lng }).
 */
export default function PickupLocationSelector({ value, onChange }) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);
  const [authIssue, setAuthIssue] = useState(null);
  const [query, setQuery] = useState(value || '');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [locating, setLocating] = useState(false);
  const [geoError, setGeoError] = useState(null);
  const [selected, setSelected] = useState(!!value);

  const boxRef = useRef(null);
  const placesLibRef = useRef(null);
  const geocoderRef = useRef(null);
  const sessionTokenRef = useRef(null);
  const debounceRef = useRef(null);
  const searchSeqRef = useRef(0);

  useEffect(() => {
    let cancelled = false;
    const origConsoleError = console.error;
    console.error = (...args) => {
      const m = String(args[0] ?? '').match(/Google Maps JavaScript API error: (\w+)/);
      if (m) setAuthIssue(m[1]);
      origConsoleError.apply(console, args);
    };
    window.gm_authFailure = () => setAuthIssue((prev) => prev || 'AuthFailure');
    (async () => {
      try {
        const res = await base44.functions.invoke('getMapsConfig', {});
        const apiKey = res.data?.google_maps_api_key;
        if (!apiKey) { setError('Falta configurar la API key de Google Maps'); return; }
        const maps = await loadGoogleMaps(apiKey);
        if (cancelled) return;
        placesLibRef.current = await maps.importLibrary('places');
        geocoderRef.current = new maps.Geocoder();
        setReady(true);
      } catch (err) {
        if (!cancelled) setError(err.message || 'Error al cargar Google Maps');
      }
    })();
    return () => { cancelled = true; console.error = origConsoleError; };
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (boxRef.current && !boxRef.current.contains(e.target)) setResults([]);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSearch = useCallback((val) => {
    setQuery(val);
    setSelected(false);
    setSearchError(null);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!val || val.trim().length < 2) { searchSeqRef.current += 1; setResults([]); setSearching(false); return; }
    if (!placesLibRef.current) return;
    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      const seq = ++searchSeqRef.current;
      const { AutocompleteSuggestion, AutocompleteSessionToken } = placesLibRef.current;
      if (!sessionTokenRef.current) sessionTokenRef.current = new AutocompleteSessionToken();
      try {
        const { suggestions } = await AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: val,
          includedRegionCodes: ['do'],
          sessionToken: sessionTokenRef.current,
        });
        if (seq !== searchSeqRef.current) return;
        setResults(suggestions.map((s) => s.placePrediction).filter(Boolean));
      } catch (err) {
        if (seq !== searchSeqRef.current) return;
        setResults([]);
        setSearchError('Google bloqueó la búsqueda. Verifica que "Places API (New)" esté habilitada. ' + (err?.message ? `(${err.message.slice(0, 120)})` : ''));
      }
      setSearching(false);
    }, 350);
  }, []);

  const selectResult = useCallback(async (prediction) => {
    setSearching(true);
    try {
      const place = prediction.toPlace();
      await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location', 'addressComponents'] });
      const lat = place.location.lat();
      const lng = place.location.lng();
      const name = place.displayName || place.formattedAddress || prediction.text?.text || '';
      const address = place.formattedAddress || '';
      let area = '';
      try {
        const comps = place.addressComponents || [];
        const find = (types) => comps.find((c) => c.types?.some((t) => types.includes(t)));
        const c = find(['locality', 'administrative_area_level_2', 'sublocality', 'administrative_area_level_1']);
        area = c?.longText || '';
      } catch {}
      setQuery(name);
      setSelected(true);
      setResults([]);
      sessionTokenRef.current = null;
      onChange?.({ name, area, address, lat, lng, type: 'area' });
    } catch {
      setSearchError('No se pudo obtener la ubicación del lugar seleccionado.');
    }
    setSearching(false);
  }, [onChange]);

  useEffect(() => () => { if (debounceRef.current) clearTimeout(debounceRef.current); }, []);

  const useMyLocation = () => {
    if (!navigator.geolocation) { setGeoError('La geolocalización no está disponible en este dispositivo.'); return; }
    setLocating(true);
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        if (geocoderRef.current) {
          geocoderRef.current.geocode({ location: { lat, lng } }, (results, status) => {
            let name = 'Mi ubicación actual';
            let address = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
            let area = '';
            if (status === 'OK' && results?.[0]) {
              address = results[0].formatted_address;
              const r = results[0];
              const c = r.address_components?.find((x) => x.types?.some((t) => ['locality', 'administrative_area_level_2', 'sublocality', 'administrative_area_level_1'].includes(t)));
              area = c?.long_name || '';
              const road = r.address_components?.find((x) => x.types?.includes('route'));
              name = road?.long_name ? road.long_name : address.split(',')[0] || name;
            }
            setQuery(name);
            setSelected(true);
            onChange?.({ name, area, address, lat, lng, type: 'area' });
            setLocating(false);
          });
        } else {
          setQuery('Mi ubicación actual');
          setSelected(true);
          onChange?.({ name: 'Mi ubicación actual', area: '', address: `${lat.toFixed(5)}, ${lng.toFixed(5)}`, lat, lng, type: 'area' });
          setLocating(false);
        }
      },
      (err) => {
        setLocating(false);
        setGeoError(err.code === 1 ? 'Permiso denegado. Activa la ubicación para usar esta opción.' : 'No se pudo obtener tu ubicación.');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  if (error) {
    return (
      <div className="rounded-2xl p-4 text-center" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC' }}>
        <MapPin size={24} color="#72706A" className="mx-auto mb-2" />
        <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{error}</p>
      </div>
    );
  }

  return (
    <div ref={boxRef} className="relative">
      <div className="w-full rounded-2xl flex items-center gap-3 px-4" style={{ background: '#F0EFE9', minHeight: '52px' }}>
        <MapPin size={20} color="#571AFF" className="flex-shrink-0" />
        <input
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          onFocus={() => { if (results.length) {} }}
          placeholder={ready ? 'Busca tu hotel, resort o dirección en el mapa…' : 'Cargando Google Maps…'}
          disabled={!ready}
          className="flex-1 bg-transparent outline-none font-inter"
          style={{ fontSize: '14px', color: '#141413' }}
        />
        {searching ? (
          <Loader2 size={16} className="animate-spin flex-shrink-0" color="#571AFF" />
        ) : query ? (
          <button
            type="button"
            onClick={() => { setQuery(''); setSelected(false); setResults([]); onChange?.(null); }}
            className="flex-shrink-0"
            aria-label="Limpiar"
          >
            <X size={16} color="#72706A" />
          </button>
        ) : (
          <Search size={16} color="#72706A" className="flex-shrink-0" />
        )}
      </div>

      <button
        type="button"
        onClick={useMyLocation}
        disabled={locating || !ready}
        className="mt-2 w-full rounded-2xl flex items-center justify-center gap-2 font-inter font-semibold transition-colors"
        style={{ minHeight: '44px', background: '#F7F4FF', border: '1.5px solid #571AFF', color: '#571AFF', fontSize: '13px' }}
      >
        <LocateFixed size={16} />
        {locating ? 'Obteniendo ubicación…' : 'Usar mi ubicación actual'}
      </button>
      {geoError && <p className="mt-1 font-inter" style={{ fontSize: '12px', color: '#DC2626' }}>{geoError}</p>}
      {authIssue && <div className="mt-2"><MapsAuthNotice code={authIssue} /></div>}

      {results.length > 0 && (
        <div
          className="absolute z-30 left-0 right-0 mt-2 rounded-2xl overflow-hidden"
          style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC', boxShadow: '0 12px 32px rgba(14,14,14,0.14)', maxHeight: '280px', overflowY: 'auto' }}
        >
          {results.map((pred) => (
            <button
              key={pred.placeId}
              type="button"
              onClick={() => selectResult(pred)}
              className="w-full text-left px-4 flex items-start gap-3 transition-colors hover:bg-[#F7F4FF]"
              style={{ padding: '12px 16px', borderBottom: '1px solid #F2F0EA' }}
            >
              <MapPin size={16} color="#571AFF" className="mt-0.5 shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="font-poppins font-semibold truncate" style={{ fontSize: '14px', color: '#141413' }}>
                  {pred.mainText?.text || pred.text?.text}
                </p>
                {pred.secondaryText?.text && (
                  <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>{pred.secondaryText.text}</p>
                )}
              </div>
            </button>
          ))}
        </div>
      )}
      {searchError && !searching && query && results.length === 0 && (
        <div className="absolute z-30 left-0 right-0 mt-2 rounded-2xl px-4 py-3" style={{ background: '#FFF3F3', border: '1.5px solid #E8A0A0' }}>
          <p className="font-inter" style={{ fontSize: '12px', color: '#8A2820' }}>{searchError}</p>
        </div>
      )}
    </div>
  );
}