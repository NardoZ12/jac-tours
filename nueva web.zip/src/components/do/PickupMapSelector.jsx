import { useState, useEffect, useRef, useCallback } from 'react';
import { MapPin, Search, X, Crosshair, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import MapsAuthNotice from '@/components/traslado/MapsAuthNotice';

const PUNTA_CANA = { lat: 18.56, lng: -68.37 };

let mapsLoaderPromise = null;

function loadGoogleMaps(apiKey) {
  if (window.google?.maps) return Promise.resolve(window.google.maps);
  if (mapsLoaderPromise) return mapsLoaderPromise;
  mapsLoaderPromise = new Promise((resolve, reject) => {
    const cb = '__gmaps_cb_' + Date.now();
    window[cb] = () => { resolve(window.google.maps); delete window[cb]; };
    const s = document.createElement('script');
    s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&v=weekly&callback=${cb}`;
    s.async = true;
    s.defer = true;
    s.onerror = () => { mapsLoaderPromise = null; reject(new Error('No se pudo cargar Google Maps')); };
    document.head.appendChild(s);
  });
  return mapsLoaderPromise;
}

/**
 * Compact map-based pickup selector for the booking/checkout flow.
 * Shows an interactive map with a search box; the user can search any place
 * on Google Maps or tap the map to set the pickup point.
 * Calls onChange({ name, area, address, lat, lng }).
 */
export default function PickupMapSelector({ value, onChange }) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);
  const [authIssue, setAuthIssue] = useState(null);
  const [searchValue, setSearchValue] = useState(value?.name || '');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [locating, setLocating] = useState(false);
  const [picked, setPicked] = useState(!!value);

  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const placesLibRef = useRef(null);
  const geocoderRef = useRef(null);
  const sessionTokenRef = useRef(null);
  const debounceRef = useRef(null);
  const searchSeqRef = useRef(0);

  useEffect(() => {
    let cancelled = false;
    const origConsoleError = console.error;
    console.error = (...args) => {
      const m = String(args[0] ?? '').match(/Google Maps JavaScript API error: (\w+)/);
      if (m) setAuthIssue(m[1]);
      origConsoleError.apply(console, args);
    };
    window.gm_authFailure = () => setAuthIssue((prev) => prev || 'AuthFailure');
    (async () => {
      try {
        const res = await base44.functions.invoke('getMapsConfig', {});
        const apiKey = res.data?.google_maps_api_key;
        if (!apiKey) { setError('Falta configurar la API key de Google Maps'); return; }
        const maps = await loadGoogleMaps(apiKey);
        if (cancelled) return;
        mapRef.current = new maps.Map(mapContainerRef.current, {
          center: PUNTA_CANA, zoom: 11,
          mapTypeControl: false, streetViewControl: false, fullscreenControl: true, zoomControl: true,
        });
        geocoderRef.current = new maps.Geocoder();
        placesLibRef.current = await maps.importLibrary('places');
        if (cancelled) return;

        mapRef.current.addListener('click', (e) => {
          if (!e.latLng) return;
          const lat = e.latLng.lat(), lng = e.latLng.lng();
          reverseGeocode(lat, lng);
        });

        if (value?.lat && value?.lng) {
          setMarker(value.lat, value.lng);
          mapRef.current.panTo({ lat: value.lat, lng: value.lng });
        }

        setReady(true);
      } catch (err) {
        if (!cancelled) setError(err.message || 'Error al cargar Google Maps');
      }
    })();
    return () => { cancelled = true; console.error = origConsoleError; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setMarker = (lat, lng) => {
    const maps = window.google.maps;
    if (markerRef.current) markerRef.current.setMap(null);
    markerRef.current = new maps.Marker({ position: { lat, lng }, map: mapRef.current, animation: maps.Animation.DROP });
    mapRef.current.panTo({ lat, lng });
  };

  const reverseGeocode = (lat, lng) => {
    setMarker(lat, lng);
    if (!geocoderRef.current) {
      const name = 'Ubicación seleccionada';
      setPicked(true); setSearchValue(name); onChange?.({ name, area: '', address: `${lat.toFixed(5)}, ${lng.toFixed(5)}`, lat, lng, type: 'area' });
      return;
    }
    geocoderRef.current.geocode({ location: { lat, lng } }, (results, status) => {
      let name = 'Ubicación seleccionada';
      let address = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
      let area = '';
      if (status === 'OK' && results?.[0]) {
        address = results[0].formatted_address;
        const r = results[0];
        const c = r.address_components?.find((x) => x.types?.some((t) => ['locality', 'administrative_area_level_2', 'sublocality', 'administrative_area_level_1'].includes(t)));
        area = c?.long_name || '';
        const road = r.address_components?.find((x) => x.types?.includes('route'));
        name = road?.long_name ? road.long_name : address.split(',')[0] || name;
      }
      setPicked(true); setSearchValue(name);
      onChange?.({ name, area, address, lat, lng, type: 'area' });
    });
  };

  const handleSearch = useCallback((val) => {
    setSearchValue(val);
    setPicked(false);
    setSearchError(null);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!val || val.trim().length < 2) { searchSeqRef.current += 1; setResults([]); setSearching(false); return; }
    if (!placesLibRef.current) return;
    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      const seq = ++searchSeqRef.current;
      const { AutocompleteSuggestion, AutocompleteSessionToken } = placesLibRef.current;
      if (!sessionTokenRef.current) sessionTokenRef.current = new AutocompleteSessionToken();
      try {
        const { suggestions } = await AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: val, includedRegionCodes: ['do'], sessionToken: sessionTokenRef.current,
        });
        if (seq !== searchSeqRef.current) return;
        setResults(suggestions.map((s) => s.placePrediction).filter(Boolean));
      } catch (err) {
        if (seq !== searchSeqRef.current) return;
        setResults([]);
        setSearchError('Google bloqueó la búsqueda. Verifica "Places API (New)" y que el dominio esté autorizado en la clave. ' + (err?.message ? `(${err.message.slice(0, 120)})` : ''));
      }
      setSearching(false);
    }, 350);
  }, []);

  const selectResult = useCallback(async (prediction) => {
    setSearching(true);
    try {
      const place = prediction.toPlace();
      await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location'] });
      const lat = place.location.lat(), lng = place.location.lng();
      const name = place.displayName || place.formattedAddress || prediction.text?.text || '';
      const address = place.formattedAddress || '';
      setMarker(lat, lng);
      setPicked(true); setSearchValue(name); setResults([]);
      sessionTokenRef.current = null;
      onChange?.({ name, area: '', address, lat, lng, type: 'area' });
    } catch {
      setSearchError('No se pudo obtener la ubicación del lugar seleccionado.');
    }
    setSearching(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onChange]);

  useEffect(() => () => { if (debounceRef.current) clearTimeout(debounceRef.current); }, []);

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      reverseGeocode(lat, lng);
      setLocating(false);
    }, () => setLocating(false));
  };

  if (error) {
    return (
      <div className="rounded-2xl p-4 text-center" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC' }}>
        <MapPin size={22} color="#72706A" className="mx-auto mb-2" />
        <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{error}</p>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="relative rounded-2xl overflow-hidden" style={{ border: '1.5px solid #E8E6DC', height: '220px' }}>
        <div ref={mapContainerRef} className="w-full h-full" />
        {!ready && (
          <div className="absolute inset-0 flex items-center justify-center" style={{ background: '#F0EFE9' }}>
            <div className="text-center">
              <Loader2 size={22} className="animate-spin mx-auto mb-1" color="#571AFF" />
              <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Cargando mapa…</p>
            </div>
          </div>
        )}

        <div className="absolute left-3 right-3 top-3 z-10">
          <div className="relative">
            <Search size={15} color="#757575" className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchValue}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Busca tu hotel o dirección en el mapa…"
              disabled={!ready}
              className="w-full rounded-xl pl-9 pr-9 py-2.5 font-inter"
              style={{ background: '#FFFFFF', border: '1.5px solid #FFFFFF', fontSize: '13px', color: '#141413', minHeight: '40px', boxShadow: '0 2px 8px rgba(14,14,14,0.18)' }}
            />
            {searching ? (
              <Loader2 size={15} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin" color="#571AFF" />
            ) : searchValue ? (
              <button onClick={() => { setSearchValue(''); setResults([]); setPicked(false); }} className="absolute right-3 top-1/2 -translate-y-1/2"><X size={15} color="#757575" /></button>
            ) : null}
          </div>

          {results.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 rounded-xl overflow-hidden" style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC', boxShadow: '0 12px 32px rgba(14,14,14,0.18)', zIndex: 1000, maxHeight: '220px', overflowY: 'auto' }}>
              {results.map((pred) => (
                <button key={pred.placeId} type="button" onClick={() => selectResult(pred)} className="w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-[#F7F4FF] transition-colors" style={{ borderBottom: '1px solid #F0EFE9' }}>
                  <MapPin size={15} color="#571AFF" className="mt-0.5 shrink-0" />
                  <div className="min-w-0">
                    <p className="font-inter font-semibold truncate" style={{ fontSize: '13px', color: '#141413' }}>{pred.mainText?.text || pred.text?.text}</p>
                    {pred.secondaryText?.text && <p className="font-inter truncate" style={{ fontSize: '11px', color: '#72706A' }}>{pred.secondaryText.text}</p>}
                  </div>
                </button>
              ))}
            </div>
          )}
          {searchError && !searching && searchValue && results.length === 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 rounded-xl px-4 py-3" style={{ background: '#FFF3F3', border: '1.5px solid #E8A0A0', zIndex: 1000 }}>
              <p className="font-inter" style={{ fontSize: '12px', color: '#8A2820' }}>{searchError}</p>
            </div>
          )}
        </div>

        <button onClick={useMyLocation} disabled={!ready || locating} className="absolute bottom-3 right-3 rounded-full px-3 py-2 flex items-center gap-1.5 font-inter font-semibold" style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC', fontSize: '12px', color: '#141413', boxShadow: '0 2px 8px rgba(14,14,14,0.15)' }}>
          {locating ? <Loader2 size={14} className="animate-spin" /> : <Crosshair size={14} color="#571AFF" />}
          {locating ? '…' : 'Mi ubicación'}
        </button>
      </div>

      {picked && (
        <div className="mt-2 rounded-xl px-3 py-2 flex items-center gap-2" style={{ background: '#F7F4FF', border: '1.5px solid #571AFF' }}>
          <MapPin size={14} color="#571AFF" />
          <span className="font-inter truncate" style={{ fontSize: '12px', color: '#141413' }}>{searchValue}</span>
        </div>
      )}
      {authIssue && <div className="mt-2"><MapsAuthNotice code={authIssue} /></div>}
    </div>
  );
}