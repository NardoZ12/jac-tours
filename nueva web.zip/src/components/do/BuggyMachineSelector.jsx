import { useState } from 'react';
import { Minus, Plus } from 'lucide-react';

/**
 * Multi-machine selector for experiences whose ticket tiers represent
 * physical units with a fixed capacity (e.g. Buggies). The guest picks how
 * many of each machine they want; the people count auto-equals the total
 * capacity of the selected machines, and the price is per machine.
 */
export default function BuggyMachineSelector({ venue, onCheckout }) {
  const tiers = (venue.ticket_tiers || []).filter((t) => t.capacity);
  const [qty, setQty] = useState(() => tiers.map(() => 0));

  const totalMachines = qty.reduce((a, b) => a + b, 0);
  const totalCapacity = qty.reduce((a, q, i) => a + q * (tiers[i].capacity || 0), 0);
  const totalPrice = qty.reduce((a, q, i) => a + q * (tiers[i].price || 0), 0);

  const setQtyAt = (i, v) =>
    setQty((arr) => arr.map((x, idx) => (idx === i ? Math.max(0, v) : x)));

  const label = tiers
    .map((t, i) => (qty[i] > 0 ? `${qty[i]}× ${t.name}` : null))
    .filter(Boolean)
    .join(' · ');

  const checkout = () => {
    if (totalMachines === 0) return;
    onCheckout({
      people: totalCapacity,
      totalPrice,
      label: label || `${totalMachines} máquina(s)`,
    });
  };

  return (
    <div className="mt-5 rounded-2xl p-4 card-shadow bg-white">
      <h2 className="font-poppins font-semibold mb-1" style={{ fontSize: '16px', color: '#141413' }}>
        Elige tus buggies
      </h2>
      <p className="font-inter mb-3" style={{ fontSize: '12px', color: '#72706A' }}>
        Cada buggy tiene un cupo fijo. Agrega las máquinas que necesites; el número de personas se ajusta al cupo total.
      </p>

      <div className="space-y-2 mb-4">
        {tiers.map((t, i) => {
          const active = qty[i] > 0;
          return (
            <div
              key={i}
              className="rounded-2xl p-4 flex items-center justify-between transition-all"
              style={{ background: active ? '#141413' : '#F0EFE9' }}
            >
              <div className="flex-1 min-w-0">
                <span className="font-poppins font-bold" style={{ fontSize: '14px', color: active ? '#FFFFFF' : '#141413' }}>
                  {t.name}
                </span>
                <p className="font-inter" style={{ fontSize: '11px', color: active ? 'rgba(255,255,255,0.7)' : '#72706A' }}>
                  {t.description || `Cupo ${t.capacity} personas`}
                </p>
                <p className="font-poppins font-bold mt-1" style={{ fontSize: '15px', color: active ? '#FFFFFF' : '#141413' }}>
                  USD ${t.price.toFixed(2)}
                  <span style={{ fontSize: '11px', fontWeight: 400 }}> /máquina</span>
                </p>
              </div>
              <div className="flex items-center gap-3 ml-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setQtyAt(i, qty[i] - 1)}
                  className="w-9 h-9 rounded-full flex items-center justify-center"
                  style={{ background: active ? '#B6F02D' : '#E8E6DC', color: '#141413' }}
                >
                  <Minus size={16} />
                </button>
                <span className="font-poppins font-bold w-5 text-center" style={{ fontSize: '16px', color: active ? '#FFFFFF' : '#141413' }}>
                  {qty[i]}
                </span>
                <button
                  type="button"
                  onClick={() => setQtyAt(i, qty[i] + 1)}
                  className="w-9 h-9 rounded-full flex items-center justify-center"
                  style={{ background: '#B6F02D', color: '#141413' }}
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between mb-2">
        <span className="font-inter" style={{ fontSize: '14px', color: '#72706A' }}>Personas (cupo total)</span>
        <span className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>{totalCapacity}</span>
      </div>
      <div className="flex items-center justify-between mb-2">
        <span className="font-inter" style={{ fontSize: '14px', color: '#72706A' }}>Máquinas</span>
        <span className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>{totalMachines}</span>
      </div>

      {totalMachines > 0 && (
        <p className="font-inter mb-2" style={{ fontSize: '11px', color: '#72706A' }}>
          ¿Necesitas más personas? Agrega otra máquina para ampliar el cupo.
        </p>
      )}

      <div className="flex items-center justify-between py-3" style={{ borderTop: '1px solid #E8E6DC' }}>
        <span className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#141413' }}>Total</span>
        <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>${totalPrice.toFixed(2)}</span>
      </div>

      <button
        type="button"
        onClick={checkout}
        disabled={totalMachines === 0}
        className="btn-primary mt-2"
      >
        {totalMachines === 0 ? 'Selecciona al menos 1 máquina' : 'Reservar'}
      </button>
    </div>
  );
}