import { Check, X, Backpack, Info } from 'lucide-react';

const DEFAULT_INCLUSIONS = [
  'Transporte ida y vuelta desde tu hotel',
  'Guía local experto bilingüe',
  'Bebidas y refrigerios',
  'Todos los impuestos y cargos',
];

const DEFAULT_EXCLUSIONS = [
  'Propinas (opcionales)',
  'Fotografías profesionales',
  'Souvenirs',
];

const DEFAULT_WHAT_TO_BRING = [
  'Ropa cómoda y ligera',
  'Protector solar',
  'Repelente de insectos',
  'Cámara o teléfono con batería cargada',
  'Dinero en efectivo para gastos extras',
];

const DEFAULT_IMPORTANT_INFO = [
  'Confirmación automática al momento de reservar',
  'Cancelación gratuita hasta 24h antes de la actividad',
  'Los horarios de recogida pueden variar según la ubicación de su hotel',
  'Se enviará un recordatorio 24h antes de la actividad',
];

function Section({ title, items, icon: Icon, iconColor, marker = 'check' }) {
  if (!items || items.length === 0) return null;
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={18} color={iconColor} />
        <h2 className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>{title}</h2>
      </div>
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item} className="flex items-start gap-2">
            {marker === 'check' ? (
              <Check size={15} color="#4A7A35" className="mt-0.5 shrink-0" />
            ) : marker === 'cross' ? (
              <X size={15} color="#B91C1C" className="mt-0.5 shrink-0" />
            ) : (
              <span className="mt-1.5 shrink-0" style={{ width: '5px', height: '5px', borderRadius: '50%', background: '#571AFF' }} />
            )}
            <span className="font-inter" style={{ fontSize: '14px', color: '#141413', lineHeight: 1.5 }}>{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function TourInfoSections({ venue }) {
  return (
    <div className="mt-5 space-y-5">
      <Section
        title="Inclusiones"
        items={venue.inclusions?.length ? venue.inclusions : DEFAULT_INCLUSIONS}
        icon={Check}
        iconColor="#4A7A35"
        marker="check"
      />
      <Section
        title="Exclusiones"
        items={venue.exclusions?.length ? venue.exclusions : DEFAULT_EXCLUSIONS}
        icon={X}
        iconColor="#B91C1C"
        marker="cross"
      />
      <Section
        title="Qué traer"
        items={venue.what_to_bring?.length ? venue.what_to_bring : DEFAULT_WHAT_TO_BRING}
        icon={Backpack}
        iconColor="#571AFF"
        marker="dot"
      />
      <Section
        title="Información importante"
        items={venue.important_info?.length ? venue.important_info : DEFAULT_IMPORTANT_INFO}
        icon={Info}
        iconColor="#D97757"
        marker="dot"
      />
    </div>
  );
}