import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function TourPhotoCarousel({ venue, height = 260, children }) {
  const images = [venue.cover_image_url, ...(venue.gallery_images || [])].filter(Boolean);
  const [index, setIndex] = useState(0);
  const total = images.length;

  const go = (dir) => setIndex((i) => (i + dir + total) % total);

  const baseStyle = { height: `${height}px`, background: '#0a0a14' };

  if (total <= 1) {
    return (
      <div className="relative overflow-hidden" style={baseStyle}>
        {images[0] && <img src={images[0]} alt={venue.name} className="absolute inset-0 w-full h-full object-cover" />}
        <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.84) 0%, transparent 60%)' }} />
        {children}
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden" style={baseStyle}>
      <div className="flex h-full transition-transform duration-300 ease-out" style={{ transform: `translateX(-${index * 100}%)` }}>
        {images.map((src, i) => (
          <img key={i} src={src} alt={`${venue.name} ${i + 1}`} className="h-full w-full flex-shrink-0 object-cover" />
        ))}
      </div>
      <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.84) 0%, transparent 60%)' }} />

      <button
        type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); go(-1); }}
        aria-label="Foto anterior"
        className="absolute left-3 top-1/2 z-20 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full transition-transform active:scale-90"
        style={{ background: 'rgba(255,255,255,0.85)' }}
      >
        <ChevronLeft size={18} color="#141413" />
      </button>
      <button
        type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); go(1); }}
        aria-label="Siguiente foto"
        className="absolute right-3 top-1/2 z-20 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full transition-transform active:scale-90"
        style={{ background: 'rgba(255,255,255,0.85)' }}
      >
        <ChevronRight size={18} color="#141413" />
      </button>

      <div className="absolute bottom-3 right-4 z-20 rounded-full px-2.5 py-1 font-inter text-xs font-semibold text-white" style={{ background: 'rgba(14,14,14,0.5)', backdropFilter: 'blur(8px)' }}>
        {index + 1} / {total}
      </div>

      {children}
    </div>
  );
}