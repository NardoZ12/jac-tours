import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Cloud } from 'lucide-react';

const CACHE_KEY = 'roam_brief_cache_v2';

export default function MorningBrief({ user, dealCount = 3, tableCount = 12, eventCount = 5, friendActivity = 2 }) {
  const [brief, setBrief] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const today = new Date().toDateString();
    const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || '{}');
    if (cached.date === today && cached.userId === user?.id && cached.text) {
      setBrief(cached.text);
      setLoading(false);
      return;
    }
    generateBrief();
  }, [user]);

  const generateBrief = async () => {
    setLoading(true);
    const hour = new Date().getHours();
    const timeOfDay = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
    const tasteProfile = user?.taste_profile || {};
    const cuisines = tasteProfile.cuisines?.join(', ') || 'Tel Aviv';
    const city = user?.city || 'Tel Aviv';

    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are Roam. Write ONE punchy sentence (max 10 words) for a ${timeOfDay} brief. User likes ${cuisines} in ${city}. ${dealCount} deals, ${tableCount} tables, ${eventCount} events tonight. Mention the best opportunity. No hashtags, no quotes.`,
      });
      const text = typeof res === 'string' ? res : res?.text || `${dealCount} flash deals near you. Perfect ${timeOfDay} to explore.`;
      setBrief(text);
      localStorage.setItem(CACHE_KEY, JSON.stringify({ date: new Date().toDateString(), userId: user?.id, text }));
    } catch {
      setBrief(`${dealCount} flash deals near you. Great time to explore ${city}.`);
    }
    setLoading(false);
  };

  const stats = [
    { value: dealCount,     label: 'deals' },
    { value: tableCount,    label: 'tables' },
    { value: eventCount,    label: 'tonight' },
    { value: friendActivity, label: 'friends' },
  ];

  return (
    <div className="mx-5 rounded-2xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #2A2342 0%, #1F1B2E 100%)' }}>
      <div className="p-5">
        {/* Top row */}
        <div className="flex items-center justify-between mb-3">
          <span className="font-poppins font-semibold text-white" style={{ fontSize: '12px', letterSpacing: '0.06em', textTransform: 'uppercase', opacity: 0.35 }}>
            Today's brief
          </span>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg" style={{ background: 'rgba(255,255,255,0.1)' }}>
            <Cloud size={12} color="white" />
            <span className="font-poppins font-semibold text-white" style={{ fontSize: '12px' }}>24° {user?.city || 'Tel Aviv'}</span>
          </div>
        </div>

        {/* Headline */}
        {loading ? (
          <div className="space-y-2 mb-4">
            <div className="skeleton h-5 rounded w-full" style={{ background: 'rgba(255,255,255,0.1)' }} />
            <div className="skeleton h-5 rounded w-4/5" style={{ background: 'rgba(255,255,255,0.1)' }} />
          </div>
        ) : (
          <p className="font-poppins font-bold text-white mb-4" style={{ fontSize: '18px', lineHeight: 1.35 }}>
            {brief.split(/(\d+)/).map((part, i) =>
              /^\d+$/.test(part)
                ? <span key={i} style={{ color: '#FFFFFF', fontWeight: 700 }}>{part}</span>
                : part
            )}
          </p>
        )}

        {/* Stat pills */}
        <div className="flex gap-2">
          {stats.map(s => (
            <div key={s.label} className="flex-1 rounded-lg py-1.5 px-2" style={{ background: 'rgba(255,255,255,0.08)' }}>
              <p className="font-poppins font-bold text-white text-center" style={{ fontSize: '14px' }}>{s.value}</p>
              <p className="font-poppins font-light text-white text-center" style={{ fontSize: '12px', opacity: 0.45 }}>{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}