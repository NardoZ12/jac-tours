import { useEffect, useRef, useState } from 'react';
import HotelCardStack from '@/components/today/HotelCardStack';

function GradientText({ text, progress, startIndex, totalChars }) {
  return text.split('').map((char, index) => {
    const revealAt = (startIndex + index) / Math.max(totalChars - 1, 1) * 0.58;
    const fade = Math.min(1, Math.max(0, (progress - revealAt) / 0.28));
    const r = Math.round(26 + (248 - 26) * fade);
    const g = Math.round(26 + (247 - 26) * fade);
    const b = Math.round(26 + (244 - 26) * fade);
    return <span key={`${char}-${index}`} style={{ color: `rgb(${r}, ${g}, ${b})` }}>{char}</span>;
  });
}

export default function HotelVibeSection() {
  const sectionRef = useRef(null);
  const [titleProgress, setTitleProgress] = useState(0);
  const first = 'Choose Your Vibe, ';
  const second = 'Select The Dates ';
  const third = '& Enjoy Your Ultimate ';
  const fourth = 'Getaway';
  const totalChars = first.length + second.length + third.length + fourth.length;
  const bodyFade = Math.min(1, Math.max(0, (titleProgress - 0.12) / 0.28));
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const query = window.matchMedia('(max-width: 767px)');
    const update = () => setIsMobile(query.matches);
    update();
    query.addEventListener('change', update);
    return () => query.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    const onScroll = () => {
      const section = sectionRef.current;
      if (!section) return;
      const rect = section.getBoundingClientRect();
      setTitleProgress(Math.min(1, Math.max(0, -rect.top / (window.innerHeight * 0.9))));
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <section ref={sectionRef} style={{ position: 'relative', background: '#F8F7F4', overflow: 'visible' }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.36, backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px' }} />
      <div style={isMobile ? { position: 'relative', top: 0, minHeight: 'auto', padding: '48px 18px 18px', textAlign: 'center', zIndex: 0 } : { position: 'sticky', top: 0, minHeight: '100vh', padding: '11vh 18px 0', textAlign: 'center', zIndex: 0 }}>
        <h2 className="[font-family:'Libre_Baskerville',_serif] font-normal" style={{ width: isMobile ? '100%' : 'min(94vw, 1320px)', maxWidth: isMobile ? 'calc(100vw - 36px)' : 'none', margin: '0 auto', textAlign: 'center', fontSize: 'clamp(40px, 7.2vw, 112px)', lineHeight: 1.08, letterSpacing: '-0.06em', color: '#1A1A1A' }}>
          <GradientText text={first} progress={titleProgress} startIndex={0} totalChars={totalChars} /><GradientText text={second} progress={titleProgress} startIndex={first.length} totalChars={totalChars} /><GradientText text={third} progress={titleProgress} startIndex={first.length + second.length} totalChars={totalChars} /><GradientText text={fourth} progress={titleProgress} startIndex={first.length + second.length + third.length} totalChars={totalChars} />
        </h2>
        <p style={{ maxWidth: '420px', margin: '22px auto 0', color: '#8A8780', fontFamily: 'Inter, sans-serif', fontSize: '14px', lineHeight: 1.6, opacity: 1 - bodyFade, transition: 'opacity 120ms linear' }}>
          Pick a stay that matches your mood, from quiet design hotels to rooftop city escapes.
        </p>
      </div>
      <HotelCardStack />
    </section>);

}