import { motion } from 'framer-motion';
import { Users, Waves, Mountain, Car, Fish, Anchor } from 'lucide-react';

const PRICES = [
  { name: 'Isla Saona', price: 55, unit: 'US por persona', icon: Waves },
  { name: 'Santo Domingo', price: 54, unit: 'US por persona', icon: Mountain },
  { name: 'La Hacienda', price: 99, unit: 'US por persona', icon: Anchor },
  { name: 'Isla Catalina', price: 59, unit: 'US por persona', icon: Waves },
  { name: 'Buggies', price: 35, unit: 'US por persona', icon: Car },
  { name: 'Party Boat', price: 50, unit: 'US por persona (mín. 2 personas)', icon: Anchor },
  { name: 'Isla Saona VIP 4 Playas', price: 85, unit: 'US por persona', icon: Waves },
  { name: 'Santo Domingo Privado', price: 350, unit: 'US (mín. 2 pax, +30 US c/u extra)', icon: Mountain },
  { name: 'Higüey City', price: 110, unit: 'US · 1–7 pax / 8–14: 170 / 15–24: 250 / 25–49: 350', icon: Car },
  { name: 'Catalina Buceo', price: 98, unit: 'US por persona', icon: Waves },
  { name: 'ATV 4WD', price: 49, unit: 'US por persona', icon: Car },
  { name: 'Pesca', price: 95, unit: 'US por persona', icon: Fish },
  { name: 'Samaná', price: 90, unit: 'US por persona', icon: Mountain },
];

export default function PriceList() {
  return (
    <section className="relative w-full" style={{ background: '#F8F7F4', padding: '48px 0 56px' }}>
      <div className="mx-auto max-w-5xl px-5">
        <div className="text-center mb-8">
          <h2 className="font-poppins text-roam-text" style={{ fontSize: '30px', letterSpacing: '-0.02em' }}>
            Lista de Precios
          </h2>
          <p className="font-inter mt-2 text-roam-muted" style={{ fontSize: '13px' }}>
            Tarifas por persona en dólares estadounidenses (US$)
          </p>
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
          {PRICES.map(({ name, price, unit, icon: Icon }, i) => (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.4, delay: (i % 4) * 0.05, ease: 'easeOut' }}
              className="flex items-center gap-4 rounded-2xl bg-white px-4 py-3.5"
              style={{ boxShadow: '0 2px 12px rgba(14,14,14,0.05)', border: '1px solid rgba(14,14,14,0.04)' }}
            >
              <div className="flex items-center justify-center shrink-0 rounded-xl" style={{ width: '44px', height: '44px', background: '#F2F1EE' }}>
                <Icon size={20} color="#571AFF" strokeWidth={2} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-inter font-semibold text-roam-text truncate" style={{ fontSize: '14px' }}>{name}</p>
                <p className="font-inter text-roam-muted mt-0.5" style={{ fontSize: '11px', lineHeight: 1.4 }}>{unit}</p>
              </div>
              <div className="text-right shrink-0">
                <span className="font-poppins font-bold text-roam-text" style={{ fontSize: '20px' }}>${price}</span>
              </div>
            </motion.div>
          ))}
        </div>

        <p className="font-inter text-center mt-6 text-roam-muted" style={{ fontSize: '11px' }}>
          Los precios pueden variar según la temporada y disponibilidad. Cotiza por WhatsApp para confirmar.
        </p>
      </div>
    </section>
  );
}