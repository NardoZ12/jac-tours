import { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import MobileRestaurantStack from '@/components/today/MobileRestaurantStack';

const RESTAURANTS = [
  { id: 1,  name: 'Volta',           cuisine: 'Modern European',  neighborhood: 'Innenstadt',       rating: 4.8, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/1a15661db_generated_image.png' },
  { id: 2,  name: 'Roux',            cuisine: 'French Bistro',    neighborhood: 'Maximilianstraße', rating: 4.6, price: '€€',   image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/d24fa3ce0_generated_image.png' },
  { id: 3,  name: 'Aura',            cuisine: 'Japanese Fusion',  neighborhood: 'Altstadt',         rating: 4.9, price: '€€€€', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/3a534eadd_generated_image.png' },
  { id: 4,  name: 'Garbo',           cuisine: 'Mediterranean',    neighborhood: 'Rathausplatz',     rating: 4.5, price: '€€',   image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/81c4f22a7_generated_image.png' },
  { id: 5,  name: 'Kōan',            cuisine: 'Plant-Based',      neighborhood: 'Dom Viertel',      rating: 4.7, price: '€€',   image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/156e426ad_generated_image.png' },
  { id: 6,  name: 'Ember',           cuisine: 'Steakhouse',       neighborhood: 'Fuggerei',         rating: 4.4, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/6202de4c6_generated_image.png' },
  { id: 7,  name: 'Silo',            cuisine: 'Farm-to-Table',    neighborhood: 'Stadtmarkt',       rating: 4.8, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/0fc4bc084_generated_image.png' },
  { id: 8,  name: 'Lagom',           cuisine: 'Scandinavian',     neighborhood: 'Jakobervorstadt',  rating: 4.6, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/34d67e71b_generated_image.png' },
  { id: 9,  name: 'Noma Sud',        cuisine: 'New Nordic',       neighborhood: 'Maxfeld',          rating: 4.9, price: '€€€€', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/fc30ce4b9_generated_image.png' },
  { id: 10, name: 'Canteen No. 7',   cuisine: 'Izakaya',          neighborhood: 'Haunstetten',      rating: 4.5, price: '€€',   image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/6e17adfa5_generated_image.png' },
  { id: 11, name: 'Terroir',         cuisine: 'Wine & Tapas',     neighborhood: 'Pfersee',          rating: 4.7, price: '€€',   image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/5f8ff3a94_generated_image.png' },
  { id: 12, name: 'Pollen',          cuisine: 'Botanical',        neighborhood: 'Kriegshaber',      rating: 4.6, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/f05dd9c8d_generated_image.png' },
  { id: 13, name: 'Soot',            cuisine: 'BBQ & Smoke',      neighborhood: 'Oberhausen',       rating: 4.4, price: '€€',   image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/2326a5c38_generated_image.png' },
  { id: 14, name: 'Velvet Room',     cuisine: 'Cocktail Kitchen', neighborhood: 'Lechhausen',       rating: 4.8, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/795fe08b0_generated_image.png' },
  { id: 15, name: 'Granary',         cuisine: 'Artisan Brunch',   neighborhood: 'Innenstadt',       rating: 4.5, price: '€',    image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/5122a2c3f_generated_image.png' },
  { id: 16, name: 'Faro',            cuisine: 'Coastal Italian',  neighborhood: 'Rathausplatz',     rating: 4.7, price: '€€€',  image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/60081db17_generated_image.png' },
];

function WheelCard({ restaurant, index, rotation }) {
  const angle = index * (360 / RESTAURANTS.length) - rotation;
  const radians = angle * Math.PI / 180;
  const depth = 280 * Math.cos(radians);
  const y = 330 * Math.sin(radians);
  const x = index % 2 === 0 ? -64 : 64;
  const face = Math.max(0, Math.cos(radians));
  const opacity = Math.max(0.18, 0.28 + face * 0.72);
  const scale = 0.72 + face * 0.34;
  const blur = face < 0.12 ? 3 : face < 0.36 ? 1.5 : 0;

  return (
    <div
      style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        width: '118px',
        height: '147.5px',
        marginLeft: '-59px',
        marginTop: '-73.75px',
        borderRadius: '8px',
        overflow: 'hidden',
        background: '#111',
        transform: `translate3d(${x}px, ${y}px, ${depth}px) rotateX(${-angle}deg) rotateY(${x < 0 ? 8 : -8}deg) scale(${scale})`,
        transformStyle: 'preserve-3d',
        opacity,
        filter: `blur(${blur}px)`,
        boxShadow: 'none',
        transition: 'filter 120ms linear, opacity 120ms linear',
        willChange: 'transform, opacity, filter',
      }}
    >
      <img
        src={restaurant.image}
        alt={restaurant.name}
        style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
      />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(255,255,255,0.08), transparent 38%, rgba(0,0,0,0.34))' }} />

    </div>
  );
}

export default function HighlightedRestaurants() {
  const sectionRef = useRef(null);
  const [rotation, setRotation] = useState(0);
  const [hoveredButton, setHoveredButton] = useState(null);
  const [isViewAllHovered, setIsViewAllHovered] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const query = window.matchMedia('(max-width: 767px)');
    const update = () => setIsMobile(query.matches);
    update();
    query.addEventListener('change', update);
    return () => query.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    if (isMobile) return;
    let frame = null;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const section = sectionRef.current;
        if (!section) return;
        const rect = section.getBoundingClientRect();
        const revealOffset = window.innerHeight;
        const max = Math.max(1, section.offsetHeight - window.innerHeight - revealOffset);
        const progress = Math.min(1, Math.max(0, (-rect.top - revealOffset) / max));
        setRotation(progress * 520);
        frame = null;
      });
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [isMobile]);


  const activeIndex = Math.round((rotation / 520) * (RESTAURANTS.length - 1));
  const restaurantAt = (offset) => RESTAURANTS[(activeIndex + offset + RESTAURANTS.length) % RESTAURANTS.length];
  const activeRestaurant = restaurantAt(0);
  const activeAddress = `${12 + activeRestaurant.id * 3} ${activeRestaurant.neighborhood} Gasse, Augsburg`;
  const activeStars = '★★★★★';
  const activePlace = { id: `home-restaurant-${activeRestaurant.name.toLowerCase().replace(/\s+/g, '-')}`, name: activeRestaurant.name, category: 'restaurant', cover_image_url: activeRestaurant.image, neighborhood: activeRestaurant.neighborhood, address: activeAddress, avg_rating: activeRestaurant.rating, price: activeRestaurant.price, short_description: `${activeRestaurant.cuisine} in ${activeRestaurant.neighborhood}.`, cuisine_tags: [activeRestaurant.cuisine] };
  const introProgress = Math.min(1, Math.max(0, rotation / 140));
  const titleOpacity = 1 - introProgress;
  const galleryOpacity = Math.min(1, Math.max(0, (introProgress - 0.86) / 0.14));

  const scrollToRestaurant = (index) => {
    const section = sectionRef.current;
    if (!section) return;
    const sectionTop = window.scrollY + section.getBoundingClientRect().top;
    const revealOffset = window.innerHeight;
    const max = Math.max(1, section.offsetHeight - window.innerHeight - revealOffset);
    const progress = Math.min(1, Math.max(0, index / (RESTAURANTS.length - 1)));
    window.scrollTo({ top: sectionTop + revealOffset + max * progress, behavior: 'smooth' });
  };

  const renderNameAnchor = (offset) => {
    const restaurant = restaurantAt(offset);
    const isActive = offset === 0;
    const targetIndex = (activeIndex + offset + RESTAURANTS.length) % RESTAURANTS.length;
    return (
      <button
        key={offset}
        type="button"
        onClick={() => scrollToRestaurant(targetIndex)}
        style={{
          color: isActive ? '#FFFFFF' : 'rgba(255,255,255,0.32)',
          background: 'transparent',
          border: 0,
          padding: '6px 0',
          font: 'inherit',
          letterSpacing: 'inherit',
          cursor: 'pointer',
          transition: 'color 180ms ease, transform 180ms ease',
          transform: isActive ? 'scale(1)' : 'scale(0.98)',
          pointerEvents: 'auto'
        }}>
        {restaurant.name}
      </button>
    );
  };

  if (isMobile) {
    return <MobileRestaurantStack restaurants={RESTAURANTS.slice(0, 6)} />;
  }

  return (
    <section ref={sectionRef} style={{ height: '460vh', marginTop: '-100vh', background: '#4D61FF', position: 'relative' }}>
      <canvas
        key="restaurant-grain-full-section"
        ref={(el) => {
          if (!el || el._grainInit) return;
          el._grainInit = true;
          const ctx = el.getContext('2d');
          let W = 0;
          let H = 0;

          const resize = () => {
            W = Math.max(1, Math.ceil(window.innerWidth));
            H = Math.max(1, Math.ceil(window.innerHeight));
            el.width = W;
            el.height = H;
          };

          const animate = () => {
            const nextW = Math.max(1, Math.ceil(window.innerWidth));
            const nextH = Math.max(1, Math.ceil(window.innerHeight));
            if (nextW !== W || nextH !== H) {
              W = nextW;
              H = nextH;
              el.width = W;
              el.height = H;
            }

            const img = ctx.createImageData(W, H);
            const d = img.data;
            for (let i = 0; i < d.length; i += 4) {
              const v = Math.random() * 255 | 0;
              d[i] = d[i + 1] = d[i + 2] = v;
              d[i + 3] = 28;
            }
            ctx.putImageData(img, 0, 0);
            requestAnimationFrame(animate);
          };

          resize();
          window.addEventListener('resize', resize);
          requestAnimationFrame(animate);
        }}
        style={{ position: 'sticky', top: 0, display: 'block', width: '100%', height: '100vh', marginBottom: '-100vh', mixBlendMode: 'overlay', pointerEvents: 'none', zIndex: 6, imageRendering: 'auto', filter: 'none' }} />
      <div style={{ position: 'sticky', top: 0, height: '100vh', marginBottom: '-100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '24px', background: '#4D61FF', opacity: titleOpacity, transition: 'opacity 120ms linear', zIndex: 8, pointerEvents: titleOpacity > 0.05 ? 'auto' : 'none' }}>
        <h2 style={{ color: '#FFFFFF', fontFamily: 'Libre Baskerville, serif', fontWeight: 400, fontSize: 'clamp(46px, 7vw, 104px)', lineHeight: 1.02, letterSpacing: '-0.055em', textTransform: 'none', textAlign: 'center' }}>Highlighted Restaurants</h2>
        <a href="/eat" onMouseEnter={() => setIsViewAllHovered(true)} onMouseLeave={() => setIsViewAllHovered(false)} style={{ height: '44px', padding: '0 24px', borderRadius: '999px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: isViewAllHovered ? '#0E0E0E' : '#FFFFFF', color: isViewAllHovered ? '#FFFFFF' : '#141413', fontFamily: 'Inter, sans-serif', fontSize: '13px', fontWeight: 600, letterSpacing: '0.02em', textDecoration: 'none', boxShadow: isViewAllHovered ? '0 10px 22px rgba(14,14,14,0.20)' : '0 0 0 rgba(0,0,0,0)', transition: 'background 180ms ease, color 180ms ease, box-shadow 180ms ease', cursor: 'pointer' }}>View All</a>
      </div>
      <div style={{ position: 'sticky', top: 0, left: 0, right: 0, height: '100vh', width: '100%', perspective: '1050px', perspectiveOrigin: '50% 50%', zIndex: 7, pointerEvents: galleryOpacity > 0.05 ? 'auto' : 'none' }}>
        <div
          style={{
            position: 'absolute',
            left: '50%',
            top: '50%',
            width: '1px',
            height: '1px',
            transformStyle: 'preserve-3d',
            transform: 'translate(-50%, -50%) rotateX(0deg)',
            opacity: galleryOpacity,
            transition: 'opacity 220ms ease',
          }}
        >
          {RESTAURANTS.map((restaurant, index) => (
            <WheelCard key={restaurant.id} restaurant={restaurant} index={index} rotation={rotation} />
          ))}
        </div>

        <div style={{ position: 'absolute', left: 0, right: 0, top: '50%', transform: 'translateY(-50%)', opacity: galleryOpacity, transition: 'opacity 220ms ease', pointerEvents: galleryOpacity > 0.05 ? 'auto' : 'none', whiteSpace: 'nowrap', overflow: 'visible', clipPath: 'inset(-40px 0 -40px 0)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '34px', fontFamily: 'Inter, sans-serif', fontSize: 'clamp(18px, 2.6vw, 34px)', letterSpacing: '-0.02em', textTransform: 'none', color: 'rgba(255,255,255,0.32)', transition: 'transform 0.55s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.55s ease', willChange: 'transform, opacity' }}>
            {renderNameAnchor(-2)}
            {renderNameAnchor(-1)}
            {renderNameAnchor(0)}
            {renderNameAnchor(1)}
            {renderNameAnchor(2)}
          </div>
        </div>

        <div style={{ position: 'absolute', left: '50%', bottom: '9vh', transform: 'translateX(-50%)', minWidth: '330px', padding: '16px', borderRadius: '28px', background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.16)', backdropFilter: 'blur(18px)', WebkitBackdropFilter: 'blur(18px)', color: '#FFFFFF', fontFamily: 'Inter, sans-serif', textAlign: 'center', opacity: galleryOpacity, transition: 'opacity 220ms ease', pointerEvents: galleryOpacity > 0.05 ? 'auto' : 'none', boxShadow: '0 18px 48px rgba(0,0,0,0.35)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '8px' }}>
            <div style={{ flex: 1, minWidth: 0, fontSize: '12px', letterSpacing: '0.04em', color: 'rgba(255,255,255,0.56)', textAlign: 'center', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{activeAddress}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '14px', fontSize: '13px', color: 'rgba(255,255,255,0.86)' }}>
            <span className="font-neue" style={{ fontSize: '13px', color: '#FFFFFF' }}>{activeRestaurant.price}</span>
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', background: 'rgba(255,255,255,0.35)' }} />
            <span style={{ color: '#F7D774', letterSpacing: '0.08em' }}>{activeStars}</span>
            <span>{activeRestaurant.rating.toFixed(1)}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '12px' }}>
            <Link
              to={`/place/${activePlace.id}#book-now`}
              state={{ venue: activePlace }}
              onMouseEnter={() => setHoveredButton('book')}
              onMouseLeave={() => setHoveredButton(null)}
              style={{ flex: 1, height: '38px', padding: '0 14px', borderRadius: '999px', border: hoveredButton === 'book' ? '1px solid #0E0E0E' : '1px solid rgba(255,255,255,0.28)', background: hoveredButton === 'book' ? '#0E0E0E' : '#FFFFFF', color: hoveredButton === 'book' ? '#FFFFFF' : '#000000', fontFamily: 'Inter, sans-serif', fontSize: '12px', fontWeight: 600, letterSpacing: '0.01em', textTransform: 'none', textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: hoveredButton === 'book' ? 'translateY(-2px) scale(1.03)' : 'translateY(0) scale(1)', boxShadow: hoveredButton === 'book' ? '0 12px 28px rgba(14,14,14,0.28)' : '0 0 0 rgba(0,0,0,0)', transition: 'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 220ms ease, background 220ms ease, border 220ms ease, color 220ms ease' }}>
              Book a Table
            </Link>
            <Link
              to={`/place/${activePlace.id}`}
              state={{ venue: activePlace }}
              onMouseEnter={() => setHoveredButton('learn')}
              onMouseLeave={() => setHoveredButton(null)}
              style={{ flex: 1, height: '38px', padding: '0 14px', borderRadius: '999px', border: hoveredButton === 'learn' ? '1px solid #0E0E0E' : '1px solid rgba(255,255,255,0.26)', background: hoveredButton === 'learn' ? '#0E0E0E' : 'rgba(255,255,255,0.08)', color: '#FFFFFF', fontFamily: 'Inter, sans-serif', fontSize: '12px', fontWeight: 500, letterSpacing: '0.01em', textTransform: 'none', textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', transform: hoveredButton === 'learn' ? 'translateY(-2px) scale(1.03)' : 'translateY(0) scale(1)', boxShadow: hoveredButton === 'learn' ? '0 12px 28px rgba(14,14,14,0.28)' : '0 0 0 rgba(0,0,0,0)', transition: 'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 220ms ease, background 220ms ease, border 220ms ease' }}>
              Learn More
            </Link>
          </div>
        </div>

      </div>
    </section>
  );
}