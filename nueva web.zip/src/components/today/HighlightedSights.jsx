import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Star } from 'lucide-react';
import HeartButton from '@/components/ui/HeartButton';

const SIGHTS = [
  { name: 'Fuggerei', note: 'Historic Courtyards', area: 'Jakobervorstadt', rating: '4.9', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/4e649fb80_generated_image.png' },
  { name: 'Rathausplatz', note: 'Old Town Square', area: 'Innenstadt', rating: '4.8', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ea2badbb4_generated_image.png' },
  { name: 'Augsburg Cathedral', note: 'Quiet Gothic Stop', area: 'Domviertel', rating: '4.7', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/c78d211ba_generated_image.png' },
  { name: 'Perlachturm', note: 'City Lookout', area: 'Rathausplatz', rating: '4.8', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/af93d794c_generated_image.png' },
  { name: 'Lech Canals', note: 'Waterfront Walk', area: 'Altstadt', rating: '4.6', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/8aefdd1c3_generated_image.png' },
  { name: 'Schaezlerpalais', note: 'Baroque Gallery', area: 'Maximilianstraße', rating: '4.7', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/9406a8127_generated_image.png' },
];

export default function HighlightedSights() {
  const sectionRef = useRef(null);
  const [moreHovered, setMoreHovered] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0.5);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const query = window.matchMedia('(max-width: 767px)');
    const update = () => setIsMobile(query.matches);
    update();
    query.addEventListener('change', update);
    return () => query.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    if (isMobile) return;
    let frame = null;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const section = sectionRef.current;
        if (!section) return;
        const rect = section.getBoundingClientRect();
        const total = window.innerHeight + rect.height;
        const progress = Math.min(1, Math.max(0, (window.innerHeight - rect.top) / total));
        setScrollProgress(progress);
        frame = null;
      });
    };

    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [isMobile]);

  return (
    <section ref={sectionRef} className="relative overflow-visible" style={{ marginLeft: 'calc(50% - 50vw)', width: '100vw', background: '#F8F7F4', padding: '18vh 18px 0', zIndex: 1 }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.36, backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'linear-gradient(to bottom, #000 0%, #000 54%, rgba(0,0,0,0.38) 76%, transparent 100%)', maskImage: 'linear-gradient(to bottom, #000 0%, #000 54%, rgba(0,0,0,0.38) 76%, transparent 100%)' }} />
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', filter: 'blur(48px)', opacity: 0.54, background: 'radial-gradient(circle at 24% 48%, rgba(83, 104, 255, 0.24), transparent 18%), radial-gradient(circle at 74% 36%, rgba(176, 190, 77, 0.36), transparent 20%), radial-gradient(circle at 50% 74%, rgba(42, 107, 58, 0.18), transparent 18%)', WebkitMaskImage: 'linear-gradient(to bottom, #000 0%, #000 60%, rgba(0,0,0,0.28) 82%, transparent 100%)', maskImage: 'linear-gradient(to bottom, #000 0%, #000 60%, rgba(0,0,0,0.28) 82%, transparent 100%)' }} />
      <div style={{ position: 'absolute', inset: 'auto 0 0', height: '36vh', pointerEvents: 'none', background: 'linear-gradient(to bottom, rgba(248,247,244,0), #F8F7F4 86%)' }} />

      <div className="relative mx-auto text-center" style={{ maxWidth: '820px' }}>
        <h2 className="[font-family:'Libre_Baskerville',_serif] font-normal" style={{ fontSize: 'clamp(42px, 6.5vw, 86px)', lineHeight: 1.05, letterSpacing: '-0.055em', color: '#1A1A1A' }}>
          Highlighted Sights
        </h2>
        <p className="font-neue mx-auto mt-4" style={{ maxWidth: '390px', color: '#8A8780', fontSize: '14px', lineHeight: 1.6 }}>
          Six calm stops for a scenic Augsburg route between meals, stays, and evening plans.
        </p>
      </div>

      <div className="relative mx-auto mt-16 grid gap-5 md:grid-cols-3" style={{ maxWidth: '1120px' }}>
        {SIGHTS.map((sight, index) => {
          const savedSight = { id: `home-sight-${sight.name.toLowerCase().replace(/\s+/g, '-')}`, name: sight.name, category: 'experience', cover_image_url: sight.image, neighborhood: sight.area, avg_rating: Number(sight.rating), short_description: sight.note };
          const parallaxY = isMobile ? 0 : (0.5 - scrollProgress) * (120 + (index % 3) * 22);
          return (
          <Link key={sight.name} to={`/place/${savedSight.id}`} state={{ venue: savedSight }} className="group h-full overflow-visible">
            <article className="relative aspect-square overflow-hidden rounded-[24px] bg-[#181818] transition-transform duration-300 ease-out group-hover:-translate-y-1" style={{ boxShadow: '0 18px 44px rgba(14,14,14,0.10)' }}>
              <div className="absolute inset-x-0 -inset-y-[16%] transition-transform duration-100 ease-linear" style={{ transform: `translateY(${parallaxY}px)` }}>
                <img src={sight.image} alt={sight.name} loading="lazy" className="h-full w-full object-cover transition-all duration-300 ease-out group-hover:scale-[1.06] group-hover:brightness-75" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/[0.96]" />
              <div className="absolute left-4 top-4 z-10"><HeartButton venue={savedSight} /></div>
              <div className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5 text-roam-text">
                <Star size={13} fill="#0E0E0E" />
                <span className="font-inter text-xs font-bold">{sight.rating}</span>
              </div>
              <div className="absolute bottom-[-30px] left-[18px] right-[18px] font-inter text-white transition-transform duration-300 ease-out group-hover:-translate-y-12">
                <h3 className="m-0 font-inter text-[18px] font-medium leading-tight tracking-[-0.03em] text-white">{sight.name}</h3>
                <p className="mt-2 flex items-center justify-between gap-3 text-xs text-white/70">
                  <span className="flex min-w-0 items-center gap-1 truncate"><MapPin size={13} className="shrink-0" />{sight.area}</span>
                  <span className="shrink-0">{sight.note}</span>
                </p>
                <div className="mt-3 translate-y-4 opacity-0 transition-all duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100">
                  <span className="flex h-9 w-full items-center justify-center rounded-full bg-[#571AFF] text-xs font-bold text-white shadow-[0_12px_28px_rgba(87,26,255,0.28)]">Learn More</span>
                </div>
              </div>
            </article>
          </Link>
          );
        })}
      </div>

      <div className="relative z-10 flex justify-center mt-8">
        <Link
          to="/do"
          className="font-neue"
          onMouseEnter={() => setMoreHovered(true)}
          onMouseLeave={() => setMoreHovered(false)}
          style={{ height: '46px', padding: '0 24px', borderRadius: '999px', background: moreHovered ? '#571AFF' : '#111111', color: '#FFFFFF', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: 700, letterSpacing: '0.01em', textDecoration: 'none', transform: moreHovered ? 'translateY(-3px) scale(1.04)' : 'translateY(0) scale(1)', boxShadow: moreHovered ? '0 18px 34px rgba(87,26,255,0.34)' : '0 0 0 rgba(0,0,0,0)', transition: 'transform 220ms cubic-bezier(0.22, 1, 0.36, 1), background 220ms ease, box-shadow 220ms ease' }}>
          More Things to Do
        </Link>
      </div>
    </section>
  );
}