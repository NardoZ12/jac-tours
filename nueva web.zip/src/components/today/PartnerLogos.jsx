import { motion } from 'framer-motion';

/* Logos reales de las OTAS socias, mostrados en tarjetas blancas
   uniformes sobre el fondo de la página. */

const LOGOS = [
  { src: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/f219d5658_logo-viator.png', alt: 'Viator', bg: '#FFFFFF' },
  { src: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/912004661_logo-tripadvisor.jpg', alt: 'Tripadvisor', bg: '#FFFFFF' },
  { src: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/1c3cebf19_logo-klook.png', alt: 'Klook', bg: '#FFFFFF' },
  { src: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/f98b1e407_gyg-logo.png', alt: 'GetYourGuide', bg: '#FFFFFF' },
];

function LogoTile({ src, alt, bg }) {
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-2xl"
      style={{
        background: bg,
        width: '150px',
        height: '84px',
        padding: '14px',
        boxShadow: '0 2px 10px rgba(14,14,14,0.06)',
        border: '1px solid rgba(14,14,14,0.05)',
      }}
    >
      <img src={src} alt={alt} loading="lazy" style={{ maxHeight: '52px', maxWidth: '100%', objectFit: 'contain' }} />
    </div>
  );
}

export default function PartnerLogos() {
  const row = [...LOGOS, ...LOGOS];
  return (
    <section className="relative w-full" style={{ background: '#F2F1EE', padding: '40px 0 52px' }}>
      <div className="mx-auto max-w-7xl px-5 text-center">
        <p className="font-poppins text-roam-text" style={{ fontSize: '22px', letterSpacing: '-0.02em' }}>
          Trabajamos con las mejores plataformas
        </p>
        <p className="font-inter mt-2 text-roam-muted" style={{ fontSize: '13px' }}>
          Reserva nuestros tours y traslados a través de tus OTAs de confianza
        </p>
      </div>
      <div className="relative mt-7 overflow-hidden" style={{ maskImage: 'linear-gradient(90deg, transparent, #000 10%, #000 90%, transparent)', WebkitMaskImage: 'linear-gradient(90deg, transparent, #000 10%, #000 90%, transparent)' }}>
        <motion.div
          className="flex w-max items-center gap-5"
          animate={{ x: ['0%', '-50%'] }}
          transition={{ duration: 24, repeat: Infinity, ease: 'linear' }}
        >
          {row.map((logo, i) => (
            <LogoTile key={i} {...logo} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}