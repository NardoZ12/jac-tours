import { useEffect, useRef } from 'react';
import RestaurantShowcaseCard from '@/components/eat/RestaurantShowcaseCard';

const HEADER_OFFSET = 88;
const CARD_STEP = 620;

function toPlace(restaurant) {
  return {
    id: `home-restaurant-${restaurant.name.toLowerCase().replace(/\s+/g, '-')}`,
    name: restaurant.name,
    category: 'eat',
    sub_category: restaurant.cuisine,
    cover_image_url: restaurant.image,
    neighborhood: restaurant.neighborhood,
    avg_rating: restaurant.rating,
    price_range: Math.min(4, Math.max(1, restaurant.price.length)),
    short_description: `${restaurant.cuisine} in ${restaurant.neighborhood}.`,
    cuisine_tags: [restaurant.cuisine]
  };
}

export default function MobileRestaurantStack({ restaurants = [] }) {
  const trackRef = useRef(null);
  const stackRef = useRef(null);
  const cardRefs = useRef([]);
  const rafRef = useRef(null);
  const targetProgressRef = useRef(0);
  const renderedProgressRef = useRef(0);
  const phaseRef = useRef('before');

  useEffect(() => {
    const applyStack = () => {
      const stack = stackRef.current;
      if (!stack) return;
      const phase = phaseRef.current;
      stack.style.position = phase === 'active' ? 'fixed' : 'absolute';
      stack.style.top = phase === 'after' ? 'auto' : phase === 'active' ? `${HEADER_OFFSET}px` : '0px';
      stack.style.bottom = phase === 'after' ? '-11vh' : 'auto';
      stack.style.left = phase === 'active' ? '18px' : '0px';
      stack.style.right = phase === 'active' ? '18px' : '0px';
    };

    const applyCards = (progress) => {
      const cardProgress = progress * Math.max(0, restaurants.length - 1);
      cardRefs.current.forEach((card, index) => {
        if (!card) return;
        const offset = index - cardProgress;
        const y = Math.max(0, offset * CARD_STEP);
        card.style.transform = `translate3d(0, ${y}px, 0)`;
        card.style.pointerEvents = offset <= 0.25 ? 'auto' : 'none';
      });
    };

    const animate = () => {
      const target = targetProgressRef.current;
      const current = renderedProgressRef.current;
      const next = Math.abs(target - current) < 0.001 ? target : current + (target - current) * 0.22;
      renderedProgressRef.current = next;
      applyStack();
      applyCards(next);
      if (next !== target) {
        rafRef.current = requestAnimationFrame(animate);
      } else {
        rafRef.current = null;
      }
    };

    const update = () => {
      const track = trackRef.current;
      if (!track) return;
      const rect = track.getBoundingClientRect();
      const scrollable = Math.max(1, track.offsetHeight - window.innerHeight + HEADER_OFFSET);
      targetProgressRef.current = Math.min(1, Math.max(0, (HEADER_OFFSET - rect.top) / scrollable));
      phaseRef.current = rect.top > HEADER_OFFSET ? 'before' : rect.bottom <= window.innerHeight ? 'after' : 'active';
      if (!rafRef.current) rafRef.current = requestAnimationFrame(animate);
    };

    applyCards(0);
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    return () => {
      window.removeEventListener('scroll', update);
      window.removeEventListener('resize', update);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [restaurants.length]);

  return (
    <section className="mobile-restaurant-stack" style={{ background: '#4D61FF', padding: '56px 18px 0', position: 'relative' }}>
      <h2 style={{ color: '#FFFFFF', fontFamily: 'Libre Baskerville, serif', fontWeight: 400, fontSize: '42px', lineHeight: 1.04, letterSpacing: '-0.055em', textAlign: 'center', marginBottom: '28px' }}>
        Highlighted Restaurants
      </h2>

      <div ref={trackRef} style={{ height: `${Math.max(1, restaurants.length * 74 - 48)}vh`, position: 'relative' }}>
        <div ref={stackRef} style={{ position: 'absolute', top: 0, left: 0, right: 0, height: `calc(100vh - ${HEADER_OFFSET}px)`, overflow: 'visible', zIndex: 2 }}>
          {restaurants.map((restaurant, index) => (
            <div
              key={restaurant.id}
              ref={(el) => { cardRefs.current[index] = el; }}
              style={{ position: 'absolute', inset: '0 0 auto 0', zIndex: index + 1, transform: `translate3d(0, ${index * CARD_STEP}px, 0)`, willChange: 'transform' }}
            >
              <RestaurantShowcaseCard venue={toPlace(restaurant)} frameless />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}