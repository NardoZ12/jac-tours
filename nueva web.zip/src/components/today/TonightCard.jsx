import { Link } from 'react-router-dom';
import VerticalBadge from '../ui/VerticalBadge';
import VenuePhoto from '../ui/VenuePhoto';

export default function TonightCard({ venue }) {
  const path = venue.category === 'hotel' ? `/stay/${venue.id}`
             : venue.category === 'experience' ? `/do/${venue.id}`
             : `/eat/${venue.id}`;
  const type = venue.category === 'hotel' ? 'stay' : venue.category === 'experience' ? 'do' : 'eat';
  const slots = ((venue.id?.charCodeAt(0) || 4) % 6) + 1;

  return (
    <Link to={path}>
      <div className="mx-5 rounded-[18px] overflow-hidden card-shadow bg-white">
        <VenuePhoto venue={venue} height={160} rounded="0">
          {/* Top badges */}
          <div className="absolute top-3 left-3 flex items-center gap-2 z-10">
            <VerticalBadge type={type} />
            {venue.vibe_tags?.[0] && (
              <span
                className="font-poppins font-semibold text-white"
                style={{ fontSize: '12px', letterSpacing: '0.04em', background: 'rgba(255,255,255,0.18)', backdropFilter: 'blur(6px)', padding: '3px 8px', borderRadius: '8px' }}
              >
                {venue.vibe_tags[0]}
              </span>
            )}
          </div>

          {/* Bottom content */}
          <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
            <p className="font-poppins font-bold text-white" style={{ fontSize: '17px' }}>{venue.name}</p>
            <p className="font-inter italic text-white mb-3" style={{ fontSize: '12px', opacity: 0.8 }}>{venue.short_description || venue.sub_category}</p>

            <div className="flex items-center justify-between">
              <div>
                <span className="font-neue" style={{ fontSize: '13px', color: '#FFFFFF' }}>
                  {'€'.repeat(venue.price_range || 2)}
                </span>
                <span className="font-inter text-white ml-1" style={{ fontSize: '12px', opacity: 0.7 }}>per person</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <span className="pulse-dot" style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#16A34A', display: 'inline-block' }} />
                  <span className="font-poppins font-semibold text-white" style={{ fontSize: '12px', opacity: 0.85 }}>{slots} slots</span>
                </div>
                <div
                  className="font-poppins font-semibold text-white"
                  style={{ fontSize: '12px', padding: '5px 12px', borderRadius: '8px', background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}
                >
                  Book →
                </div>
              </div>
            </div>
          </div>
        </VenuePhoto>
      </div>
    </Link>
  );
}