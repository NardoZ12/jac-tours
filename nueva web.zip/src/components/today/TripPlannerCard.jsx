import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarDays, MapPinned, Search, Users } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';

const formatDate = (isoDate) => {
  if (!isoDate) return '';
  const [year, month, day] = isoDate.split('-');
  return `${day}/${month}/${year}`;
};
const dateToIso = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export default function TripPlannerCard() {
  const navigate = useNavigate();
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [dateRange, setDateRange] = useState(undefined);
  const [people, setPeople] = useState(2);
  const [activityType, setActivityType] = useState('Tours');
  const [dateOpen, setDateOpen] = useState(false);
  const [compactProgress, setCompactProgress] = useState(0);
  const [isHoverExpanded, setIsHoverExpanded] = useState(false);
  const plannerRef = useRef(null);

  useEffect(() => {
    let frame = null;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        setCompactProgress(Math.min(1, window.scrollY / 260));
        frame = null;
      });
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    if (!dateOpen) return;
    const handleOutsideClick = (event) => {
      if (plannerRef.current && !plannerRef.current.contains(event.target)) {
        setDateOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [dateOpen]);

  const handleDateRangeSelect = (range) => {
    setDateRange(range);
    if (!range?.from) {
      setStartDate('');
      setEndDate('');
      return;
    }
    setStartDate(dateToIso(range.from));
    setEndDate(range.to ? dateToIso(range.to) : '');
  };

  const clearDates = () => {
    setDateRange(undefined);
    setStartDate('');
    setEndDate('');
  };

  const handleSearch = () => {
    const params = new URLSearchParams({ people: String(people) });
    if (startDate) params.set('start_date', startDate);
    if (endDate) params.set('end_date', endDate);
    const targetPath = '/do';
    navigate(`${targetPath}?${params.toString()}`);
  };

  const visualProgress = isHoverExpanded ? 0 : compactProgress;
  const hasSearchParams = Boolean(startDate || endDate || people !== 2 || activityType !== 'Tours');

  return (
    <div ref={plannerRef} onMouseEnter={() => setIsHoverExpanded(true)} onMouseLeave={() => setIsHoverExpanded(false)} className={`trip-planner-card relative ${dateOpen ? 'z-[30000]' : 'z-50'} mx-auto mt-4 rounded-full border border-white/50 bg-white/25 p-1 shadow-[0_8px_22px_rgba(0,0,0,0.18),inset_0_1px_0_rgba(255,255,255,0.5)] backdrop-blur-2xl backdrop-saturate-150 transition-all duration-700 ease-out hover:shadow-[0_12px_30px_rgba(0,0,0,0.16),inset_0_1px_0_rgba(255,255,255,0.48)]`} style={{ width: `min(${188 + (1 - visualProgress) * 360}px, calc(100vw - 32px))` }}>
      <div className="trip-planner-grid grid items-stretch gap-1 overflow-hidden rounded-full transition-all duration-700 ease-out" style={{ gridTemplateColumns: `minmax(42px, ${42 + (1 - visualProgress) * 178}px) minmax(42px, ${42 + (1 - visualProgress) * 48}px) minmax(42px, ${42 + (1 - visualProgress) * 128}px) ${40 + (1 - visualProgress) * 8}px` }}>
        <button
          type="button"
          aria-label="Choose trip dates"
          onClick={() => setDateOpen(!dateOpen)}
          className="group relative min-w-0 rounded-full border border-transparent bg-transparent text-center shadow-none transition-all duration-500 ease-out hover:border-white/60 hover:bg-[#F8F7F4]/50 hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.48)]"
          style={{ padding: `${8 - compactProgress * 8}px ${18 - compactProgress * 18}px`, minHeight: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          <p className="pointer-events-none absolute left-1/2 top-1.5 -translate-x-1/2 -translate-y-1 whitespace-nowrap font-inter text-[12px] font-medium leading-none opacity-0 transition-all duration-500 ease-out group-hover:translate-y-0 group-hover:opacity-100" style={{ color: '#8A8780' }}>Let&apos;s Plan Your Trip</p>
          <span className="flex min-w-0 items-center justify-center gap-1.5 font-inter text-xs font-semibold transition-transform duration-500 ease-out group-hover:translate-y-2" style={{ color: '#141413', width: '100%' }}>
            <CalendarDays size={14} color="#141413" className="shrink-0" />
            <span className="truncate transition-all duration-500 ease-out" style={{ maxWidth: `${210 * (1 - visualProgress)}px`, opacity: 1 - visualProgress, overflow: 'hidden' }}>{startDate ? [formatDate(startDate), endDate ? formatDate(endDate) : null].filter(Boolean).join(' — ') : 'Select dates'}</span>
          </span>
        </button>

        <label className="group relative min-w-0 cursor-pointer rounded-full border border-transparent bg-transparent text-center shadow-none transition-all duration-500 ease-out hover:border-white/60 hover:bg-[#F8F7F4]/50 hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.48)]" style={{ padding: `${8 - compactProgress * 8}px ${15 - compactProgress * 15}px`, minHeight: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <p className="pointer-events-none absolute left-1/2 top-1.5 -translate-x-1/2 -translate-y-1 whitespace-nowrap font-inter text-[12px] font-medium leading-none opacity-0 transition-all duration-500 ease-out group-hover:translate-y-0 group-hover:opacity-100" style={{ color: '#8A8780' }}>People</p>
          <span className="flex items-center justify-center gap-1.5 font-inter text-xs font-semibold transition-transform duration-500 ease-out group-hover:translate-y-2" style={{ color: '#141413', width: '100%' }}>
            <Users size={14} color="#141413" className="shrink-0" />
            <span className="min-w-0 transition-all duration-500" style={{ maxWidth: `${34 * (1 - visualProgress)}px`, opacity: 1 - visualProgress, overflow: 'hidden' }}>{people}</span>
          </span>
          <select aria-label="Number of people" value={people} onChange={(e) => setPeople(Number(e.target.value))} className="absolute -inset-px h-[calc(100%+2px)] w-[calc(100%+2px)] cursor-pointer rounded-full opacity-0">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
        </label>

        <label className="group relative min-w-0 cursor-pointer rounded-full border border-transparent bg-transparent text-center shadow-none transition-all duration-500 ease-out hover:border-white/60 hover:bg-[#F8F7F4]/50 hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.48)]" style={{ padding: `${8 - compactProgress * 8}px ${15 - compactProgress * 15}px`, minHeight: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <p className="pointer-events-none absolute left-1/2 top-1.5 -translate-x-1/2 -translate-y-1 whitespace-nowrap font-inter text-[12px] font-medium leading-none opacity-0 transition-all duration-500 ease-out group-hover:translate-y-0 group-hover:opacity-100" style={{ color: '#8A8780' }}>Type of Activities</p>
          <span className="flex items-center justify-center gap-1.5 font-inter text-xs font-semibold transition-transform duration-500 ease-out group-hover:translate-y-2" style={{ color: '#141413', width: '100%' }}>
            <MapPinned size={14} color="#141413" className="shrink-0" />
            <span className="min-w-0 transition-all duration-500" style={{ maxWidth: `${126 * (1 - visualProgress)}px`, opacity: 1 - visualProgress, overflow: 'hidden' }}>{activityType}</span>
          </span>
          <select aria-label="Type of Activities" value={activityType} onChange={(e) => setActivityType(e.target.value)} className="absolute -inset-px h-[calc(100%+2px)] w-[calc(100%+2px)] cursor-pointer rounded-full opacity-0">
            {['Tours', 'Transfers'].map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
        </label>

        <button type="button" aria-label="Search trip matches" data-ready={hasSearchParams ? 'true' : 'false'} onClick={handleSearch} className="trip-planner-search-button flex items-center justify-center rounded-full border border-transparent bg-transparent text-[#141413] shadow-none backdrop-blur-[18px] transition-colors transition-shadow duration-300 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.28)]" style={{ width: `${39 + (1 - visualProgress) * 7}px`, height: `${39 + (1 - compactProgress) * 7}px` }}>
          <Search size={17} />
        </button>
      </div>

      {dateOpen && (
        <div className="absolute left-1/2 top-[calc(100%+10px)] z-[30000] mx-auto rounded-[40px] border border-black/10 bg-white p-3 text-left shadow-[0_18px_52px_rgba(14,14,14,0.16)]" style={{ width: 'min(510px, calc(100vw - 32px))', transform: 'translateX(-50%)' }}>
          <div className="mb-2 grid gap-2 sm:grid-cols-2">
            <div className="rounded-full border border-black/10 bg-white px-4 py-2 transition-all duration-300 hover:border-[#571AFF] hover:bg-[#F7F4FF]">
              <p className="font-inter text-[12px] font-medium leading-none" style={{ color: '#8A8780' }}>from</p>
              <span className="mt-1 flex items-center gap-1.5 font-inter text-xs font-semibold" style={{ color: '#141413' }}><CalendarDays size={14} color="#571AFF" />{formatDate(startDate) || 'Select date'}</span>
            </div>
            <div className="rounded-full border border-black/10 bg-white px-4 py-2 transition-all duration-300 hover:border-[#571AFF] hover:bg-[#F7F4FF]">
              <p className="font-inter text-[12px] font-medium leading-none" style={{ color: '#8A8780' }}>to</p>
              <span className="mt-1 flex items-center gap-1.5 font-inter text-xs font-semibold" style={{ color: '#141413' }}><CalendarDays size={14} color="#571AFF" />{formatDate(endDate) || 'Optional'}</span>
            </div>
          </div>
          <Calendar
            mode="range"
            selected={dateRange}
            onSelect={handleDateRangeSelect}
            className="w-full rounded-[32px] border border-black/10 bg-white p-3"
            classNames={{
              month: 'w-full space-y-4',
              table: 'w-full border-collapse space-y-1',
              head_row: 'flex w-full justify-between',
              row: 'mt-2 flex w-full justify-between',
              cell: 'relative p-0 text-center text-sm focus-within:relative focus-within:z-20',
              day: 'h-8 w-8 rounded-full p-0 font-normal transition-all hover:bg-[#F7F4FF] hover:text-[#571AFF]',
              day_selected: 'bg-[#571AFF] text-white hover:bg-[#571AFF] hover:text-white focus:bg-[#571AFF] focus:text-white',
              day_range_start: 'day-range-start bg-[#571AFF] text-white rounded-full',
              day_range_end: 'day-range-end bg-[#571AFF] text-white rounded-full',
              day_range_middle: 'aria-selected:bg-[#F7F4FF] aria-selected:text-[#571AFF]',
            }}
          />
          {startDate && <button type="button" onClick={clearDates} className="mt-2 w-full rounded-full border border-black/10 bg-white px-4 py-2 font-inter text-xs font-semibold transition-colors hover:bg-[#F7F4FF]" style={{ color: '#571AFF' }}>Clear dates</button>}
        </div>
      )}
    </div>
  );
}