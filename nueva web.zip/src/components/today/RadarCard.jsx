import { Link } from 'react-router-dom';
import { useRadar } from '@/lib/RadarContext';
import { DEMO_FRIENDS } from '@/lib/radarMockData';

export default function RadarCard() {
  const { state } = useRadar();
  if (!state.enabled) return null;

  const friends = DEMO_FRIENDS;
  const neighborhoods = [...new Set(friends.map(f => f.neighborhood))].slice(0, 2).join(', ');

  return (
    <Link to="/radar" className="block mx-5">
      <div className="rounded-2xl bg-white p-3.5 flex items-center gap-3" style={{ border: '1.5px solid #E8E6DC' }}>
        {/* Pulsing radar icon */}
        <div className="relative w-11 h-11 flex items-center justify-center flex-shrink-0">
          <span className="absolute inset-0 rounded-full pulse-dot" style={{ background: '#D97757', opacity: 0.25 }} />
          <span className="absolute inset-2 rounded-full pulse-dot" style={{ background: '#D97757', opacity: 0.5, animationDelay: '0.3s' }} />
          <span className="relative w-3 h-3 rounded-full" style={{ background: '#D97757' }} />
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>
            {friends.length} friends nearby
          </p>
          <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>
            {neighborhoods}
          </p>
        </div>

        {/* Avatar stack */}
        <div className="flex -space-x-2">
          {friends.slice(0, 3).map(f => (
            <div
              key={f.id}
              className="w-7 h-7 rounded-full flex items-center justify-center font-poppins font-semibold text-white border-2 border-white"
              style={{ background: f.color, fontSize: '12px' }}
            >
              {f.initials}
            </div>
          ))}
        </div>
        <span className="font-inter flex-shrink-0" style={{ fontSize: '13px', color: '#D97757' }}>See →</span>
      </div>
    </Link>
  );
}