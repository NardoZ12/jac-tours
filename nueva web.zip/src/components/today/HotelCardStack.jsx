import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import HeartButton from '@/components/ui/HeartButton';

const HOTEL_CARDS = [
  { name: 'Maison Altstadt', address: 'Karolinenstraße 12', price: '€€€', rating: '4.8', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/bd01b14b3_generated_image.png' },
  { name: 'Garden Suite', address: 'Maximilianstraße 44', price: '€€€€', rating: '4.9', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/186e462e7_generated_image.png' },
  { name: 'River House', address: 'Lechviertel 7', price: '€€', rating: '4.7', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/c8089fceb_generated_image.png' },
  { name: 'Rooftop Atelier', address: 'Rathausplatz 3', price: '€€€', rating: '4.6', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ed140582b_generated_image.png' },
  { name: 'Velvet Residence', address: 'Fuggerstraße 18', price: '€€€', rating: '4.8', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/58a0377f5_generated_image.png' },
  { name: 'Cloud Nine Hotel', address: 'Annstraße 9', price: '€€€€', rating: '4.9', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/9c99ca161_generated_image.png' },
  { name: 'The Linen House', address: 'Stadtmarkt 21', price: '€€', rating: '4.6', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/c298a0168_generated_image.png' },
  { name: 'Arcade Rooms', address: 'Jakoberstraße 5', price: '€€€', rating: '4.7', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/d69954d1a_generated_image.png' },
  { name: 'Courtyard Stay', address: 'Dom Viertel 14', price: '€€€', rating: '4.8', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/2386f7804_generated_image.png' },
  { name: 'Terra Boutique', address: 'Pfersee 28', price: '€€', rating: '4.5', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/663f72d87_generated_image.png' },
  { name: 'Brass & Marble', address: 'Innenstadt 32', price: '€€€€', rating: '4.9', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/4d8be7329_generated_image.png' },
  { name: 'Canal Hideaway', address: 'Lechkanal 2', price: '€€€', rating: '4.7', image: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ea01b4cc1_generated_image.png' },
];

const COLUMNS = [
  HOTEL_CARDS.slice(8, 12),
  HOTEL_CARDS.slice(0, 4),
  HOTEL_CARDS.slice(4, 8),
];

function clamp(value, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

export default function HotelCardStack() {
  const gridRef = useRef(null);
  const itemRefs = useRef({});
  const [gridProgress, setGridProgress] = useState(0);
  const [itemProgress, setItemProgress] = useState({});
  const [hoveredCard, setHoveredCard] = useState(null);
  const [hoveredButton, setHoveredButton] = useState(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const query = window.matchMedia('(max-width: 767px)');
    const update = () => setIsMobile(query.matches);
    update();
    query.addEventListener('change', update);
    return () => query.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    if (isMobile) return;
    let frame = null;
    const update = () => {
      frame = null;
      const viewport = window.innerHeight;
      const grid = gridRef.current;
      if (!grid) return;

      const gridRect = grid.getBoundingClientRect();
      setGridProgress(clamp((viewport - gridRect.top) / (viewport + gridRect.height)));

      const next = {};
      Object.entries(itemRefs.current).forEach(([key, element]) => {
        if (!element) return;
        const rect = element.getBoundingClientRect();
        next[key] = clamp((viewport - rect.top) / (viewport + rect.height));
      });
      setItemProgress(next);
    };

    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(update);
    };

    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [isMobile]);

  return (
    <section style={{ marginLeft: 'calc(50% - 50vw)', width: '100vw', background: '#F8F7F4', color: '#FFFFFF', overflow: 'hidden', padding: isMobile ? '20px 18px 56px' : '14vh 4vw 18vh' }}>
      <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-3" style={{ gap: '18px', maxWidth: '1200px', margin: '0 auto', alignItems: 'start' }}>
        {COLUMNS.map((column, columnIndex) => {
          const isCenter = columnIndex === 1;
          const columnTransform = !isMobile && isCenter ? `translateY(${-gridProgress * 20}%)` : 'translateY(0)';

          return (
            <div key={columnIndex} style={{ display: 'grid', gap: '18px', transform: columnTransform, willChange: 'transform' }}>
              {column.map((hotel, cardIndex) => {
                const key = `${columnIndex}-${cardIndex}`;
                const progress = itemProgress[key] || 0;
                const direction = columnIndex === 0 ? -1 : columnIndex === 2 ? 1 : 0;
                const wrapperTransform = isMobile || direction === 0 ? 'translate3d(0,0,0)' : `translateX(${direction * progress * 10}%) rotate(${direction * progress * 6}deg)`;
                const imageTransform = isMobile ? 'scale(1)' : `translateY(${(0.5 - progress) * 16}%) scale(1.16)`;
                const origin = columnIndex === 0 ? '0% 100%' : columnIndex === 2 ? '100% 100%' : '50% 50%';
                const isHovered = !isMobile && hoveredCard === key;
                const learnHovered = hoveredButton === `${key}-learn`;
                const bookHovered = hoveredButton === `${key}-book`;
                const placeVenue = { id: `home-hotel-${hotel.name.toLowerCase().replace(/\s+/g, '-')}`, name: hotel.name, category: 'hotel', cover_image_url: hotel.image, address: hotel.address, price: hotel.price, price_range: hotel.price.length, avg_rating: Number(hotel.rating), short_description: 'Highlighted hotel stay in Augsburg' };

                return (
                  <div
                    key={hotel.name}
                    ref={(element) => { itemRefs.current[key] = element; }}
                    style={{ aspectRatio: '1 / 1', overflow: 'visible', position: 'relative' }}>
                    <article
                      onMouseEnter={() => setHoveredCard(key)}
                      onMouseLeave={() => { setHoveredCard(null); setHoveredButton(null); }}
                      style={{ margin: 0, width: '100%', height: '100%', borderRadius: '24px', overflow: 'hidden', position: 'relative', transform: wrapperTransform, transformOrigin: origin, willChange: 'transform', cursor: 'pointer' }}>
                      <div style={{ width: '100%', height: '100%', overflow: 'hidden', background: '#181818' }}>
                        <img src={hotel.image} alt={hotel.name} loading="lazy" style={{ width: '100%', height: '118%', objectFit: 'cover', display: 'block', transform: imageTransform, filter: isHovered ? 'brightness(0.8)' : 'brightness(1)', transition: 'transform 260ms ease-out, filter 260ms ease', willChange: 'transform, filter' }} />
                      </div>
                      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(0,0,0,0.05), transparent 42%, rgba(0,0,0,0.94))' }} />
                      <div style={{ position: 'absolute', left: '16px', top: '16px', zIndex: 3 }}>
                        <HeartButton venue={placeVenue} />
                      </div>
                      <div style={{ position: 'absolute', left: '18px', right: '18px', bottom: '-30px', fontFamily: 'Inter, sans-serif', transform: isHovered ? 'translateY(-48px)' : 'translateY(0)', transition: 'transform 260ms cubic-bezier(0.22, 1, 0.36, 1)' }}>
                        <h3 style={{ margin: 0, fontFamily: 'Inter, sans-serif', fontSize: '18px', fontWeight: 500, letterSpacing: '-0.03em', color: '#FFFFFF' }}>{hotel.name}</h3>
                        <p style={{ margin: '7px 0 0', display: 'flex', justifyContent: 'space-between', gap: '12px', color: 'rgba(255,255,255,0.72)', fontSize: '12px' }}>
                          <span>{hotel.address}</span>
                          <span><span className="font-neue" style={{ fontSize: '13px', color: '#FFFFFF' }}>{hotel.price}</span> · ★ {hotel.rating}</span>
                        </p>
                        <div style={{ display: 'flex', gap: '8px', marginTop: '14px', opacity: isHovered ? 1 : 0, transform: isHovered ? 'translateY(0)' : 'translateY(18px)', transition: 'opacity 220ms ease, transform 260ms cubic-bezier(0.22, 1, 0.36, 1)' }}>
                          <Link
                            to={`/place/${placeVenue.id}`}
                            state={{ venue: placeVenue }}
                            onMouseEnter={() => setHoveredButton(`${key}-learn`)}
                            onMouseLeave={() => setHoveredButton(null)}
                            style={{ flex: 1, height: '34px', borderRadius: '999px', border: learnHovered ? '1px solid #571AFF' : '1px solid rgba(255,255,255,0.36)', background: learnHovered ? '#571AFF' : 'rgba(255,255,255,0.08)', color: '#FFFFFF', fontFamily: 'Inter, sans-serif', fontSize: '12px', fontWeight: 600, textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: learnHovered ? 'translateY(-2px) scale(1.03)' : 'translateY(0) scale(1)', boxShadow: learnHovered ? '0 12px 28px rgba(87,26,255,0.28)' : '0 0 0 rgba(0,0,0,0)', transition: 'transform 180ms ease, background 180ms ease, border 180ms ease, box-shadow 180ms ease' }}>
                            Learn More
                          </Link>
                          <Link
                            to={`/place/${placeVenue.id}#book-now`}
                            state={{ venue: placeVenue }}
                            onMouseEnter={() => setHoveredButton(`${key}-book`)}
                            onMouseLeave={() => setHoveredButton(null)}
                            style={{ flex: 1, height: '34px', borderRadius: '999px', border: bookHovered ? '1px solid #571AFF' : '1px solid rgba(255,255,255,0.92)', background: bookHovered ? '#571AFF' : '#FFFFFF', color: bookHovered ? '#FFFFFF' : '#000000', fontFamily: 'Inter, sans-serif', fontSize: '12px', fontWeight: 700, textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: bookHovered ? 'translateY(-2px) scale(1.03)' : 'translateY(0) scale(1)', boxShadow: bookHovered ? '0 12px 28px rgba(87,26,255,0.28)' : '0 0 0 rgba(0,0,0,0)', transition: 'transform 180ms ease, background 180ms ease, border 180ms ease, box-shadow 180ms ease, color 180ms ease' }}>
                            Book Now
                          </Link>
                        </div>
                      </div>
                    </article>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </section>
  );
}