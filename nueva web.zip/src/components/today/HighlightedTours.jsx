import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, MapPin, Star, ArrowRight } from 'lucide-react';
import Reveal from '@/components/ui/Reveal';
import { listContentByType } from '@/lib/contentTables';

export default function HighlightedTours() {
  const [tours, setTours] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listContentByType('do', '-avg_rating', 6)
      .then((rows) => { setTours(rows || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <section className="relative" style={{ background: '#121623', marginLeft: 'calc(50% - 50vw)', width: '100vw' }}>
      <div className="mx-auto max-w-7xl px-5 md:px-8 py-20 md:py-28">
        <Reveal className="text-center mb-12">
          <motion.h2
            className="[font-family:'Libre_Baskerville',_serif] font-normal text-white inline-block"
            style={{ fontSize: 'clamp(40px, 7vw, 92px)', lineHeight: 1.02, letterSpacing: '-0.055em' }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}>
            Highlighted Tours
          </motion.h2>
          <motion.p
            className="mx-auto mt-4 font-inter text-white/75"
            style={{ maxWidth: '480px', fontSize: '15px', lineHeight: 1.6 }}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.6, delay: 0.15, ease: 'easeOut' }}>
            Las excursiones más populares de Jac Tour and Transfers en Punta Cana y toda la República Dominicana.
          </motion.p>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {loading
            ? [0, 1, 2].map((i) => <div key={i} className="h-[340px] rounded-[24px] bg-white/15 animate-pulse" />)
            : tours.map((tour, i) => (
                <motion.div
                  key={tour.id}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.55, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}>
                <Link to={`/do/${tour.id}`} className="group block overflow-hidden rounded-[24px] bg-white transition-transform duration-300 hover:-translate-y-1" style={{ boxShadow: '0 18px 44px rgba(0,0,0,0.20)' }}>
                  <div className="relative h-[200px] overflow-hidden">
                    <img src={tour.cover_image_url} alt={tour.name} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5">
                      <Star size={13} fill="#0E0E0E" />
                      <span className="font-inter text-xs font-bold">{Number(tour.avg_rating || 4.8).toFixed(1)}</span>
                    </div>
                    {tour.duration && (
                      <div className="absolute left-3 bottom-3 flex items-center gap-1 rounded-full px-3 py-1.5 font-inter text-xs font-bold text-white" style={{ background: 'rgba(14,14,14,0.5)', backdropFilter: 'blur(8px)' }}>
                        <Clock size={12} className="mr-1" />{tour.duration}
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <p className="font-inter text-xs" style={{ color: '#72706A' }}>{tour.sub_category}</p>
                    <h3 className="mt-1 font-poppins font-bold" style={{ fontSize: '18px', color: '#141413' }}>{tour.name}</h3>
                    <div className="mt-2 flex items-center gap-1 font-inter text-xs" style={{ color: '#72706A' }}><MapPin size={13} />{tour.neighborhood || tour.city}</div>
                    <p className="mt-3 font-inter text-sm" style={{ color: '#3A3A3A', lineHeight: 1.5 }}>{tour.short_description}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>{tour.price_label || `$${tour.price}`}<span className="font-inter text-xs font-normal" style={{ color: '#72706A' }}> /persona</span></span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#141413] px-4 py-2 font-inter text-xs font-semibold text-white transition-colors group-hover:bg-[#571AFF]">Ver <ArrowRight size={14} /></span>
                    </div>
                  </div>
                </Link>
                </motion.div>
              ))}
        </div>

        <Reveal className="mt-12 text-center" delay={0.2}>
          <motion.div whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.96 }} transition={{ duration: 0.2 }}>
            <Link to="/do" className="inline-flex items-center gap-2 rounded-full bg-white px-7 py-3 font-inter text-sm font-semibold text-[#141413] transition-transform hover:scale-105">
              Ver todos los tours <ArrowRight size={16} />
            </Link>
          </motion.div>
        </Reveal>
      </div>
    </section>
  );
}