import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Building2, Compass, Heart, Sun, UtensilsCrossed } from 'lucide-react';

const footerItems = [
  { icon: Sun, label: 'Highlights', path: '/' },
  { icon: UtensilsCrossed, label: 'Eat', path: '/eat' },
  { icon: Building2, label: 'Stay', path: '/stay' },
  { icon: Compass, label: 'Do', path: '/do' },
  { icon: Heart, label: 'Favourites', path: '/favourites' },
];

const FOOTER_BG = '#F8F7F4';
const FOOTER_BG_RGB = 'rgb(248, 247, 244)';
const TRANSPARENT = new Set(['transparent', 'rgba(0, 0, 0, 0)']);

function findVisibleBackground(element) {
  let node = element;
  while (node && node !== document.documentElement) {
    const bg = window.getComputedStyle(node).backgroundColor;
    if (bg && !TRANSPARENT.has(bg)) return bg;
    node = node.parentElement;
  }
  return FOOTER_BG_RGB;
}

export default function TodayFooter() {
  const footerRef = useRef(null);
  const [progress, setProgress] = useState(0);
  const [previousBg, setPreviousBg] = useState(FOOTER_BG_RGB);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const query = window.matchMedia('(max-width: 767px)');
    const updateMobile = () => setIsMobile(query.matches);
    updateMobile();
    query.addEventListener('change', updateMobile);
    return () => query.removeEventListener('change', updateMobile);
  }, []);

  useEffect(() => {
    let frame = null;
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const footer = footerRef.current;
        if (!footer) return;
        const rect = footer.getBoundingClientRect();
        const next = Math.min(1, Math.max(0, (window.innerHeight - rect.top) / Math.max(1, rect.height)));
        setProgress(next);

        if (rect.top < window.innerHeight) {
          const y = Math.min(window.innerHeight - 1, Math.max(0, rect.top - 2));
          const above = document.elementsFromPoint(window.innerWidth / 2, y).find((el) => el !== footer && !footer.contains(el));
          setPreviousBg(findVisibleBackground(above));
        }
        frame = null;
      });
    };

    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const visualProgress = isMobile ? 0 : progress;
  const cardSize = 74 + visualProgress * 18;
  const cardHeight = 78 + visualProgress * 14;
  const navGap = 8 + visualProgress * 4;
  const navPadX = 10 + visualProgress * 6;
  const navPadY = 8 + visualProgress * 4;
  const navRadius = 28 + visualProgress * 6;
  const cardRadius = 18 + visualProgress * 6;
  const iconSize = 20 + visualProgress * 4;

  const needsBlend = previousBg !== FOOTER_BG_RGB && previousBg !== FOOTER_BG;

  return (
    <footer ref={footerRef} className="relative overflow-visible px-5 pb-6 pt-8 sm:pb-14 sm:pt-16" style={{ background: FOOTER_BG }}>
      {needsBlend && (
        <div
          className="pointer-events-none absolute inset-x-0 -top-40 h-80"
          style={{ background: `linear-gradient(to bottom, ${previousBg} 0%, rgba(248,247,244,0.18) 34%, rgba(248,247,244,0.72) 68%, ${FOOTER_BG} 100%)` }}
        />
      )}
      <div className="relative z-10 mx-auto flex max-w-5xl flex-col items-center">
        <nav
          className="flex max-w-full flex-wrap items-end justify-center border bg-white backdrop-blur-2xl backdrop-saturate-150"
          style={{
            display: isMobile ? 'grid' : undefined,
            gridTemplateColumns: isMobile ? 'repeat(3, minmax(0, 1fr))' : undefined,
            alignItems: isMobile ? 'stretch' : undefined,
            width: isMobile ? '100%' : undefined,
            maxWidth: isMobile ? '520px' : undefined,
            gap: `${navGap}px`,
            borderRadius: `${navRadius}px`,
            borderColor: '#E8E6DC',
            padding: `${navPadY}px ${navPadX}px`,
            boxShadow: '0 2px 12px rgba(14,14,14,0.08)',
            transition: isMobile ? 'none' : 'gap 120ms linear, padding 120ms linear, border-radius 120ms linear'
          }}>
          {footerItems.map(({ icon: Icon, label, path }) => (
            <Link
              key={label}
              to={path}
              className="group flex flex-col items-center justify-center border border-black/[0.04] bg-white/55 text-[#141413] transition-all duration-300 ease-out hover:-translate-y-3 hover:scale-110 hover:border-[#571AFF] hover:bg-[#571AFF] hover:text-white hover:shadow-[0_16px_34px_rgba(87,26,255,0.28)]"
              style={{ width: isMobile ? '100%' : `${cardSize}px`, height: `${cardHeight}px`, borderRadius: `${cardRadius}px`, transition: isMobile ? 'transform 300ms ease, background 300ms ease, color 300ms ease, box-shadow 300ms ease' : 'width 120ms linear, height 120ms linear, border-radius 120ms linear, transform 300ms ease, background 300ms ease, color 300ms ease, box-shadow 300ms ease' }}>
              <Icon size={iconSize} strokeWidth={2.1} className="transition-transform duration-300 group-hover:scale-110" />
              <span className="mt-2 font-inter font-semibold tracking-[-0.01em]" style={{ fontSize: `${11 + visualProgress}px` }}>{label}</span>
            </Link>
          ))}
        </nav>

      </div>
    </footer>
  );
}