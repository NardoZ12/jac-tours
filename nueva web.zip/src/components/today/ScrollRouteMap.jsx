import { useState } from 'react';
import { motion } from 'framer-motion';
import { MapContainer, TileLayer, Polyline, Marker, Tooltip } from 'react-leaflet';
import { useNavigate } from 'react-router-dom';
import L from 'leaflet';
import { MapPin } from 'lucide-react';
import Reveal from '@/components/ui/Reveal';
import 'leaflet/dist/leaflet.css';

const TOURS = [
  {
    id: '6ac01a5de83b817c8ebaa899',
    title: 'Isla Saona',
    sub: 'Excursión de Isla',
    coords: [18.16, -68.68],
    place: 'Isla Saona, Parque Nacional del Este',
    detail: 'Playa paradisíaca de arena blanca y aguas turquesas. Excursión en lancha rápida con almuerzo criollo incluido.',
    meta: ['Lancha rápida', 'Almuerzo incluido'],
    image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/e0630ef0b_generated_image.png',
  },
  {
    id: '6ac01a5de83b817c8ebaa895',
    title: 'Buggies – Playa Macao',
    sub: 'Aventura Off-Road',
    coords: [18.57, -68.46],
    place: 'Playa Macao, Punta Cana',
    detail: 'Recorre caminos off-road, cenotes y la playa de Macao a bordo de un buggy. Adrenalina pura en la costa caribeña.',
    meta: ['Off-road', 'Cenotes'],
    image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/ecc1a17bd_generated_image.png',
  },
  {
    id: '6ac01a5de83b817c8ebaa89f',
    title: 'Santo Domingo – Zona Colonial',
    sub: 'Tour Cultural',
    coords: [18.47, -69.88],
    place: 'Zona Colonial, Santo Domingo',
    detail: 'La primera ciudad del Nuevo Mundo: callejones empedrados, catedral primada y museos coloniales. Tour cultural guiado.',
    meta: ['Cultural', 'Guiado'],
    image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/ebf064593_generated_image.png',
  },
];

const ROUTE = TOURS.map((t) => t.coords);

const makeIcon = (image, active) => {
  const size = active ? 58 : 46;
  return L.divIcon({
    className: 'tour-marker',
    html: `
      <div style="position:relative;width:${size}px;height:${size}px;">
        <div style="position:absolute;inset:-4px;border-radius:50%;border:2px solid ${active ? '#571AFF' : '#FFFFFF'};box-shadow:0 4px 14px rgba(14,14,14,0.30);background:#FFFFFF;"></div>
        <img src="${image}" style="position:absolute;inset:2px;width:calc(100% - 4px);height:calc(100% - 4px);border-radius:50%;object-fit:cover;" />
        <div style="position:absolute;left:50%;bottom:-7px;transform:translateX(-50%);width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:8px solid ${active ? '#571AFF' : '#FFFFFF'};"></div>
      </div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2 + 4],
  });
};

export default function ScrollRouteMap() {
  const [activeId, setActiveId] = useState(0);
  const navigate = useNavigate();

  const goToTour = (id) => navigate(`/do/${id}`);

  return (
    <section className="relative" style={{ background: 'linear-gradient(180deg, #F8F7F4 0%, #EDE7F6 55%, #E8E0F4 100%)' }}>
      <div className="mx-auto max-w-7xl px-5 md:px-8 pt-16 md:pt-24 pb-16 md:pb-24">
        <Reveal className="text-center mb-10">
          <motion.h2
            className="[font-family:'Libre_Baskerville',_serif] font-normal inline-block"
            style={{ fontSize: 'clamp(34px, 6vw, 64px)', lineHeight: 1.05, letterSpacing: '-0.05em', color: '#141413' }}
            initial={{ opacity: 0, y: 26 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}>
            Ruta Punta Cana
          </motion.h2>
          <motion.p
            className="mx-auto mt-4 font-inter"
            style={{ maxWidth: '520px', fontSize: '15px', lineHeight: 1.6, color: '#72706A' }}
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.55, delay: 0.12, ease: 'easeOut' }}>
            Explora nuestras excursiones más populares: Isla Saona, los buggies en Playa Macao y el tour cultural por la Zona Colonial de Santo Domingo. Toca una marca para ver el tour.
          </motion.p>
        </Reveal>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="lg:sticky lg:top-24 lg:self-start">
            <div className="overflow-hidden rounded-[28px] bg-white" style={{ border: '1px solid #E8E6DC', boxShadow: '0 18px 44px rgba(14,14,14,0.10)' }}>
              <MapContainer bounds={ROUTE} boundsOptions={{ padding: [60, 60] }} scrollWheelZoom={false} style={{ height: '440px', width: '100%' }}>
                <TileLayer url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}" attribution='&copy; Esri' />
                <Polyline positions={ROUTE} pathOptions={{ color: '#571AFF', weight: 3, opacity: 0.6, dashArray: '8 8' }} />
                {TOURS.map((t, i) => (
                  <Marker
                    key={t.id}
                    position={t.coords}
                    icon={makeIcon(t.image, i === activeId)}
                    eventHandlers={{
                      click: () => goToTour(t.id),
                      mouseover: (e) => { e.target.openTooltip(); setActiveId(i); },
                    }}
                  >
                    <Tooltip direction="top" offset={[0, -28]}>{t.title}</Tooltip>
                  </Marker>
                ))}
              </MapContainer>
            </div>
          </div>

          <div className="space-y-4">
            {TOURS.map((t, i) => (
              <motion.div
                key={t.id}
                onMouseEnter={() => setActiveId(i)}
                onClick={() => goToTour(t.id)}
                className="cursor-pointer rounded-2xl bg-white p-5 transition-all"
                style={{ border: `2px solid ${i === activeId ? '#571AFF' : 'rgba(14,14,14,0.08)'}`, boxShadow: i === activeId ? '0 12px 28px rgba(87,26,255,0.18)' : '0 8px 22px rgba(14,14,14,0.06)' }}
                initial={{ opacity: 0, x: 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.5, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ scale: 1.02 }}
              >
                <div className="flex gap-4">
                  <img src={t.image} alt={t.title} className="rounded-xl object-cover press-shrink" style={{ width: '88px', height: '88px', flexShrink: 0 }} />
                  <div className="min-w-0 flex-1">
                    <div className="inline-flex items-center gap-2 rounded-full bg-[#F0EFE9] px-3 py-1">
                      <span className="font-inter text-xs font-semibold" style={{ color: '#141413' }}>{t.sub}</span>
                    </div>
                    <h3 className="mt-2 font-poppins font-bold" style={{ fontSize: '18px', color: '#141413' }}>{t.title}</h3>
                    <div className="mt-1 flex items-center gap-1 font-inter text-xs" style={{ color: '#72706A' }}><MapPin size={13} />{t.place}</div>
                  </div>
                </div>
                <p className="mt-3 font-inter text-sm" style={{ color: '#3A3A3A', lineHeight: 1.6 }}>{t.detail}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {t.meta.map((m) => <span key={m} className="rounded-full bg-[#F2F1EE] px-3 py-1 font-inter text-xs font-semibold" style={{ color: '#3A3A3A' }}>{m}</span>)}
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); goToTour(t.id); }}
                  className="btn-primary-sm mt-4"
                  style={{ width: 'auto', padding: '0 22px' }}
                >
                  Ver tour
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}