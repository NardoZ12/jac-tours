import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';
import VenuePhoto from '@/components/ui/VenuePhoto';

const EMOJIS = { Japanese: '🍜', Italian: '🍝', Israeli: '🥙', Mediterranean: '🫒', default: '🍽️' };

export default function LunchRoulette({ venues = [], user }) {
  const [idx, setIdx] = useState(0);
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [sliding, setSliding] = useState(false);

  const restaurants = venues.filter(v => v.category === 'restaurant');
  const venue = restaurants[idx % Math.max(restaurants.length, 1)];

  useEffect(() => {
    if (venue) pickWithAI([venue]);
  }, [idx]);

  const pickWithAI = async (candidates) => {
    if (!candidates.length) return;
    setLoading(true);
    try {
      const names = candidates.map(v => v.name).join(', ');
      const tasteProfile = user?.taste_profile?.cuisines?.join(', ') || 'Mediterranean';
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Roam app. From: ${names}. User likes: ${tasteProfile}. Write one short punchy reason (max 8 words, no quotes) why they'll love this restaurant right now.`,
      });
      setReason(typeof res === 'string' ? res : 'Perfect for your taste today');
    } catch {
      setReason('AI-picked just for you');
    }
    setLoading(false);
  };

  const handleSkip = () => {
    setSliding(true);
    setTimeout(() => { setIdx(i => i + 1); setSliding(false); }, 250);
  };

  if (!venue) return null;
  const cuisine = venue.cuisine_tags?.[0] || venue.sub_category || 'Mediterranean';
  const emoji = EMOJIS[cuisine] || EMOJIS.default;

  return (
    <div>
      <div className="flex items-center justify-between px-5 mb-3">
        <span className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>Lunch roulette</span>
        <span className="font-inter" style={{ fontSize: '13px', color: '#D97757' }}>How it works →</span>
      </div>

      <div
        className="mx-5 rounded-2xl overflow-hidden card-shadow bg-white transition-all"
        style={{ opacity: sliding ? 0 : 1, transform: sliding ? 'translateX(-30px)' : 'none' }}
      >
        {/* Photo top */}
        <VenuePhoto venue={venue} height={140} rounded="0">
          <div className="absolute bottom-0 left-0 right-0 p-3.5 z-10">
            <span style={{ fontSize: '28px' }}>{emoji}</span>
            <p className="font-poppins font-semibold text-white mt-1" style={{ fontSize: '12px', letterSpacing: '0.06em', textTransform: 'uppercase', opacity: 0.7 }}>
              AI pick for you · tap to spin
            </p>
            <p className="font-poppins font-bold text-white" style={{ fontSize: '18px' }}>{venue.name}</p>
            <p className="font-inter text-white" style={{ fontSize: '12px', opacity: 0.85 }}>{cuisine} · {venue.neighborhood}</p>
          </div>
        </VenuePhoto>

        {/* Bottom white */}
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0 flex-1">
            <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>
              ~{Math.floor(Math.random() * 5) + 1} km away · <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>{'€'.repeat(venue.price_range || 2)}</span>
            </p>
            {loading ? (
              <div className="skeleton h-3 w-32 rounded mt-1" />
            ) : (
              <p className="font-poppins font-semibold truncate" style={{ fontSize: '12px', color: '#16A34A' }}>
                ● {Math.floor(Math.random() * 5) + 1} tables available
              </p>
            )}
            {reason && !loading && (
              <p className="font-inter italic mt-0.5 truncate" style={{ fontSize: '12px', color: '#72706A' }}>{reason}</p>
            )}
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={handleSkip}
              aria-label="Skip"
              className="flex items-center gap-1 font-poppins font-semibold whitespace-nowrap"
              style={{
                height: '36px', padding: '0 12px', borderRadius: '10px',
                border: '1.5px solid #E8E6DC', fontSize: '13px', color: '#141413',
              }}
            >
              <RefreshCw size={13} /> Skip
            </button>
            <Link
              to={`/eat/${venue.id}`}
              className="flex items-center font-poppins font-semibold text-white whitespace-nowrap"
              style={{
                height: '36px', padding: '0 16px', borderRadius: '10px',
                background: '#141413', fontSize: '13px',
              }}
            >
              Book
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}