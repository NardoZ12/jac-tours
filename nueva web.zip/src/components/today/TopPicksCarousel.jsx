import { useState, useEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Star, Sparkles } from 'lucide-react';
import VenuePhoto from '@/components/ui/VenuePhoto';

const AUTO_ADVANCE_MS = 5000;

/**
 * Desktop-only suggestions carousel showing top-reviewed restaurants.
 * - Ranks restaurants by review_count × avg_rating
 * - Auto-advances every 5s
 * - Pauses on hover, respects prefers-reduced-motion
 */
export default function TopPicksCarousel({ venues = [] }) {
  const ranked = useMemo(() => {
    return venues
      .filter(v => v.category === 'restaurant' && (v.review_count || 0) > 0)
      .map(v => ({ ...v, _score: (v.review_count || 0) * (v.avg_rating || 0) }))
      .sort((a, b) => b._score - a._score)
      .slice(0, 8);
  }, [venues]);

  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef(null);

  // Auto-advance — pauses on hover and respects reduced-motion
  useEffect(() => {
    if (ranked.length < 2) return;
    const reduceMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion || paused) return;

    timerRef.current = setInterval(() => {
      setIndex(i => (i + 1) % ranked.length);
    }, AUTO_ADVANCE_MS);
    return () => clearInterval(timerRef.current);
  }, [ranked.length, paused]);

  // Clamp index when ranked list shrinks
  useEffect(() => {
    if (index >= ranked.length) setIndex(0);
  }, [ranked.length, index]);

  if (ranked.length === 0) return null;

  const next = () => setIndex(i => (i + 1) % ranked.length);
  const prev = () => setIndex(i => (i - 1 + ranked.length) % ranked.length);

  return (
    <div
      className="px-8 max-w-7xl mx-auto"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles size={16} color="#FF5C39" />
          <span className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>
            Top picks · most-loved this season
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={prev}
            aria-label="Previous"
            className="w-9 h-9 flex items-center justify-center rounded-full"
            style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC' }}
          >
            <ChevronLeft size={16} color="#141413" />
          </button>
          <button
            onClick={next}
            aria-label="Next"
            className="w-9 h-9 flex items-center justify-center rounded-full"
            style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC' }}
          >
            <ChevronRight size={16} color="#141413" />
          </button>
        </div>
      </div>

      {/* Track */}
      <div className="relative overflow-hidden rounded-2xl card-shadow bg-white">
        <div
          className="flex transition-transform duration-700"
          style={{
            transform: `translateX(-${index * 100}%)`,
            transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)',
          }}
        >
          {ranked.map(v => (
            <Slide key={v.id} venue={v} />
          ))}
        </div>

        {/* Dot indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
          {ranked.map((_, i) => (
            <button
              key={i}
              onClick={() => setIndex(i)}
              aria-label={`Go to slide ${i + 1}`}
              className="transition-all"
              style={{
                width: i === index ? '24px' : '8px',
                height: '8px',
                borderRadius: '99px',
                background: i === index ? '#FFFFFF' : 'rgba(255,255,255,0.5)',
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function Slide({ venue }) {
  const cuisine = venue.cuisine_tags?.[0] || venue.sub_category || 'Restaurant';
  return (
    <div className="flex-shrink-0 w-full grid grid-cols-2 gap-0" style={{ minHeight: '320px' }}>
      {/* Image */}
      <div className="relative">
        <VenuePhoto venue={venue} height={320} rounded="0">
          <div className="absolute top-4 left-4 z-10">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.95)' }}>
              <Star size={12} fill="#FF5C39" color="#FF5C39" />
              <span className="font-poppins font-bold" style={{ fontSize: '12px', color: '#141413' }}>
                {(venue.avg_rating || 0).toFixed(1)}
              </span>
              <span className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
                ({venue.review_count} reviews)
              </span>
            </div>
          </div>
        </VenuePhoto>
      </div>

      {/* Content */}
      <div className="p-8 flex flex-col justify-center">
        <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#FF5C39', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {cuisine}{venue.neighborhood ? ` · ${venue.neighborhood}` : ''}
        </span>
        <h3 className="font-poppins font-bold mt-2" style={{ fontSize: '28px', color: '#141413', letterSpacing: '-0.5px', lineHeight: 1.1 }}>
          {venue.name}
        </h3>
        {venue.short_description && (
          <p className="font-inter mt-3" style={{ fontSize: '14px', color: '#5E5E5E', lineHeight: 1.55 }}>
            {venue.short_description}
          </p>
        )}
        <div className="flex items-center gap-2 mt-5">
          <Link
            to={`/eat/${venue.id}`}
            className="font-poppins font-semibold text-white"
            style={{
              height: '44px', padding: '0 22px', borderRadius: '99px',
              background: 'linear-gradient(135deg,#FF385C,#E61E4D)',
              fontSize: '14px',
              boxShadow: '0 8px 22px rgba(255,56,92,0.30)',
              display: 'inline-flex', alignItems: 'center',
            }}
          >
            View {'&'} book →
          </Link>
          <span className="font-neue ml-2" style={{ fontSize: '13px', color: '#72706A' }}>
            {'€'.repeat(venue.price_range || 2)}
          </span>
        </div>
      </div>
    </div>
  );
}