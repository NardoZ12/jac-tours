import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import VenuePhoto from '../ui/VenuePhoto';
import { findContentById } from '@/lib/contentTables';

function useCountdown(validUntil) {
  const [timeLeft, setTimeLeft] = useState('');
  useEffect(() => {
    const calc = () => {
      const diff = new Date(validUntil) - new Date();
      if (diff <= 0) { setTimeLeft('Expired'); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      setTimeLeft(`${h}h ${m}m`);
    };
    calc();
    const id = setInterval(calc, 30000);
    return () => clearInterval(id);
  }, [validUntil]);
  return timeLeft;
}

export default function FlashDealCard({ deal, index = 0 }) {
  const timeLeft = useCountdown(deal.valid_until);
  const [venue, setVenue] = useState(null);
  useEffect(() => {
    if (deal.venue_id) {
      findContentById(deal.venue_id, deal.venue_category).then(setVenue).catch(() => {});
    }
  }, [deal.venue_id]);

  // Hide expired deals
  if (timeLeft === 'Expired') return null;

  const discountText = deal.discount_type === 'percentage'
    ? `${deal.discount_value}% off`
    : deal.discount_type === 'freebie'
    ? deal.title
    : `€${deal.discount_value} off`;

  return (
    <div className="flex-shrink-0 rounded-2xl overflow-hidden card-shadow bg-white" style={{ width: '175px' }}>
      <VenuePhoto venue={venue || { name: deal.venue_name }} height={110} rounded="0">
        {timeLeft && (
          <div
            className="absolute top-2 right-2 z-10 font-poppins font-bold text-white"
            style={{ fontSize: '12px', background: '#0E0E0E', padding: '3px 7px', borderRadius: '6px' }}
          >
            ⏱ {timeLeft}
          </div>
        )}
        <div className="absolute bottom-0 left-0 right-0 p-2.5 z-10">
          <p className="font-poppins font-semibold text-white" style={{ fontSize: '13px' }}>{deal.venue_name}</p>
          <p className="font-inter text-white" style={{ fontSize: '12px', opacity: 0.8 }}>{deal.venue_category}</p>
        </div>
      </VenuePhoto>

      {/* White bottom */}
      <div className="p-3">
        <p className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>{discountText}</p>
        {deal.original_price && (
          <p className="font-neue" style={{ fontSize: '13px', color: '#72706A', textDecoration: 'line-through' }}>
            €{deal.original_price}
          </p>
        )}
        <p className="font-inter italic" style={{ fontSize: '12px', color: '#72706A' }}>
          {deal.max_redemptions - (deal.redemption_count || 0)} spots left
        </p>
        <Link
          to={`${deal.venue_category === 'stay' ? '/stay' : deal.venue_category === 'do' ? '/do' : '/eat'}/${deal.venue_id}`}
          className="block w-full text-center font-poppins font-semibold text-white mt-2"
          style={{ height: '36px', lineHeight: '36px', borderRadius: '10px', background: '#0E0E0E', fontSize: '12px' }}
        >
          Book now
        </Link>
      </div>
    </div>
  );
}