import { useState, useEffect } from 'react';
import { X, ChevronRight, ChevronLeft } from 'lucide-react';

const KEY = 'roam_welcome_tutorial_seen_v1';

const SLIDES = [
  {
    emoji: '☀️',
    accent: '#F59E0B',
    accentBg: '#FEF3C7',
    title: 'Welcome to Roam',
    subtitle: 'Your daily city guide',
    body: 'Every morning, get a personalized brief with the best deals, openings, and events near you — all in one place.',
  },
  {
    emoji: '🍽️',
    accent: '#FF5C39',
    accentBg: '#FFE4DB',
    title: 'Eat, Stay & Discover',
    subtitle: 'Book in two taps',
    body: 'Browse restaurants, hotels, and activities curated for your taste. Real-time availability — no calls, no waiting.',
  },
  {
    emoji: '🧭',
    accent: '#84CC16',
    accentBg: '#ECFCCB',
    title: 'Find activities & people nearby',
    subtitle: 'Roam Radar',
    body: 'See what\'s happening around you and meet up with friends spontaneously. Toggle "Open to hang out" when you\'re free.',
  },
  {
    emoji: '🗺️',
    accent: '#EC4899',
    accentBg: '#FCE7F3',
    title: 'Plan trips together',
    subtitle: 'Group votes & itineraries',
    body: 'Coordinate trips with friends — vote on places, build day-by-day plans, and split bookings. Travel made easy.',
  },
];

export default function WelcomeTutorial({ onClose }) {
  const [index, setIndex] = useState(0);
  const slide = SLIDES[index];
  const isLast = index === SLIDES.length - 1;

  // Lock body scroll while open
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);

  const finish = () => {
    try { localStorage.setItem(KEY, '1'); } catch {}
    onClose?.();
  };

  const next = () => {
    if (isLast) finish();
    else setIndex(i => i + 1);
  };

  const back = () => setIndex(i => Math.max(0, i - 1));

  return (
    <div className="fixed inset-0 z-[30000] flex items-center justify-center" style={{ background: 'rgba(20,20,19,0.6)', backdropFilter: 'blur(4px)' }}>
      <div
        className="relative bg-white card-shadow-elevated flex flex-col"
        style={{ width: 'calc(100% - 32px)', maxWidth: '380px', borderRadius: '24px', maxHeight: '92vh' }}
      >
        {/* Skip */}
        <button
          onClick={finish}
          className="absolute top-4 right-4 z-10 w-8 h-8 flex items-center justify-center rounded-full"
          style={{ background: '#F0EFE9' }}
          aria-label="Skip tutorial"
        >
          <X size={16} color="#141413" />
        </button>

        {/* Hero */}
        <div
          className="flex items-center justify-center"
          style={{ height: '180px', background: slide.accentBg, borderRadius: '24px 24px 0 0' }}
        >
          <span style={{ fontSize: '88px' }}>{slide.emoji}</span>
        </div>

        {/* Content */}
        <div className="px-6 pt-6 pb-5 flex-1">
          <p className="font-poppins font-semibold mb-1" style={{ fontSize: '12px', letterSpacing: '0.08em', textTransform: 'uppercase', color: slide.accent }}>
            {slide.subtitle}
          </p>
          <h2 className="font-poppins font-bold mb-2" style={{ fontSize: '22px', color: '#141413', letterSpacing: '-0.5px' }}>
            {slide.title}
          </h2>
          <p className="font-inter" style={{ fontSize: '14px', color: '#72706A', lineHeight: 1.5 }}>
            {slide.body}
          </p>
        </div>

        {/* Dots */}
        <div className="flex items-center justify-center gap-1.5 pb-4">
          {SLIDES.map((_, i) => (
            <div
              key={i}
              className="rounded-full transition-all"
              style={{
                height: '6px',
                width: i === index ? '20px' : '6px',
                background: i === index ? slide.accent : '#E8E6DC',
              }}
            />
          ))}
        </div>

        {/* Actions */}
        <div className="px-6 pb-6 flex items-center gap-3">
          {index > 0 ? (
            <button
              onClick={back}
              className="flex items-center justify-center font-poppins font-semibold"
              style={{ height: '48px', width: '48px', borderRadius: '12px', border: '1.5px solid #E8E6DC', color: '#141413' }}
              aria-label="Back"
            >
              <ChevronLeft size={18} />
            </button>
          ) : (
            <button
              onClick={finish}
              className="font-poppins font-semibold"
              style={{ height: '48px', padding: '0 16px', borderRadius: '12px', color: '#72706A', fontSize: '13px' }}
            >
              Skip
            </button>
          )}

          <button
            onClick={next}
            className="flex-1 flex items-center justify-center gap-1.5 font-poppins font-semibold text-white"
            style={{ height: '48px', borderRadius: '12px', background: slide.accent, fontSize: '14px' }}
          >
            {isLast ? "Let's go" : 'Next'}
            {!isLast && <ChevronRight size={16} />}
          </button>
        </div>
      </div>
    </div>
  );
}

WelcomeTutorial.STORAGE_KEY = KEY;