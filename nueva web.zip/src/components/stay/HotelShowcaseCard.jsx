import { Link, useNavigate } from 'react-router-dom';
import { Star, MessageCircle } from 'lucide-react';
import AddToCartButton from '@/components/ui/AddToCartButton';
import { notifyQuote } from '@/lib/notifyQuote';

const WHATSAPP_NUMBER = '18090000000';

function buildHotelWhatsAppLink(hotel) {
  const lines = [
    '¡Hola Jac Tour and Transfers! 👋',
    '',
    'Me gustaría cotizar información de hospedaje:',
    '',
    `🏨 Hotel: ${hotel.name}`,
    `📍 Ubicación: ${hotel.address || hotel.neighborhood || 'Bávaro, Punta Cana'}`,
    '',
    '¿Me pueden enviar tarifas y disponibilidad? ¡Gracias!',
  ];
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join('\n'))}`;
}

export default function HotelShowcaseCard({ hotel }) {
  const navigate = useNavigate();
  const placeVenue = { ...hotel, category: 'stay', avg_rating: hotel.avg_rating || hotel.rating, cover_image_url: hotel.cover_image_url || hotel.image };
  const path = `/place/${hotel.id}`;
  const Shell = ({ children }) => <Link to={path} state={{ venue: placeVenue }} className="block h-full">{children}</Link>;
  const handleBookNow = (event) => {
    event.preventDefault();
    event.stopPropagation();
    navigate(`${path}#book-now`, { state: { venue: placeVenue } });
  };
  const handleQuote = (event) => {
    event.preventDefault();
    event.stopPropagation();
    notifyQuote({ type: 'Hotel', hotel: hotel.name, source: 'Stay - tarjeta' });
    window.open(buildHotelWhatsAppLink(hotel), '_blank', 'noopener,noreferrer');
  };
  const price = hotel.price || `${'€'.repeat(hotel.price_range || 3)}`;
  const rating = Number(hotel.avg_rating || hotel.rating || 4.8).toFixed(1);
  const address = hotel.address || hotel.neighborhood || 'Augsburg';

  return (
    <div className="group h-full overflow-visible">
      <Shell>
        <article className="relative aspect-square overflow-hidden rounded-[24px] bg-[#181818] cursor-pointer transition-transform duration-300 ease-out group-hover:-translate-y-1" style={{ boxShadow: '0 18px 44px rgba(14,14,14,0.10)' }}>
          <img
            src={hotel.cover_image_url || hotel.image}
            alt={hotel.name}
            loading="lazy"
            className="h-[118%] w-full object-cover transition-all duration-300 ease-out group-hover:scale-[1.06] group-hover:brightness-75"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/[0.96]" />
          <div className="absolute left-4 top-4 z-10"><AddToCartButton venue={placeVenue} /></div>
          <div className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5 text-roam-text">
            <Star size={13} fill="#0E0E0E" />
            <span className="font-inter text-xs font-bold">{rating}</span>
          </div>
          <div className="absolute bottom-[18px] md:bottom-[-30px] left-[18px] right-[18px] font-inter text-white transition-transform duration-300 ease-out md:group-hover:-translate-y-12">
            <h3 className="m-0 font-inter text-[18px] font-medium leading-tight tracking-[-0.03em] text-white">{hotel.name}</h3>
            <p className="mt-2 flex justify-between gap-3 text-xs text-white/70">
              <span className="truncate">{address}</span>
              <span className="shrink-0"><span className="font-neue" style={{ fontSize: '13px', color: '#FFFFFF' }}>{price}</span> · {hotel.sub_category || 'Hotel'}</span>
            </p>
            <div className="mt-3 flex gap-2 translate-y-0 opacity-100 md:translate-y-4 md:opacity-0 transition-all duration-300 ease-out md:group-hover:translate-y-0 md:group-hover:opacity-100">
              <span className="flex h-9 flex-1 items-center justify-center rounded-full border border-white/35 bg-white/10 text-xs font-semibold text-white transition-all duration-200 hover:border-[#571AFF] hover:bg-[#571AFF] hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]">Learn More</span>
              <span onClick={handleQuote} className="flex h-9 flex-1 items-center justify-center gap-1.5 rounded-full bg-[#25D366] text-xs font-bold text-white transition-all duration-200 hover:shadow-[0_12px_28px_rgba(37,211,102,0.28)]"><MessageCircle size={13} /> Cotizar</span>
            </div>
          </div>
        </article>
      </Shell>
    </div>
  );
}