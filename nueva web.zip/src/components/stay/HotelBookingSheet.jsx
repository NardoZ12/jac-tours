import { useState, useMemo } from 'react';
import { X, Calendar as CalendarIcon, Minus, Plus } from 'lucide-react';
import { format, differenceInCalendarDays } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import ConfettiEffect from '../ui/ConfettiEffect';
import BookingConfirmation from '../booking/BookingConfirmation';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';

function genCode() {
  return 'H' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

/**
 * Hotel-specific booking flow with a date-range calendar.
 * Steps: 0 = pick dates + guests + room summary
 *        1 = special requests
 *        2 = confirm + price breakdown
 *        success = confirmation
 */
export default function HotelBookingSheet({ venue, room, onClose }) {
  const today = new Date();
  const [step, setStep] = useState(0);
  const [range, setRange] = useState(undefined);
  const [guests, setGuests] = useState(2);
  const [requests, setRequests] = useState('');
  const [showCalendar, setShowCalendar] = useState(false);
  const [loading, setLoading] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const [code, setCode] = useState('');
  const [bookingId, setBookingId] = useState(null);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const pricePerNight = room?.price || (venue.price_range || 2) * 250;
  const maxGuests = room?.guests || 4;

  const nights = useMemo(() => {
    if (!range?.from || !range?.to) return 0;
    return Math.max(1, differenceInCalendarDays(range.to, range.from));
  }, [range]);

  const subtotal = pricePerNight * nights;
  const taxes = Math.round(subtotal * 0.17);
  const total = subtotal + taxes;
  const datesValid = range?.from && range?.to && nights > 0;

  const confirm = async () => {
    if (!datesValid) return;
    setLoading(true);
    setError(null);
    const confirmationCode = genCode();
    const checkInISO = format(range.from, 'yyyy-MM-dd');
    const checkOutISO = format(range.to, 'yyyy-MM-dd');

    try {
      setCode(confirmationCode);
      setBookingId(null);
      setConfetti(true);
      setTimeout(() => setSuccess(true), 500);
    } catch (e) {
      setError(e?.message || 'Could not complete booking. Please try again.');
    }
    setLoading(false);
  };

  const incGuests = () => setGuests(g => Math.min(maxGuests, g + 1));
  const decGuests = () => setGuests(g => Math.max(1, g - 1));

  return (
    <>
      <ConfettiEffect active={confetti} />
      <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-3 flex-shrink-0">
          <div className="w-10 h-1 rounded-full" style={{ background: '#E8E6DC' }} />
        </div>

        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-5 z-10 w-8 h-8 flex items-center justify-center rounded-full"
          style={{ background: '#F0EFE9' }}
        >
          <X size={16} color="#141413" />
        </button>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-5" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 32px)' }}>
          {success ? (
            <BookingConfirmation
              booking={{
                confirmationCode: code,
                bookingId,
                venue,
                type: 'stay',
                dateLabel: `${format(range.from, 'MMM d')} → ${format(range.to, 'MMM d')}`,
                timeLabel: `${nights} night${nights > 1 ? 's' : ''}`,
                partyLabel: `${guests} guest${guests > 1 ? 's' : ''} · ${room?.name || 'Standard'}`,
                total,
                currency: 'EUR',
              }}
              onClose={onClose}
            />
          ) : step === 0 ? (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Choose your dates</h2>

              {/* Date range card */}
              <button
                onClick={() => setShowCalendar(s => !s)}
                className="w-full rounded-2xl p-4 mb-3 flex items-center gap-3 text-left"
                style={{ background: '#F0EFE9' }}
              >
                <CalendarIcon size={20} color="#1F1B2E" />
                <div className="flex-1">
                  <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Check-in → Check-out</p>
                  <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>
                    {range?.from ? format(range.from, 'EEE, MMM d') : 'Select dates'}
                    {range?.from && ' → '}
                    {range?.to ? format(range.to, 'EEE, MMM d') : ''}
                  </p>
                </div>
                <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#0EA5E9' }}>
                  {showCalendar ? 'Done' : 'Edit'}
                </span>
              </button>

              {showCalendar && (
                <div className="rounded-2xl mb-3" style={{ background: '#FFF', border: '1.5px solid #E8E6DC' }}>
                  <div className="flex justify-center">
                    <Calendar
                      mode="range"
                      selected={range}
                      onSelect={setRange}
                      disabled={{ before: today }}
                      numberOfMonths={1}
                    />
                  </div>
                  {range?.from && <button type="button" onClick={() => setRange(undefined)} className="mx-3 mb-3 w-[calc(100%-24px)] rounded-full border border-[#E8E6DC] bg-white px-4 py-2 font-inter text-xs font-semibold transition-colors hover:bg-[#F7F4FF]" style={{ color: '#571AFF' }}>Clear dates</button>}
                </div>
              )}

              {/* Guests stepper */}
              <div className="rounded-2xl p-4 mb-3 flex items-center justify-between" style={{ background: '#F0EFE9' }}>
                <div>
                  <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Guests</p>
                  <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>
                    {guests} guest{guests > 1 ? 's' : ''}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={decGuests}
                    disabled={guests <= 1}
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ background: '#FFF', border: '1.5px solid #E8E6DC', opacity: guests <= 1 ? 0.4 : 1 }}
                  >
                    <Minus size={14} color="#141413" />
                  </button>
                  <span className="font-poppins font-bold w-5 text-center" style={{ fontSize: '16px', color: '#141413' }}>{guests}</span>
                  <button
                    onClick={incGuests}
                    disabled={guests >= maxGuests}
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ background: '#FFF', border: '1.5px solid #E8E6DC', opacity: guests >= maxGuests ? 0.4 : 1 }}
                  >
                    <Plus size={14} color="#141413" />
                  </button>
                </div>
              </div>

              {/* Summary */}
              <div className="rounded-2xl p-4 mb-4" style={{ background: '#FFF1EC' }}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{room?.name || 'Standard Room'}</span>
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{pricePerNight.toLocaleString()} / night</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{nights} night{nights > 1 ? 's' : ''}</span>
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{total.toLocaleString()}</span>
                </div>
              </div>

              <button
                onClick={() => setStep(1)}
                disabled={!datesValid}
                className="btn-primary"
              >
                Continue →
              </button>
            </>
          ) : step === 1 ? (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Special requests</h2>
              <textarea
                value={requests}
                onChange={e => setRequests(e.target.value)}
                placeholder="High floor, quiet room, late check-in..."
                rows={4}
                className="w-full font-inter outline-none resize-none mb-4"
                style={{ background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '12px', padding: '12px 16px', fontSize: '14px' }}
              />
              <button onClick={() => setStep(2)} className="btn-primary">
                Continue →
              </button>
            </>
          ) : (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Confirm booking</h2>
              <div className="rounded-2xl p-4 mb-3" style={{ background: '#F0EFE9' }}>
                <div className="space-y-2">
                  {[
                    ['Hotel', venue.name],
                    ['Room', room?.name || 'Standard Room'],
                    ['Check-in', format(range.from, 'EEE, MMM d')],
                    ['Check-out', format(range.to, 'EEE, MMM d')],
                    ['Nights', `${nights}`],
                    ['Guests', `${guests}`],
                  ].map(([l, v]) => (
                    <div key={l} className="flex items-center justify-between">
                      <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{l}</span>
                      <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price breakdown */}
              <div className="rounded-2xl p-4 mb-4" style={{ background: '#FFF1EC' }}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{pricePerNight} × {nights} nights</span>
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between mb-2 pb-2" style={{ borderBottom: '1px solid #E8E6DC' }}>
                  <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{'Taxes & fees'}</span>
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{taxes.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>Total</span>
                  <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{total.toLocaleString()}</span>
                </div>
              </div>

              <p className="font-inter mb-3 text-center" style={{ fontSize: '12px', color: '#72706A' }}>
                ✓ Free cancellation up to 48h before check-in
              </p>
              {error && (
                <p className="font-inter mb-2 text-center" style={{ fontSize: '12px', color: '#DC2626' }}>{error}</p>
              )}
              <button
                onClick={confirm}
                disabled={loading}
                className="btn-primary"
              >
                {loading ? 'Booking...' : <>Confirm · <span className="font-neue" style={{ fontSize: '13px', color: '#FFFFFF' }}>€{total.toLocaleString()}</span></>}
              </button>
            </>
          )}
        </div>
      </ResponsiveSheetShell>
    </>
  );
}