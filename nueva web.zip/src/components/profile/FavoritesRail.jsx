import { useNavigate } from 'react-router-dom';
import VenuePhoto from '@/components/ui/VenuePhoto';
import { RotateCcw } from 'lucide-react';

const TYPE_PATH = { eat: '/eat', stay: '/stay', do: '/do' };

/**
 * Surface the user's most-booked venues for quick rebooking.
 * Builds a frequency map from booking history, sorts by count, and renders
 * a horizontally scrolling rail of "favorite" venues with a one-tap rebook CTA.
 */
export default function FavoritesRail({ bookings, venuesById }) {
  const navigate = useNavigate();

  // Build {venue_id: {count, lastBooking, type}} map
  const freq = {};
  for (const b of bookings) {
    if (!b.venue_id) continue;
    if (!freq[b.venue_id]) {
      freq[b.venue_id] = { count: 0, last: b, type: b.booking_type };
    }
    freq[b.venue_id].count += 1;
  }

  const favorites = Object.entries(freq)
    .filter(([, v]) => v.count >= 1)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 6)
    .map(([venueId, meta]) => ({
      venueId,
      meta,
      venue: venuesById[venueId],
    }))
    .filter(f => f.venue);

  if (favorites.length === 0) return null;

  return (
    <div className="mb-5">
      <div className="flex items-center justify-between px-5 mb-3">
        <h2 className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>
          Your favorites
        </h2>
        <span className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>One-tap rebook</span>
      </div>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide px-5 pb-1">
        {favorites.map(({ venueId, meta, venue }) => {
          const type = meta.type || venue.category;
          const lastParty = meta.last.party_size || 2;
          return (
            <div
              key={venueId}
              className="flex-shrink-0 rounded-2xl overflow-hidden card-shadow bg-white"
              style={{ width: '160px' }}
            >
              <VenuePhoto venue={venue} height={100} rounded="16px 16px 0 0" />
              <div className="p-3">
                <p className="font-poppins font-semibold truncate" style={{ fontSize: '13px', color: '#141413' }}>
                  {venue.name}
                </p>
                <p className="font-inter mb-2" style={{ fontSize: '12px', color: '#72706A' }}>
                  Booked {meta.count}× · {venue.neighborhood || venue.city}
                </p>
                <button
                  onClick={() => navigate(`${TYPE_PATH[type === 'restaurant' ? 'eat' : type === 'hotel' ? 'stay' : type === 'experience' ? 'do' : type]}/${venueId}?rebook=1&party=${lastParty}`)}
                  className="w-full flex items-center justify-center gap-1 font-poppins font-semibold"
                  style={{
                    fontSize: '12px',
                    padding: '6px 10px',
                    borderRadius: '8px',
                    background: '#1F1B2E',
                    color: '#FFF',
                    minHeight: '32px',
                  }}
                >
                  <RotateCcw size={11} /> Rebook
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}