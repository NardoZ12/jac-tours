import { useState, useMemo } from 'react';
import { Building2, Compass, Sun, UtensilsCrossed } from 'lucide-react';
import BookingHistoryRow from './BookingHistoryRow';

const FILTERS = [
  { key: 'all', label: 'All', icon: Sun },
  { key: 'eat', label: 'Eat', icon: UtensilsCrossed },
  { key: 'stay', label: 'Stay', icon: Building2 },
  { key: 'do', label: 'Do', icon: Compass },
];

function bookingEndMs(b) {
  if (b.check_out) return new Date(b.check_out).getTime();
  if (b.date) {
    const t = b.time || (b.booking_type === 'stay' ? '11:00' : '23:59');
    const ms = new Date(`${b.date}T${t}`).getTime();
    if (!Number.isNaN(ms)) return ms;
  }
  return new Date(b.created_date || 0).getTime();
}

export default function MyBookingsTab({ bookings = [], venuesById = {} }) {
  const [filter, setFilter] = useState('all');
  const [tab, setTab] = useState('upcoming');

  const { upcoming, past } = useMemo(() => {
    const now = Date.now();
    const visible = filter === 'all' ? bookings : bookings.filter(b => b.booking_type === filter);
    const up = [];
    const ps = [];
    for (const b of visible) {
      const isPast = bookingEndMs(b) < now || b.status === 'completed' || b.status === 'cancelled' || b.status === 'no_show';
      (isPast ? ps : up).push(b);
    }
    up.sort((a, b) => bookingEndMs(a) - bookingEndMs(b));
    ps.sort((a, b) => bookingEndMs(b) - bookingEndMs(a));
    return { upcoming: up, past: ps };
  }, [bookings, filter]);

  const list = tab === 'upcoming' ? upcoming : past;
  const EmptyIcon = tab === 'upcoming' ? Sun : Compass;

  return (
    <div>
      <div className="mb-4 grid grid-cols-2 gap-2 rounded-[22px] bg-[#F0EFE9] p-1">
        {[
          { key: 'upcoming', label: 'Upcoming', count: upcoming.length },
          { key: 'past', label: 'Past', count: past.length },
        ].map(({ key, label, count }) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className="flex h-11 items-center justify-center gap-1.5 rounded-[18px] font-inter text-xs font-semibold transition-all duration-300 ease-out"
            style={{
              background: tab === key ? '#FFFFFF' : 'transparent',
              color: tab === key ? '#141413' : '#72706A',
              boxShadow: tab === key ? '0 8px 18px rgba(14,14,14,0.08)' : 'none',
            }}
          >
            {label}
            <span className="font-inter text-xs opacity-70">({count})</span>
          </button>
        ))}
      </div>

      <div className="-mx-3 -my-5 mb-0 flex gap-2 overflow-x-auto px-3 py-5 scrollbar-hide">
        {FILTERS.map(({ key, label, icon: Icon }) => {
          const active = filter === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className="flex flex-shrink-0 items-center gap-1.5 rounded-full px-4 py-2.5 font-inter text-xs font-semibold transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#571AFF] hover:text-white hover:shadow-[0_12px_28px_rgba(87,26,255,0.18)]"
              style={{
                background: active ? '#0E0E0E' : '#FFFFFF',
                color: active ? '#FFFFFF' : '#555550',
                border: active ? '1px solid #0E0E0E' : '1px solid rgba(14,14,14,0.08)',
              }}
            >
              <Icon size={13} />
              {label}
            </button>
          );
        })}
      </div>

      {list.length === 0 ? (
        <div className="rounded-[26px] border border-black/[0.06] bg-white px-5 py-10 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#F8F7F4] text-[#0E0E0E]">
            <EmptyIcon size={20} />
          </div>
          <p className="mt-3 font-inter text-sm text-[#72706A]">
            {tab === 'upcoming' ? 'No upcoming reservations. Time to explore.' : 'No past bookings yet.'}
          </p>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map(b => <BookingHistoryRow key={b.id} booking={b} venue={venuesById[b.venue_id]} />)}
        </div>
      )}
    </div>
  );
}