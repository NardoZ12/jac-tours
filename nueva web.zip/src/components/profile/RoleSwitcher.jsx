import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Building2, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';

/**
 * Demo-only role switcher.
 * Tap the user avatar to toggle between "user" (regular explorer)
 * and "venue_owner" (business dashboard) roles.
 */
export default function RoleSwitcher({ user, onChange }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const currentRole = user?.role === 'venue_owner' ? 'venue_owner' : 'user';
  const initial = (user?.full_name || 'E')[0];

  const switchTo = async (role) => {
    if (saving || role === currentRole) {
      setOpen(false);
      return;
    }
    setSaving(true);
    try {
      await base44.auth.updateMe({ role });
      onChange?.({ ...user, role });
    } catch {}
    setSaving(false);
    setOpen(false);
    if (role === 'venue_owner') navigate('/dashboard');else
    navigate('/');
  };

  return null;


































































}