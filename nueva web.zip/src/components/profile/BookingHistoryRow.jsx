import { useNavigate } from 'react-router-dom';
import { Building2, Compass, RotateCcw, UtensilsCrossed } from 'lucide-react';

const TYPE_PATH = { eat: '/eat', stay: '/stay', do: '/do' };
const TYPE_META = {
  eat: { label: 'Eat', icon: UtensilsCrossed },
  stay: { label: 'Stay', icon: Building2 },
  do: { label: 'Do', icon: Compass },
};

const STATUS_STYLES = {
  confirmed: { label: 'Confirmed', bg: '#F0FDF4', color: '#16A34A' },
  pending: { label: 'Pending', bg: '#FFFBEB', color: '#D97706' },
  completed: { label: 'Completed', bg: '#F0EFE9', color: '#72706A' },
  cancelled: { label: 'Cancelled', bg: '#FEF2F2', color: '#DC2626' },
  no_show: { label: 'No-show', bg: '#FEF2F2', color: '#DC2626' },
};

function formatDate(booking) {
  if (booking.check_in && booking.check_out) return `${booking.check_in} → ${booking.check_out}`;
  return `${booking.date || 'Date pending'}${booking.time ? ` · ${booking.time}` : ''}`;
}

export default function BookingHistoryRow({ booking, venue }) {
  const navigate = useNavigate();
  const type = booking.booking_type || 'eat';
  const status = STATUS_STYLES[booking.status] || STATUS_STYLES.confirmed;
  const meta = TYPE_META[type] || TYPE_META.eat;
  const Icon = meta.icon;
  const imageUrl = venue?.cover_image_url;

  const handleRebook = (e) => {
    e.stopPropagation();
    if (booking.venue_id) {
      navigate(`${TYPE_PATH[type]}/${booking.venue_id}?rebook=1&party=${booking.party_size || 2}`);
    }
  };

  const handleOpen = () => {
    if (booking.venue_id) navigate(`${TYPE_PATH[type]}/${booking.venue_id}`);
  };

  return (
    <article
      onClick={handleOpen}
      className="group overflow-hidden rounded-[26px] border border-black/[0.06] bg-white shadow-[0_10px_24px_rgba(14,14,14,0.07)] transition-all duration-300 ease-out hover:-translate-y-1 hover:shadow-[0_16px_34px_rgba(14,14,14,0.11)]"
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter') handleOpen(); }}
    >
      <div className="relative h-36 bg-[#E8E7E3]">
        {imageUrl ? (
          <img src={imageUrl} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-[linear-gradient(135deg,#F8F7F4_0%,#E8E7E3_100%)] text-[#0E0E0E]">
            <Icon size={30} />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-black/5 to-transparent" />
        <span className="absolute left-3 top-3 inline-flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-1.5 font-inter text-xs font-semibold text-[#141413] backdrop-blur-xl">
          <Icon size={13} />
          {meta.label}
        </span>
        <span className="absolute right-3 top-3 rounded-full px-3 py-1.5 font-inter text-xs font-semibold backdrop-blur-xl" style={{ background: status.bg, color: status.color }}>
          {status.label}
        </span>
      </div>

      <div className="p-4">
        <h3 className="truncate font-inter text-[15px] font-semibold tracking-[-0.02em] text-[#141413]">
          {booking.venue_name || venue?.name || 'Venue'}
        </h3>
        <p className="mt-2 font-inter text-xs leading-5 text-[#72706A]">
          {formatDate(booking)} · {booking.party_size || 2} guests
        </p>
        {(venue?.neighborhood || venue?.city) && (
          <p className="mt-1 truncate font-inter text-xs leading-5 text-[#72706A]">
            {venue.neighborhood || venue.city}
          </p>
        )}
        <button
          onClick={handleRebook}
          aria-label={`Rebook ${booking.venue_name || venue?.name || 'venue'}`}
          className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-[#0E0E0E] px-4 py-2.5 font-inter text-xs font-semibold text-white transition-all duration-300 ease-out hover:bg-[#571AFF] hover:shadow-[0_12px_26px_rgba(87,26,255,0.24)]"
        >
          <RotateCcw size={13} />
          Rebook
        </button>
      </div>
    </article>
  );
}