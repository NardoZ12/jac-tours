import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BadgeCheck, MessageSquare, UtensilsCrossed, Building2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import RatingStars from '@/components/ui/RatingStars';
import { findContentByIds } from '@/lib/contentTables';

/**
 * Lists all reviews the current user has left for restaurants & hotels.
 * Shows the rating, body, venue, date, and a "Verified visit" badge when applicable.
 */
export default function MyReviewsTab({ userId }) {
  const [reviews, setReviews] = useState([]);
  const [venuesById, setVenuesById] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setReviews([]);
    setVenuesById({});
    setLoading(false);
  }, [userId]);

  return (
    <div className="px-5 mb-5">
      <div className="flex items-center gap-2 mb-3">
        <MessageSquare size={16} color="#141413" />
        <h2 className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>
          My reviews
        </h2>
        {reviews.length > 0 && (
          <span
            className="font-poppins font-semibold"
            style={{ fontSize: '12px', color: '#72706A', background: '#F0EFE9', padding: '2px 8px', borderRadius: '99px' }}
          >
            {reviews.length}
          </span>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[0, 1].map(i => (
            <div key={i} className="skeleton rounded-2xl" style={{ height: '110px' }} />
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <div className="rounded-2xl bg-white card-shadow p-6 text-center">
          <p style={{ fontSize: '32px' }}>✍️</p>
          <p className="font-poppins font-semibold mt-2" style={{ fontSize: '14px', color: '#141413' }}>
            No reviews yet
          </p>
          <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>
            After your next visit, you'll be able to share feedback here.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {reviews.map(r => (
            <ReviewRow key={r.id} review={r} venue={venuesById[r.venue_id]} />
          ))}
        </div>
      )}
    </div>
  );
}

function ReviewRow({ review, venue }) {
  const isHotel = venue?.category === 'stay' || venue?.category === 'hotel';
  const Icon = isHotel ? Building2 : UtensilsCrossed;
  const route = isHotel ? `/stay/${venue.id}` : `/eat/${venue.id}`;
  const dateLabel = review.created_date
    ? new Date(review.created_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : '';

  return (
    <div className="rounded-2xl bg-white card-shadow p-4">
      <div className="flex items-start justify-between gap-3 mb-2">
        <Link to={route} className="flex items-center gap-2 min-w-0">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: isHotel ? '#E0F2FE' : '#FFF0F3' }}
          >
            <Icon size={16} color={isHotel ? '#0071C2' : '#FF385C'} />
          </div>
          <div className="min-w-0">
            <p className="font-poppins font-semibold truncate" style={{ fontSize: '14px', color: '#141413' }}>
              {venue?.name || 'Venue'}
            </p>
            <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>
              {isHotel ? 'Hotel' : 'Restaurant'}
              {venue?.neighborhood ? ` · ${venue.neighborhood}` : ''}
              {dateLabel ? ` · ${dateLabel}` : ''}
            </p>
          </div>
        </Link>
        {review.visit_verified ? (
          <span
            className="flex items-center gap-1 flex-shrink-0 font-poppins font-semibold"
            style={{ fontSize: '12px', color: '#008A05', background: '#E8F7E8', padding: '4px 8px', borderRadius: '99px' }}
          >
            <BadgeCheck size={12} /> Verified visit
          </span>
        ) : (
          <span
            className="flex-shrink-0 font-poppins font-semibold"
            style={{ fontSize: '12px', color: '#72706A', background: '#F0EFE9', padding: '4px 8px', borderRadius: '99px' }}
          >
            Unverified
          </span>
        )}
      </div>

      <div className="mb-1.5">
        <RatingStars rating={review.rating} showCount={false} size={14} />
      </div>

      {review.title && (
        <p className="font-poppins font-semibold" style={{ fontSize: '13px', color: '#141413' }}>
          {review.title}
        </p>
      )}
      {review.body && (
        <p className="font-inter" style={{ fontSize: '13px', color: '#5E5E5E', lineHeight: 1.5 }}>
          {review.body}
        </p>
      )}
    </div>
  );
}