import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import VenuePhoto from '@/components/ui/VenuePhoto';
import { findContentByIds } from '@/lib/contentTables';

const TYPE_PATH = { eat: '/eat', stay: '/stay', do: '/do', restaurant: '/eat', hotel: '/stay', experience: '/do' };
const TYPE_LABEL = { eat: 'EAT', stay: 'STAY', do: 'DO', restaurant: 'EAT', hotel: 'STAY', experience: 'DO' };
const TYPE_COLOR = { eat: '#FF7849', stay: '#7AB8DD', do: '#A3CD7B', restaurant: '#FF7849', hotel: '#7AB8DD', experience: '#A3CD7B' };

/**
 * "My Favorites" — lists all venues the user has hearted across the app.
 * Reads from SavedPlace entity (user_id scoped) + hydrates with Venue data.
 */
export default function MyFavorites() {
  const [items, setItems] = useState([]);
  const loading = false;

  const handleUnsave = (saveId, e) => {
    e.preventDefault();
    e.stopPropagation();
    setItems(prev => prev.filter(x => x.save.id !== saveId));
  };

  return (
    <div className="px-5 mb-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Heart size={16} color="#EC4899" fill="#EC4899" />
          <h2 className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>My Favorites</h2>
        </div>
        {items.length > 0 && (
          <span className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>{items.length} saved</span>
        )}
      </div>

      {loading ? (
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
          {[0, 1, 2].map(i => (
            <div key={i} className="flex-shrink-0 skeleton rounded-2xl" style={{ width: '160px', height: '180px' }} />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl bg-white card-shadow p-6 text-center">
          <Heart size={28} color="#EC4899" className="mx-auto mb-2" />
          <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>No favorites yet</p>
          <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>
            Tap the heart on any venue to save it here.
          </p>
        </div>
      ) : (
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
          {items.map(({ save, venue }) => {
            const path = `${TYPE_PATH[venue.category] || '/eat'}/${venue.id}`;
            const accent = TYPE_COLOR[venue.category] || '#FF7849';
            return (
              <Link
                key={save.id}
                to={path}
                className="flex-shrink-0 rounded-2xl overflow-hidden card-shadow bg-white"
                style={{ width: '160px' }}
              >
                <div className="relative">
                  <VenuePhoto venue={venue} height={100} rounded="16px 16px 0 0" />
                  <span className="absolute top-2 left-2 font-poppins font-semibold text-white" style={{ fontSize: '12px', letterSpacing: '0.06em', background: accent, padding: '2px 7px', borderRadius: '6px' }}>
                    {TYPE_LABEL[venue.category]}
                  </span>
                  <button
                    onClick={(e) => handleUnsave(save.id, e)}
                    aria-label="Remove from favorites"
                    className="absolute top-2 right-2 w-7 h-7 flex items-center justify-center rounded-full"
                    style={{ background: 'rgba(255,255,255,0.95)' }}
                  >
                    <Heart size={13} color="#EC4899" fill="#EC4899" />
                  </button>
                </div>
                <div className="p-3">
                  <p className="font-poppins font-semibold truncate" style={{ fontSize: '13px', color: '#141413' }}>
                    {venue.name}
                  </p>
                  <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>
                    {venue.neighborhood || venue.city || venue.sub_category}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}