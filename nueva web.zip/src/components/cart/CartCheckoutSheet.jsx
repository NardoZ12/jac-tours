import { useState, useMemo } from 'react';
import { X, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import ConfettiEffect from '@/components/ui/ConfettiEffect';
import BookingConfirmation from '@/components/booking/BookingConfirmation';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';
import PickupMapSelector from '@/components/do/PickupMapSelector';
import PaypalCardForm from '@/components/payment/PaypalCardForm';
import { useCart } from '@/lib/CartContext';

function genCode() {
  return 'C' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

const DEFAULT_TIMES = ['09:00', '11:00', '14:00', '16:00'];

/**
 * Multi-product cart checkout. Collects a shared date/time/pickup + customer
 * info for all items in the cart, then confirms and clears the cart.
 */
export default function CartCheckoutSheet({ onClose }) {
  const { items, total, clear } = useCart();
  const today = new Date();
  const [step, setStep] = useState(0);
  const [date, setDate] = useState(null);
  const [time, setTime] = useState(DEFAULT_TIMES[0]);
  const [showCal, setShowCal] = useState(false);
  const [pickup, setPickup] = useState(null);
  const [confetti, setConfetti] = useState(false);
  const [code] = useState(genCode);
  const [success, setSuccess] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [paymentOption, setPaymentOption] = useState('deposit');

  const depositAmount = useMemo(() => Math.round(total * 0.3 * 100) / 100, [total]);
  const dueAtPickup = useMemo(() => Math.round((total - depositAmount) * 100) / 100, [total, depositAmount]);
  const payNow = paymentOption === 'deposit' ? depositAmount : total;

  const itemsList = items.map((i) => `• ${i.venueName} (${i.tierLabel}) — ${i.groupSize} pers — $${i.total}`).join('\n');

  const onPaid = () => {
    setConfetti(true);
    setSuccess(true);
  };

  // The cart is emptied once the buyer closes the confirmation (it is still shown inside it).
  const handleClose = () => {
    if (success) clear();
    onClose();
  };

  const buildBooking = () => {
    const confirmationCode = code;
    return {
      confirmationCode,
      venueName: `${items.length} experiencias`,
      tier: items.map((i) => i.tierLabel).join(', '),
      dateLabel: format(date, 'EEE, MMM d'),
      timeLabel: time,
      partyLabel: `${items.reduce((n, i) => n + i.groupSize, 0)} personas`,
      pickupLabel: pickup ? `${pickup.name}${pickup.area ? ` · ${pickup.area}` : ''}` : '',
      total,
      currency: 'USD',
      customerName,
      customerPhone,
      customerEmail,
      paymentOption,
      depositAmount,
      dueAtPickup,
      payNow,
      itemsList,
    };
  };

  return (
    <>
      <ConfettiEffect active={confetti} />
      <ResponsiveSheetShell onClose={handleClose} zIndex={30000}>
        <div className="flex justify-center pt-3 pb-3 flex-shrink-0">
          <div className="w-10 h-1 rounded-full" style={{ background: '#E8E6DC' }} />
        </div>
        <button onClick={handleClose} className="absolute top-4 right-5 z-10 w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>
          <X size={16} color="#141413" />
        </button>

        <div className="flex-1 overflow-y-auto px-5" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 32px)' }}>
          {success ? (
            <BookingConfirmation
              booking={{
                confirmationCode: code,
                venue: {
                  name: items.length === 1 ? items[0].venueName : `${items.length} experiencias`,
                  cover_image_url: items[0]?.cover_image_url,
                  neighborhood: items[0]?.sub_category,
                  city: 'Punta Cana',
                },
                type: 'cart',
                tier: 'Carrito',
                dateLabel: format(date, 'EEE, MMM d'),
                timeLabel: time,
                partyLabel: `${items.reduce((n, i) => n + i.groupSize, 0)} personas`,
                pickupLabel: pickup ? `${pickup.name}${pickup.area ? ` · ${pickup.area}` : ''}` : '',
                total,
                currency: 'USD',
                customerName,
                customerPhone,
                customerEmail,
                paymentOption,
                depositAmount,
                dueAtPickup,
                payNow,
              }}
              onClose={handleClose}
            />
          ) : step === 0 ? (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Fecha y ubicación</h2>

              <button onClick={() => setShowCal((s) => !s)} className="w-full rounded-2xl p-4 mb-3 flex items-center gap-3 text-left" style={{ background: '#F0EFE9' }}>
                <CalendarIcon size={20} color="#1F1B2E" />
                <div className="flex-1">
                  <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Fecha</p>
                  <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{date ? format(date, 'EEE, MMM d') : 'Selecciona fecha'}</p>
                </div>
                <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#4A7A35' }}>{showCal ? 'Listo' : 'Editar'}</span>
              </button>

              {showCal && (
                <div className="rounded-2xl mb-3" style={{ background: '#FFF', border: '1.5px solid #E8E6DC' }}>
                  <div className="flex justify-center">
                    <Calendar mode="single" selected={date || undefined} onSelect={(d) => d && setDate(d)} disabled={{ before: today }} numberOfMonths={1} />
                  </div>
                </div>
              )}

              <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Ubicación de recogida</p>
              <div className="mb-4">
                <PickupMapSelector value={pickup} onChange={setPickup} />
              </div>

              <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Hora disponible</p>
              <div className="grid grid-cols-4 gap-2 mb-4">
                {DEFAULT_TIMES.map((t) => (
                  <button key={t} onClick={() => setTime(t)} className="font-poppins font-semibold" style={{ height: '40px', borderRadius: '10px', fontSize: '13px', background: t === time ? '#141413' : '#FFF', color: t === time ? '#FFF' : '#141413', border: '1.5px solid ' + (t === time ? '#141413' : '#E8E6DC') }}>{t}</button>
                ))}
              </div>

              <p className="font-inter mb-2 mt-4" style={{ fontSize: '13px', color: '#72706A' }}>Tus datos</p>
              <div className="space-y-3 mb-4">
                <input type="text" placeholder="Nombre completo" value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                <input type="tel" placeholder="Teléfono" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
                <input type="email" placeholder="Correo electrónico" value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} className="w-full rounded-2xl px-4 py-3 font-inter" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }} />
              </div>

              <button onClick={() => setStep(1)} disabled={!date || !pickup || !customerName || !customerPhone || !customerEmail} className="btn-primary">Continuar →</button>
            </>
          ) : (
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Confirmar reserva</h2>
              <div className="rounded-2xl p-4 mb-3" style={{ background: '#F0EFE9' }}>
                <p className="font-inter mb-2" style={{ fontSize: '12px', color: '#72706A' }}>Experiencias en el carrito</p>
                <div className="space-y-1 mb-2">
                  {items.map((i) => (
                    <div key={i.key} className="flex items-center justify-between">
                      <span className="font-inter truncate" style={{ fontSize: '13px', color: '#141413' }}>{i.venueName} · {i.tierLabel} · {i.groupSize}p</span>
                      <span className="font-poppins font-semibold ml-2 shrink-0" style={{ fontSize: '13px', color: '#141413' }}>${i.total}</span>
                    </div>
                  ))}
                </div>
                <div className="space-y-2 pt-2" style={{ borderTop: '1px solid #E8E6DC' }}>
                  {[['Fecha', format(date, 'EEE, MMM d')], ['Hora', time], ['Recogida', pickup ? `${pickup.name}${pickup.area ? ` · ${pickup.area}` : ''}` : '—'], ['Nombre', customerName || '—'], ['Teléfono', customerPhone || '—'], ['Correo', customerEmail || '—']].map(([l, v]) => (
                    <div key={l} className="flex items-center justify-between">
                      <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{l}</span>
                      <span className="font-poppins font-semibold truncate ml-2" style={{ fontSize: '14px', color: '#141413' }}>{v}</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between pt-2" style={{ borderTop: '1px solid #E8E6DC' }}>
                    <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>Total</span>
                    <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>${total}</span>
                  </div>
                </div>
              </div>

              <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Opción de pago</p>
              <div className="space-y-2 mb-3">
                <button type="button" onClick={() => setPaymentOption('deposit')} className="w-full rounded-2xl p-4 text-left transition-all" style={{ background: paymentOption === 'deposit' ? '#141413' : '#FFF', border: '2px solid ' + (paymentOption === 'deposit' ? '#141413' : '#E8E6DC') }}>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-poppins font-bold" style={{ fontSize: '14px', color: paymentOption === 'deposit' ? '#FFFFFF' : '#141413' }}>Pagar 30% ahora</span>
                      <p className="font-inter" style={{ fontSize: '11px', color: paymentOption === 'deposit' ? 'rgba(255,255,255,0.7)' : '#72706A' }}>Restante ${dueAtPickup} al ser recogido</p>
                    </div>
                    <span className="font-poppins font-bold" style={{ fontSize: '16px', color: paymentOption === 'deposit' ? '#B6F02D' : '#141413' }}>${depositAmount}</span>
                  </div>
                </button>
                <button type="button" onClick={() => setPaymentOption('full')} className="w-full rounded-2xl p-4 text-left transition-all" style={{ background: paymentOption === 'full' ? '#141413' : '#FFF', border: '2px solid ' + (paymentOption === 'full' ? '#141413' : '#E8E6DC') }}>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-poppins font-bold" style={{ fontSize: '14px', color: paymentOption === 'full' ? '#FFFFFF' : '#141413' }}>Pagar total ahora</span>
                      <p className="font-inter" style={{ fontSize: '11px', color: paymentOption === 'full' ? 'rgba(255,255,255,0.7)' : '#72706A' }}>Pago completo al reservar</p>
                    </div>
                    <span className="font-poppins font-bold" style={{ fontSize: '16px', color: paymentOption === 'full' ? '#B6F02D' : '#141413' }}>${total}</span>
                  </div>
                </button>
              </div>

              <p className="font-inter mb-3 text-center" style={{ fontSize: '12px', color: '#72706A' }}>✓ Cancelación gratis hasta 24h antes</p>
              <PaypalCardForm
                amount={payNow}
                description={`Carrito · ${items.length} experiencias · ${code}`}
                booking={buildBooking()}
                onPaid={onPaid}
              />
            </>
          )}
        </div>
      </ResponsiveSheetShell>
    </>
  );
}