import { useState } from 'react';
import { Clock, Info } from 'lucide-react';

const MINUTES = ['00','05','10','15','20','25','30','35','40','45','50','55'];

const selStyle = {
  background: '#F0EFE9',
  border: '1.5px solid #E8E6DC',
  fontSize: '15px',
  color: '#141413',
  minHeight: '48px',
  appearance: 'none',
  WebkitAppearance: 'none',
  backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2210%22 height=%226%22 viewBox=%220 0 10 6%22%3E%3Cpath fill=%22%2372706A%22 d=%22M0 0l5 6 5-6z%22/%3E%3C/svg%3E")',
  backgroundRepeat: 'no-repeat',
  backgroundPosition: 'right 10px center',
  paddingRight: '26px',
};

export default function TimePicker({ value, onChange }) {
  const [format, setFormat] = useState('24h');
  const [h, m] = value.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;

  const update = (newH, newM) => onChange(String(newH).padStart(2, '0') + ':' + String(newM).padStart(2, '0'));

  const toggleBtn = (active) => ({
    height: '32px',
    fontSize: '12px',
    padding: '0 14px',
    borderRadius: '999px',
    fontWeight: 600,
    background: active ? '#141413' : '#F0EFE9',
    color: active ? '#FFF' : '#141413',
    border: '1.5px solid ' + (active ? '#141413' : '#E8E6DC'),
  });

  return (
    <div>
      <div className="flex gap-2 mb-2">
        <button type="button" onClick={() => setFormat('24h')} style={toggleBtn(format === '24h')}>24H</button>
        <button type="button" onClick={() => setFormat('12h')} style={toggleBtn(format === '12h')}>12H</button>
      </div>

      <div className="flex items-center gap-2">
        <Clock size={16} color="#571AFF" />
        {format === '24h' ? (
          <>
            <select value={h} onChange={(e) => update(Number(e.target.value), m)} style={selStyle} className="flex-1 rounded-xl px-3 py-2.5 font-poppins font-semibold cursor-pointer">
              {Array.from({ length: 24 }, (_, i) => i).map((i) => (
                <option key={i} value={i}>{String(i).padStart(2, '0')}</option>
              ))}
            </select>
            <span className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>:</span>
            <select value={m} onChange={(e) => update(h, Number(e.target.value))} style={selStyle} className="flex-1 rounded-xl px-3 py-2.5 font-poppins font-semibold cursor-pointer">
              {MINUTES.map((mm) => (
                <option key={mm} value={Number(mm)}>{mm}</option>
              ))}
            </select>
          </>
        ) : (
          <>
            <select value={h12} onChange={(e) => { let nh = Number(e.target.value) % 12; if (period === 'PM') nh += 12; update(nh, m); }} style={selStyle} className="flex-1 rounded-xl px-3 py-2.5 font-poppins font-semibold cursor-pointer">
              {Array.from({ length: 12 }, (_, i) => i + 1).map((i) => (
                <option key={i} value={i}>{i}</option>
              ))}
            </select>
            <span className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>:</span>
            <select value={m} onChange={(e) => update(h, Number(e.target.value))} style={selStyle} className="flex-1 rounded-xl px-3 py-2.5 font-poppins font-semibold cursor-pointer">
              {MINUTES.map((mm) => (
                <option key={mm} value={Number(mm)}>{mm}</option>
              ))}
            </select>
            <select value={period} onChange={(e) => { let nh = h12 % 12; if (e.target.value === 'PM') nh += 12; update(nh, m); }} style={{ ...selStyle, width: '72px', flex: 'none' }} className="rounded-xl px-3 py-2.5 font-poppins font-semibold cursor-pointer">
              <option value="AM">AM</option>
              <option value="PM">PM</option>
            </select>
          </>
        )}
      </div>

      <p className="font-inter mt-2 flex items-center gap-1.5" style={{ fontSize: '11px', color: '#72706A' }}>
        <Info size={12} color="#571AFF" />
        Le informaremos la hora exacta luego de la reserva.
      </p>
    </div>
  );
}