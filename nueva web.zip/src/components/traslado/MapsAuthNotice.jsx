import { AlertTriangle } from 'lucide-react';

const FIXES = {
  ApiNotActivatedMapError: 'Falta activar "Maps JavaScript API" en Google Cloud (APIs y servicios > Biblioteca > Maps JavaScript API > Habilitar).',
  ApiTargetBlockedMapError: 'La clave tiene restricción de APIs y no incluye "Maps JavaScript API". Agrégala en Restricciones de API de la clave.',
  RefererNotAllowedMapError: 'La clave no permite este sitio web. Agrega el dominio de abajo en Restricciones de sitios web de la clave.',
  BillingNotEnabledMapError: 'El proyecto de Google Cloud no tiene la facturación activada.',
  InvalidKeyMapError: 'Google dice que la clave no es válida.',
  MissingKeyMapError: 'No se envió ninguna clave a Google.',
  ExpiredKeyMapError: 'La clave expiró.',
  AuthFailure: 'Google rechazó la clave. Revisa que "Maps JavaScript API" esté habilitada y que la clave permita este dominio.',
};

export default function MapsAuthNotice({ code }) {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const fix = FIXES[code] || `Google devolvió el error ${code}.`;
  return (
    <div className="rounded-xl p-3 flex items-start gap-2.5" style={{ background: '#FFF3F3', border: '1.5px solid #E8A0A0' }}>
      <AlertTriangle size={16} color="#8A2820" className="mt-0.5 shrink-0" />
      <div className="min-w-0">
        <p className="font-inter font-semibold" style={{ fontSize: '12px', color: '#8A2820' }}>Google Maps bloqueó la carga del mapa ({code})</p>
        <p className="font-inter mt-0.5" style={{ fontSize: '12px', color: '#8A2820', lineHeight: 1.5 }}>{fix}</p>
        <p className="font-inter mt-1 break-all" style={{ fontSize: '11px', color: '#72706A' }}>Dominio actual: <span className="font-semibold">{origin}/*</span></p>
      </div>
    </div>
  );
}