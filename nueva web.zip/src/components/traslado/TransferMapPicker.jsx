import { useState, useEffect, useRef, useCallback } from 'react';
import { MapPin, Navigation, Crosshair, Search, Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import MapsAuthNotice from '@/components/traslado/MapsAuthNotice';

const PUNTA_CANA = { lat: 18.56, lng: -68.37 };

const QUICK_DESTINATIONS = [
  { name: 'Aeropuerto PUJ', lat: 18.5674, lng: -68.3634 },
  { name: 'Bávaro', lat: 18.665, lng: -68.408 },
  { name: 'Cap Cana', lat: 18.452, lng: -68.37 },
  { name: 'Uvero Alto', lat: 18.733, lng: -68.448 },
  { name: 'Higüey', lat: 18.615, lng: -68.717 },
  { name: 'Santo Domingo', lat: 18.4861, lng: -69.9312 },
];

let mapsLoaderPromise = null;

function loadGoogleMaps(apiKey) {
  if (window.google?.maps) return Promise.resolve(window.google.maps);
  if (mapsLoaderPromise) return mapsLoaderPromise;
  mapsLoaderPromise = new Promise((resolve, reject) => {
    const cb = '__gmaps_cb_' + Date.now();
    window[cb] = () => { resolve(window.google.maps); delete window[cb]; };
    const s = document.createElement('script');
    s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&v=weekly&callback=${cb}`;
    s.async = true;
    s.defer = true;
    s.onerror = () => { mapsLoaderPromise = null; reject(new Error('No se pudo cargar Google Maps')); };
    document.head.appendChild(s);
  });
  return mapsLoaderPromise;
}

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export default function TransferMapPicker({ onPickupChange, onDestinationChange, onDistanceChange }) {
  const [mode, setMode] = useState('origin');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchValue, setSearchValue] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [points, setPoints] = useState({ origin: null, dest: null });
  const [distance, setDistance] = useState(0);
  const [locating, setLocating] = useState(false);
  const [authIssue, setAuthIssue] = useState(null);

  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const markersRef = useRef({ origin: null, dest: null });
  const routeLineRef = useRef(null);
  const routeReqRef = useRef(0);
  const searchSeqRef = useRef(0);
  const geocoderRef = useRef(null);
  const placesLibRef = useRef(null);
  const routesLibRef = useRef(null);
  const sessionTokenRef = useRef(null);
  const searchInputRef = useRef(null);
  const debounceRef = useRef(null);
  const modeRef = useRef(mode);
  const pointsRef = useRef(points);

  useEffect(() => { modeRef.current = mode; }, [mode]);
  useEffect(() => { pointsRef.current = points; }, [points]);

  const clearRoute = useCallback(() => {
    routeReqRef.current += 1;
    if (routeLineRef.current) { routeLineRef.current.setMap(null); routeLineRef.current = null; }
  }, []);

  const calcRoute = useCallback(async (origin, dest) => {
    if (!routesLibRef.current) return;
    clearRoute();
    const reqId = routeReqRef.current;
    let km;
    let path = null;
    try {
      const { routes } = await routesLibRef.current.Route.computeRoutes({
        origin: { lat: origin.lat, lng: origin.lng },
        destination: { lat: dest.lat, lng: dest.lng },
        travelMode: 'DRIVING',
        fields: ['distanceMeters', 'path'],
      });
      km = Math.round(routes[0].distanceMeters / 1000);
      path = routes[0].path.map((p) => ({ lat: p.lat, lng: p.lng }));
    } catch {
      km = Math.round(haversineKm(origin.lat, origin.lng, dest.lat, dest.lng) * 1.3);
    }
    if (reqId !== routeReqRef.current) return;
    if (path) {
      routeLineRef.current = new window.google.maps.Polyline({
        path, map: mapRef.current, strokeColor: '#571AFF', strokeWeight: 5, strokeOpacity: 0.85,
      });
    }
    setDistance(km);
    onDistanceChange?.(km);
  }, [onDistanceChange, clearRoute]);

  const setPoint = useCallback((which, point) => {
    const maps = window.google.maps;
    const newPoints = { ...pointsRef.current, [which]: point };
    pointsRef.current = newPoints;
    setPoints(newPoints);

    if (markersRef.current[which]) markersRef.current[which].setMap(null);
    markersRef.current[which] = new maps.Marker({
      position: { lat: point.lat, lng: point.lng },
      map: mapRef.current,
      label: { text: which === 'origin' ? 'A' : 'B', color: '#FFFFFF', fontWeight: 'bold', fontSize: '12px' },
      animation: maps.Animation.DROP,
    });
    mapRef.current.panTo({ lat: point.lat, lng: point.lng });

    if (which === 'origin') onPickupChange?.(point);
    else onDestinationChange?.(point);

    if (newPoints.origin && newPoints.dest) {
      calcRoute(newPoints.origin, newPoints.dest);
    } else {
      clearRoute();
      setDistance(0);
      onDistanceChange?.(0);
    }
  }, [onPickupChange, onDestinationChange, onDistanceChange, calcRoute, clearRoute]);

  const reverseGeocode = useCallback((lat, lng, callback) => {
    if (!geocoderRef.current) { callback(`${lat.toFixed(4)}, ${lng.toFixed(4)}`); return; }
    geocoderRef.current.geocode({ location: { lat, lng } }, (results, status) => {
      const name = (status === 'OK' && results?.[0]) ? results[0].formatted_address : `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      callback(name);
    });
  }, []);

  useEffect(() => {
    let cancelled = false;
    const origConsoleError = console.error;
    console.error = (...args) => {
      const m = String(args[0] ?? '').match(/Google Maps JavaScript API error: (\w+)/);
      if (m) setAuthIssue(m[1]);
      origConsoleError.apply(console, args);
    };
    window.gm_authFailure = () => setAuthIssue((prev) => prev || 'AuthFailure');
    (async () => {
      try {
        const res = await base44.functions.invoke('getMapsConfig', {});
        const apiKey = res.data?.google_maps_api_key;
        if (!apiKey) { setError('Falta configurar la API key de Google Maps'); setLoading(false); return; }
        const maps = await loadGoogleMaps(apiKey);
        if (cancelled) return;

        mapRef.current = new maps.Map(mapContainerRef.current, {
          center: PUNTA_CANA, zoom: 11,
          mapTypeControl: false, streetViewControl: false, fullscreenControl: true, zoomControl: true,
        });
        geocoderRef.current = new maps.Geocoder();
        placesLibRef.current = await maps.importLibrary('places');
        routesLibRef.current = await maps.importLibrary('routes');
        if (cancelled) return;

        mapRef.current.addListener('click', (e) => {
          if (!e.latLng) return;
          const lat = e.latLng.lat(), lng = e.latLng.lng();
          const which = modeRef.current === 'origin' ? 'origin' : 'dest';
          reverseGeocode(lat, lng, (name) => {
            setPoint(which, { lat, lng, name });
            if (which === 'origin') setMode('destination');
          });
        });

        setLoading(false);
      } catch (err) {
        if (!cancelled) { setError(err.message || 'Error al cargar el mapa'); setLoading(false); }
      }
    })();
    return () => { cancelled = true; console.error = origConsoleError; };
  }, [setPoint, reverseGeocode]);

  const handleSearch = useCallback((value) => {
    setSearchValue(value);
    setSearchError(null);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!value || value.trim().length < 2) { searchSeqRef.current += 1; setSearchResults([]); setSearching(false); return; }
    if (!placesLibRef.current) return;
    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      const seq = ++searchSeqRef.current;
      const { AutocompleteSuggestion, AutocompleteSessionToken } = placesLibRef.current;
      if (!sessionTokenRef.current) sessionTokenRef.current = new AutocompleteSessionToken();
      try {
        const { suggestions } = await AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: value,
          includedRegionCodes: ['do'],
          sessionToken: sessionTokenRef.current,
        });
        if (seq !== searchSeqRef.current) return;
        setSearchResults(suggestions.map((s) => s.placePrediction).filter(Boolean));
      } catch (err) {
        if (seq !== searchSeqRef.current) return;
        setSearchResults([]);
        setSearchError('Google bloqueó la búsqueda. En Google Cloud habilita "Places API (New)" y agrégala a las restricciones de la clave. ' + (err?.message ? `(${err.message.slice(0, 120)})` : ''));
      }
      setSearching(false);
    }, 350);
  }, []);

  const selectResult = useCallback(async (prediction) => {
    setSearching(true);
    try {
      const place = prediction.toPlace();
      await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location'] });
      const lat = place.location.lat(), lng = place.location.lng();
      const name = place.displayName || place.formattedAddress || prediction.text?.text;
      const which = modeRef.current === 'origin' ? 'origin' : 'dest';
      setPoint(which, { lat, lng, name });
      if (which === 'origin') setMode('destination');
      setSearchValue('');
      setSearchResults([]);
      sessionTokenRef.current = null;
    } catch {
      setSearchError('No se pudo obtener la ubicación del lugar seleccionado.');
    }
    setSearching(false);
  }, [setPoint]);

  useEffect(() => () => { if (debounceRef.current) clearTimeout(debounceRef.current); }, []);

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      const which = modeRef.current === 'origin' ? 'origin' : 'dest';
      reverseGeocode(lat, lng, (name) => {
        setPoint(which, { lat, lng, name });
        if (which === 'origin') setMode('destination');
        setLocating(false);
      });
    }, () => setLocating(false));
  };

  const quickSelect = (dest) => {
    const which = modeRef.current === 'origin' ? 'origin' : 'dest';
    setPoint(which, { lat: dest.lat, lng: dest.lng, name: dest.name });
    if (which === 'origin') setMode('destination');
  };

  const clearPoint = (which) => {
    if (markersRef.current[which]) { markersRef.current[which].setMap(null); markersRef.current[which] = null; }
    const newPoints = { ...pointsRef.current, [which]: null };
    pointsRef.current = newPoints;
    setPoints(newPoints);
    clearRoute();
    setDistance(0);
    onDistanceChange?.(0);
    if (which === 'origin') onPickupChange?.(null);
    else onDestinationChange?.(null);
  };

  if (error) {
    return (
      <div className="rounded-2xl p-6 text-center" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC' }}>
        <MapPin size={28} color="#72706A" className="mx-auto mb-2" />
        <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Mode toggle */}
      <div className="flex gap-2">
        <button
          onClick={() => setMode('origin')}
          className="flex-1 rounded-xl py-2.5 font-poppins font-semibold flex items-center justify-center gap-2"
          style={{
            background: mode === 'origin' ? '#571AFF' : '#F0EFE9',
            color: mode === 'origin' ? '#FFF' : '#141413',
            border: '1.5px solid ' + (mode === 'origin' ? '#571AFF' : '#E8E6DC'),
            fontSize: '13px',
          }}
        >
          <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: mode === 'origin' ? 'rgba(255,255,255,0.25)' : '#FFFFFF', color: mode === 'origin' ? '#FFF' : '#571AFF', border: '1.5px solid ' + (mode === 'origin' ? '#FFF' : '#571AFF') }}>A</span>
          Origen
        </button>
        <button
          onClick={() => setMode('destination')}
          className="flex-1 rounded-xl py-2.5 font-poppins font-semibold flex items-center justify-center gap-2"
          style={{
            background: mode === 'destination' ? '#571AFF' : '#F0EFE9',
            color: mode === 'destination' ? '#FFF' : '#141413',
            border: '1.5px solid ' + (mode === 'destination' ? '#571AFF' : '#E8E6DC'),
            fontSize: '13px',
          }}
        >
          <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: mode === 'destination' ? 'rgba(255,255,255,0.25)' : '#FFFFFF', color: mode === 'destination' ? '#FFF' : '#571AFF', border: '1.5px solid ' + (mode === 'destination' ? '#FFF' : '#571AFF') }}>B</span>
          Destino
        </button>
      </div>

      {/* Map with search overlay */}
      <div className="relative rounded-2xl overflow-hidden" style={{ border: '1.5px solid #E8E6DC', height: '360px' }}>
        <div ref={mapContainerRef} className="w-full h-full" />
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center" style={{ background: '#F0EFE9' }}>
            <div className="text-center">
              <Loader2 size={24} className="animate-spin mx-auto mb-2" color="#571AFF" />
              <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Cargando mapa...</p>
            </div>
          </div>
        )}

        {/* Search bar overlay */}
        <div className="absolute left-3 right-3 top-3 z-10">
          <div className="relative">
            <Search size={16} color="#757575" className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchValue}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Buscar hotel, restaurante, lugar o dirección..."
              className="w-full rounded-xl pl-10 pr-10 py-2.5 font-inter"
              style={{ background: '#F0F0ED', border: '1.5px solid #FFFFFF', fontSize: '13px', color: '#212121', minHeight: '42px', boxShadow: '0 2px 8px rgba(14,14,14,0.18)' }}
            />
            {searching && (
              <Loader2 size={16} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin" color="#571AFF" />
            )}
            {searchValue && !searching && (
              <button onClick={() => { setSearchValue(''); setSearchResults([]); }} className="absolute right-3 top-1/2 -translate-y-1/2">
                <X size={16} color="#757575" />
              </button>
            )}

            {/* Custom dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1 rounded-xl overflow-hidden" style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC', boxShadow: '0 12px 32px rgba(14,14,14,0.18)', zIndex: 1000, maxHeight: '260px', overflowY: 'auto' }}>
                {searchResults.map((pred) => (
                  <button
                    key={pred.placeId}
                    onClick={() => selectResult(pred)}
                    className="w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-[#F0EFE9] transition-colors"
                    style={{ borderBottom: '1px solid #F0EFE9' }}
                  >
                    <MapPin size={16} color="#571AFF" className="mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <p className="font-inter font-semibold truncate" style={{ fontSize: '13px', color: '#141413' }}>{pred.mainText?.text || pred.text?.text}</p>
                      {pred.secondaryText?.text && (
                        <p className="font-inter truncate" style={{ fontSize: '11px', color: '#72706A' }}>{pred.secondaryText.text}</p>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
            {searchError && !searching && searchValue && (
              <div className="absolute left-0 right-0 top-full mt-1 rounded-xl px-4 py-3" style={{ background: '#FFF3F3', border: '1.5px solid #E8A0A0', zIndex: 1000 }}>
                <p className="font-inter" style={{ fontSize: '12px', color: '#8A2820' }}>{searchError}</p>
              </div>
            )}
          </div>
        </div>

        <button
          onClick={useMyLocation}
          disabled={loading || locating}
          className="absolute bottom-3 right-3 rounded-full px-3 py-2 flex items-center gap-1.5 font-inter font-semibold"
          style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC', fontSize: '12px', color: '#141413', boxShadow: '0 2px 8px rgba(14,14,14,0.15)' }}
        >
          {locating ? <Loader2 size={14} className="animate-spin" /> : <Crosshair size={14} color="#571AFF" />}
          {locating ? 'Ubicando...' : 'Mi ubicación'}
        </button>
      </div>

      {authIssue && <MapsAuthNotice code={authIssue} />}

      {/* Quick destinations */}
      <div className="flex flex-wrap gap-2">
        {QUICK_DESTINATIONS.map((d) => (
          <button
            key={d.name}
            onClick={() => quickSelect(d)}
            className="rounded-full px-3 py-1.5 font-inter font-semibold"
            style={{ background: '#F0EFE9', border: '1px solid #E8E6DC', fontSize: '12px', color: '#3A3A3A' }}
          >
            {d.name}
          </button>
        ))}
      </div>

      {/* Selected points + distance */}
      <div className="space-y-2">
        {points.origin && (
          <div className="rounded-xl p-3 flex items-center gap-3" style={{ background: '#F0EFE9', border: '1.5px solid #571AFF' }}>
            <span className="w-7 h-7 rounded-full flex items-center justify-center font-poppins font-bold text-xs shrink-0" style={{ background: '#571AFF', color: '#FFF' }}>A</span>
            <span className="font-inter flex-1 truncate" style={{ fontSize: '13px', color: '#141413' }}>{points.origin.name}</span>
            <button onClick={() => clearPoint('origin')} className="w-6 h-6 rounded-full flex items-center justify-center shrink-0" style={{ background: '#FFFFFF' }}><X size={14} color="#72706A" /></button>
          </div>
        )}
        {points.dest && (
          <div className="rounded-xl p-3 flex items-center gap-3" style={{ background: '#F0EFE9', border: '1.5px solid #571AFF' }}>
            <span className="w-7 h-7 rounded-full flex items-center justify-center font-poppins font-bold text-xs shrink-0" style={{ background: '#571AFF', color: '#FFF' }}>B</span>
            <span className="font-inter flex-1 truncate" style={{ fontSize: '13px', color: '#141413' }}>{points.dest.name}</span>
            <button onClick={() => clearPoint('dest')} className="w-6 h-6 rounded-full flex items-center justify-center shrink-0" style={{ background: '#FFFFFF' }}><X size={14} color="#72706A" /></button>
          </div>
        )}
        {distance > 0 && (
          <div className="rounded-xl p-3 flex items-center justify-between" style={{ background: '#571AFF' }}>
            <div className="flex items-center gap-2 text-white">
              <Navigation size={16} />
              <span className="font-poppins font-bold" style={{ fontSize: '18px' }}>{distance} KM</span>
            </div>
            <span className="font-inter text-white" style={{ fontSize: '12px', opacity: 0.9 }}>Distancia por carretera</span>
          </div>
        )}
      </div>
    </div>
  );
}