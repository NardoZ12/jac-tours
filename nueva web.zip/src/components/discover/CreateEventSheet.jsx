import { useState } from 'react';
import { X, Loader2 } from 'lucide-react';
import { contentEntityForCategory } from '@/lib/contentTables';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';

const CATEGORIES = [
  { key: 'eat', emoji: '🍽️', label: 'Eat' },
  { key: 'stay', emoji: '🏨', label: 'Stay' },
  { key: 'do', emoji: '🧭', label: 'Do' },
];

// Quick-pick neighborhoods around Tel Aviv with rough centroids
const NEIGHBORHOODS = [
  { name: 'Florentin',     lat: 32.0540, lng: 34.7716 },
  { name: 'Rothschild',    lat: 32.0640, lng: 34.7740 },
  { name: 'Carmel Market', lat: 32.0686, lng: 34.7697 },
  { name: 'Dizengoff',     lat: 32.0793, lng: 34.7745 },
  { name: 'Gordon Beach',  lat: 32.0844, lng: 34.7691 },
  { name: 'Hilton Beach',  lat: 32.0902, lng: 34.7691 },
  { name: 'Old Jaffa',     lat: 32.0530, lng: 34.7500 },
  { name: 'Sarona',        lat: 32.0723, lng: 34.7860 },
];

function nextHourIso(hoursFromNow = 2) {
  const d = new Date();
  d.setHours(d.getHours() + hoursFromNow, 0, 0, 0);
  return d.toISOString();
}

function formatDateTimeLocal(iso) {
  const d = new Date(iso);
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function CreateEventSheet({ user, onClose, onCreated }) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('do');
  const [neighborhood, setNeighborhood] = useState(NEIGHBORHOODS[1]);
  const [startTime, setStartTime] = useState(formatDateTimeLocal(nextHourIso(2)));
  const [maxAttendees, setMaxAttendees] = useState(8);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const cat = CATEGORIES.find(c => c.key === category);
  const canSubmit = title.trim().length >= 3 && !submitting;

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      const table = contentEntityForCategory(category);
      const created = await table.create({
        name: title.trim(),
        category,
        emoji: cat.emoji,
        host_user_id: user?.id,
        host_name: user?.full_name || 'You',
        start_time: new Date(startTime).toISOString(),
        duration_min: 60,
        location_name: neighborhood.name,
        neighborhood: neighborhood.name,
        city: 'Tel Aviv',
        lat: neighborhood.lat,
        lng: neighborhood.lng,
        max_attendees: Number(maxAttendees) || 8,
        attendee_ids: user?.id ? [user.id] : [],
        attendee_names: user?.full_name ? [user.full_name] : [],
        price: 0,
        currency: 'EUR',
        status: 'upcoming',
      });
      onCreated?.({ ...created, category });
    } catch (e) {
      setError(e?.message || 'Could not create event');
      setSubmitting(false);
    }
  };

  return (
    <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3">
          <div>
            <p className="font-poppins font-bold" style={{ fontSize: '20px', color: '#141413', letterSpacing: '-0.5px' }}>
              Host a hangout
            </p>
            <p className="font-inter mt-0.5" style={{ fontSize: '12px', color: '#72706A' }}>
              Open it to anyone nearby — meet new people.
            </p>
          </div>
          <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>
            <X size={16} color="#141413" />
          </button>
        </div>

        <div className="px-5 pb-5 overflow-y-auto flex-1 space-y-5">
          {/* Title */}
          <div>
            <label className="font-poppins font-semibold block mb-2" style={{ fontSize: '12px', color: '#141413' }}>
              What are you doing?
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Sunset run, hummus crawl, rooftop drinks…"
              maxLength={60}
              className="w-full font-inter"
              style={{
                height: '48px', padding: '0 14px', borderRadius: '12px',
                border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413',
                background: '#FAF9F5', outline: 'none',
              }}
            />
          </div>

          {/* Category */}
          <div>
            <label className="font-poppins font-semibold block mb-2" style={{ fontSize: '12px', color: '#141413' }}>
              Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {CATEGORIES.map(c => {
                const active = c.key === category;
                return (
                  <button
                    key={c.key}
                    onClick={() => setCategory(c.key)}
                    className="flex items-center gap-1.5 justify-center font-poppins font-semibold"
                    style={{
                      height: '40px', borderRadius: '10px', fontSize: '12px',
                      background: active ? '#141413' : '#FFFFFF',
                      color: active ? '#FFFFFF' : '#72706A',
                      border: '1.5px solid ' + (active ? '#141413' : '#E8E6DC'),
                    }}
                  >
                    <span>{c.emoji}</span> {c.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Neighborhood */}
          <div>
            <label className="font-poppins font-semibold block mb-2" style={{ fontSize: '12px', color: '#141413' }}>
              Where in Tel Aviv?
            </label>
            <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
              {NEIGHBORHOODS.map(n => {
                const active = n.name === neighborhood.name;
                return (
                  <button
                    key={n.name}
                    onClick={() => setNeighborhood(n)}
                    className="flex-shrink-0 font-poppins font-semibold"
                    style={{
                      height: '36px', padding: '0 14px', borderRadius: '99px', fontSize: '12px',
                      background: active ? '#141413' : '#FFFFFF',
                      color: active ? '#FFFFFF' : '#72706A',
                      border: '1.5px solid ' + (active ? '#141413' : '#E8E6DC'),
                    }}
                  >
                    {n.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time + Capacity */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-poppins font-semibold block mb-2" style={{ fontSize: '12px', color: '#141413' }}>
                When
              </label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full font-inter"
                style={{
                  height: '44px', padding: '0 12px', borderRadius: '12px',
                  border: '1.5px solid #E8E6DC', fontSize: '13px', color: '#141413',
                  background: '#FAF9F5', outline: 'none',
                }}
              />
            </div>
            <div>
              <label className="font-poppins font-semibold block mb-2" style={{ fontSize: '12px', color: '#141413' }}>
                Max people
              </label>
              <input
                type="number"
                min={2}
                max={50}
                value={maxAttendees}
                onChange={(e) => setMaxAttendees(e.target.value)}
                className="w-full font-inter"
                style={{
                  height: '44px', padding: '0 12px', borderRadius: '12px',
                  border: '1.5px solid #E8E6DC', fontSize: '13px', color: '#141413',
                  background: '#FAF9F5', outline: 'none',
                }}
              />
            </div>
          </div>

          {error && (
            <p className="font-inter" style={{ fontSize: '12px', color: '#DC2626' }}>{error}</p>
          )}
        </div>

        {/* Submit */}
        <div className="px-5 pb-6 pt-2" style={{ borderTop: '1px solid #F0EFE9' }}>
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className="w-full flex items-center justify-center gap-2 font-poppins font-semibold text-white"
            style={{
              height: '52px', borderRadius: '14px',
              background: canSubmit ? 'linear-gradient(135deg, #16A34A 0%, #15803D 100%)' : '#B0AEA5',
              fontSize: '15px',
            }}
          >
            {submitting ? <><Loader2 size={16} className="animate-spin" /> Creating…</> : 'Post hangout 🟢'}
          </button>
          <p className="font-inter text-center mt-2" style={{ fontSize: '12px', color: '#72706A' }}>
            You'll be the host · friends nearby will see it instantly
          </p>
        </div>
    </ResponsiveSheetShell>
  );
}