import { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import MapInfoCard from './MapInfoCard';

const DEFAULT_CENTER = [48.3705, 10.8978]; // Augsburg
// Augsburg bounding box — used to keep the initial map framed on Augsburg activities only.
const AUGSBURG_BOUNDS = [
  [48.3480, 10.8700],
  [48.3910, 10.9250],
];

// Category → { color, emoji } for activity pins.
const CATEGORY_STYLE = {
  run:      { color: '#F5B945', emoji: '🏃' },
  food:     { color: '#FF7849', emoji: '🍽️' },
  drinks:   { color: '#EC4899', emoji: '🍸' },
  beach:    { color: '#7AB8DD', emoji: '🏖️' },
  culture:  { color: '#A855F7', emoji: '🎨' },
  sports:   { color: '#16A34A', emoji: '⚽' },
  music:    { color: '#F43F5E', emoji: '🎵' },
  walk:     { color: '#A3CD7B', emoji: '🚶' },
  workshop: { color: '#F59E0B', emoji: '🛠️' },
  default:  { color: '#FF7849', emoji: '✨' },
};

const meIcon = L.divIcon({
  html: `<div style="
    width:16px;height:16px;border-radius:50%;
    background:#0E0E0E;border:2px solid #fff;box-shadow:0 0 0 6px rgba(14,14,14,0.12);
  "></div>`,
  className: '',
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function minimalPointIcon(selected = false, label = '') {
  const size = selected ? 18 : 12;
  const safeLabel = escapeHtml(label);
  const html = `<div class="activity-map-pin" style="position:relative;width:${size}px;height:${size}px;">
    <div style="
      width:${size}px;height:${size}px;border-radius:50%;
      background:#0E0E0E;border:2px solid #FFFFFF;
      box-shadow:0 4px 10px rgba(14,14,14,0.16);
      transition:all 180ms cubic-bezier(0.22, 1, 0.36, 1);
    "></div>
    ${safeLabel ? `<div class="activity-map-pin-label">${safeLabel}</div>` : ''}
  </div>`;
  return L.divIcon({ html, className: '', iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
}

function eventIcon(activity, selected) {
  return minimalPointIcon(selected, activity.title || activity.name || activity.location_name || 'Event');
}

function placeIcon(place, selected) {
  return minimalPointIcon(selected, place.name || place.location_name || 'Place');
}

function personIcon(person, selected) {
  return minimalPointIcon(selected, person.full_name || person.name || 'Person');
}

/** Auto-fit map to include all visible pins so users don't need to pan/zoom. */
function FitToPins({ points }) {
  const map = useMap();
  useEffect(() => {
    const augsburgBounds = L.latLngBounds(AUGSBURG_BOUNDS);
    const inAugsburg = (points || []).filter(([lat, lng]) => augsburgBounds.contains([lat, lng]));
    if (inAugsburg.length === 0) {
      map.fitBounds(augsburgBounds, { padding: [20, 20] });
      return;
    }
    const bounds = L.latLngBounds(inAugsburg);
    map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
  }, [JSON.stringify(points), map]);
  return null;
}

/** When selection changes, gently pan the map to center the selected pin. */
function PanToSelection({ selection }) {
  const map = useMap();
  useEffect(() => {
    if (!selection?.item) return;
    const { lat, lng } = selection.item;
    if (lat == null || lng == null) return;
    map.panTo([lat, lng], { animate: true, duration: 0.4 });
  }, [selection, map]);
  return null;
}

export default function DiscoverMap({
  events = [],
  places = [],
  people = [],
  showEvents = true,
  showPlaces = true,
  showPeople = true,
  onSelectEvent,
  onSelectPlace,
  onSelectPerson,
}) {
  const [myLocation, setMyLocation] = useState(null);
  const [locError, setLocError] = useState(null);
  const [selection, setSelection] = useState(null); // { type: 'event'|'place'|'person', item }

  useEffect(() => {
    if (!navigator.geolocation) { setLocError('GPS not available'); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => setMyLocation([pos.coords.latitude, pos.coords.longitude]),
      () => setLocError('Location permission denied'),
      { enableHighAccuracy: false, timeout: 8000 }
    );
  }, []);

  const center = useMemo(() => myLocation || DEFAULT_CENTER, [myLocation]);

  const allPoints = useMemo(() => {
    const pts = [];
    if (showEvents) events.forEach(a => a.lat && a.lng && pts.push([a.lat, a.lng]));
    if (showPlaces) {
      places.forEach(a => a.lat && a.lng && pts.push([a.lat, a.lng]));
    }
    if (showPeople) people.forEach(p => p.lat && p.lng && pts.push([p.lat, p.lng]));
    return pts;
  }, [events, places, people, showEvents, showPlaces, showPeople]);

  const isSelected = (type, id) => selection?.type === type && selection?.item?.id === id;

  const handlePrimary = (item) => {
    if (!selection) return;
    if (selection.type === 'event') onSelectEvent?.(item);
    else if (selection.type === 'place') onSelectPlace?.(item);
    else if (selection.type === 'person') onSelectPerson?.(item);
    setSelection(null);
  };

  return (
    <div className="activity-map-canvas relative" style={{ height: '620px' }}>
      <style>{`
        .leaflet-control-zoom {
          border: 0 !important;
          box-shadow: none !important;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .leaflet-control-zoom a {
          width: 34px !important;
          height: 34px !important;
          line-height: 32px !important;
          border-radius: 999px !important;
          border: 1px solid rgba(14,14,14,0.10) !important;
          background: #FFFFFF !important;
          color: #0E0E0E !important;
          font-family: Inter, sans-serif !important;
          box-shadow: 0 4px 12px rgba(14,14,14,0.10) !important;
        }
        .activity-map-pin {
          cursor: pointer;
        }
        .activity-map-pin:hover > div:first-child {
          transform: scale(1.32);
          box-shadow: 0 8px 18px rgba(14,14,14,0.24);
        }
        .activity-map-pin-label {
          position: absolute;
          left: 50%;
          bottom: calc(100% + 9px);
          transform: translate(-50%, 4px) scale(0.96);
          opacity: 0;
          pointer-events: none;
          white-space: nowrap;
          border-radius: 999px;
          background: #FFFFFF;
          color: #0E0E0E;
          padding: 7px 11px;
          font-family: Inter, sans-serif;
          font-size: 12px;
          font-weight: 700;
          box-shadow: 0 10px 26px rgba(14,14,14,0.16);
          transition: opacity 160ms ease, transform 160ms ease;
        }
        .activity-map-pin-label::after {
          content: '';
          position: absolute;
          left: 50%;
          top: 100%;
          transform: translateX(-50%);
          border: 5px solid transparent;
          border-top-color: #FFFFFF;
        }
        .activity-map-pin:hover .activity-map-pin-label {
          opacity: 1;
          transform: translate(-50%, 0) scale(1);
        }
      `}</style>
      <MapContainer center={center} zoom={13} scrollWheelZoom={false} style={{ height: '100%', width: '100%', fontFamily: 'Inter, sans-serif', filter: 'grayscale(1)' }}>
        <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" maxZoom={19} />
        <FitToPins points={allPoints} />
        <PanToSelection selection={selection} />

        {/* Me */}
        {myLocation && (
          <>
            <Marker position={myLocation} icon={meIcon} />
            <Circle center={myLocation} radius={300} pathOptions={{ color: '#0E0E0E', fillColor: '#0E0E0E', fillOpacity: 0.05, weight: 1 }} />
          </>
        )}

        {/* Events */}
        {showEvents && events.filter(a => a.lat && a.lng).map(a => (
          <Marker
            key={`e-${a.id}`}
            position={[a.lat, a.lng]}
            icon={eventIcon(a, isSelected('event', a.id))}
            eventHandlers={{ click: () => setSelection({ type: 'event', item: a }) }}
          />
        ))}

        {/* Places */}
        {showPlaces && places.filter(a => a.lat && a.lng).map(a => (
          <Marker
            key={`p-place-${a.id}`}
            position={[a.lat, a.lng]}
            icon={placeIcon(a, isSelected('place', a.id))}
            eventHandlers={{ click: () => onSelectPlace ? onSelectPlace(a) : setSelection({ type: 'place', item: a }) }}
          />
        ))}

        {/* People (fuzzy circle + pin) */}
        {showPeople && people.filter(p => p.lat && p.lng).map(p => (
          <div key={`p-${p.id}`}>
            <Circle
              center={[p.lat, p.lng]}
              radius={250}
              pathOptions={{
                color: '#0E0E0E',
                fillColor: '#0E0E0E',
                fillOpacity: 0.06, weight: 1,
              }}
            />
            <Marker
              position={[p.lat, p.lng]}
              icon={personIcon(p, isSelected('person', p.id))}
              eventHandlers={{ click: () => setSelection({ type: 'person', item: p }) }}
            />
          </div>
        ))}
      </MapContainer>

      {/* Status pill */}
      <div className="absolute top-3 right-3 z-[400] flex items-center gap-2 px-3 py-1.5 rounded-full bg-white card-shadow">
        <span className="pulse-dot" style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#0E0E0E', display: 'inline-block' }} />
        <span className="font-inter font-semibold" style={{ fontSize: '12px', color: '#141413' }}>
          {showEvents ? events.length : 0} events · {showPlaces ? places.length : 0} places
        </span>
      </div>

      {locError && !selection && (
        <div className="absolute bottom-3 left-3 right-3 z-[400] px-3 py-2 rounded-2xl bg-white card-shadow">
          <p className="font-inter" style={{ fontSize: '12px', color: '#6B6962' }}>
            📍 {locError} · showing approximate area
          </p>
        </div>
      )}

      {/* Floating info card */}
      <MapInfoCard
        selection={selection}
        onClose={() => setSelection(null)}
        onPrimary={handlePrimary}
      />
    </div>
  );
}