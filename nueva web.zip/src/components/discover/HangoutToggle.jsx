import { useRadar } from '@/lib/RadarContext';
import { Users, Plus } from 'lucide-react';

/**
 * Big toggle to broadcast "I'm open to hang out" — appears at the top
 * of the Discover page so users can opt-in to be discoverable by others.
 * When ON, also exposes a "Host a hangout" CTA that opens the create-event sheet.
 */
export default function HangoutToggle({ onHostHangout }) {
  const { state, setState } = useRadar();
  const on = state.looking_to_hangout;

  const toggle = () => {
    const next = !on;
    setState({ looking_to_hangout: next, enabled: next || state.enabled });
    // When user turns it ON, immediately prompt them to host an event.
    if (next) onHostHangout?.();
  };

  return (
    <>
    <button
      onClick={toggle}
      className="w-full rounded-2xl p-4 flex items-center gap-3 transition-all card-shadow"
      style={{
        background: on ? 'linear-gradient(135deg, #16A34A 0%, #15803D 100%)' : '#FFFFFF',
        border: on ? 'none' : '1.5px solid #E8E6DC',
      }}
    >
      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: on ? 'rgba(255,255,255,0.2)' : '#F0FDF4' }}
      >
        <Users size={20} color={on ? '#FFFFFF' : '#16A34A'} />
      </div>
      <div className="flex-1 text-left">
        <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: on ? '#FFFFFF' : '#141413' }}>
          {on ? "You're open to hang out" : 'Looking to hang out?'}
        </p>
        <p className="font-inter mt-0.5" style={{ fontSize: '12px', color: on ? 'rgba(255,255,255,0.85)' : '#72706A' }}>
          {on ? 'Friends nearby can see you · tap to stop' : 'Let nearby friends know you’re free'}
        </p>
      </div>
      <div
        className="w-11 h-6 rounded-full p-0.5 flex items-center flex-shrink-0"
        style={{ background: on ? 'rgba(255,255,255,0.3)' : '#E8E6DC' }}
      >
        <div
          className="w-5 h-5 rounded-full bg-white transition-transform"
          style={{ transform: on ? 'translateX(20px)' : 'translateX(0)' }}
        />
      </div>
    </button>

    {on && (
      <button
        onClick={(e) => { e.stopPropagation(); onHostHangout?.(); }}
        className="w-full mt-2 flex items-center justify-center gap-2 font-poppins font-semibold"
        style={{
          height: '44px', borderRadius: '12px',
          background: '#FFFFFF', color: '#141413',
          border: '1.5px solid #E8E6DC', fontSize: '13px',
        }}
      >
        <Plus size={16} /> Host a hangout
      </button>
    )}
    </>
  );
}