import { useEffect, useState } from 'react';
import { Sparkles, X, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const EXAMPLES = [
'Romantic hotels with a pool',
'Cheap sushi spots',
'Rooftop bars with a view',
'Family-friendly experiences',
'Cozy cafes for working'];


const SEARCH_SCHEMA = {
  type: 'object',
  properties: {
    category: {
      type: 'string',
      enum: ['restaurant', 'hotel', 'experience', 'event', 'any'],
      description: 'Primary category the user is searching for'
    },
    price_range: {
      type: 'array',
      items: { type: 'integer', enum: [1, 2, 3, 4] },
      description: '1=cheap (€), 2=moderate, 3=upscale, 4=luxury. Empty = any.'
    },
    cuisine_tags: {
      type: 'array',
      items: { type: 'string' },
      description: 'e.g. sushi, italian, vegan, mediterranean'
    },
    vibe_tags: {
      type: 'array',
      items: { type: 'string' },
      description: 'e.g. romantic, rooftop, family-friendly, quiet, lively, cozy, view, pool'
    },
    neighborhood: {
      type: 'string',
      description: 'Specific neighborhood mentioned, or empty string'
    },
    summary: {
      type: 'string',
      description: 'Short, friendly one-line summary of what was matched'
    }
  },
  required: ['category', 'summary']
};

/**
 * AI-powered natural-language search input. Calls InvokeLLM to translate the
 * user's free text into a structured filter object that the parent page uses
 * to narrow results across events, places & people.
 */
export default function AISearchBar({ activeQuery, activeFilters, onApply, onClear, onExpandedChange }) {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showExamples, setShowExamples] = useState(false);

  const runSearch = async (q) => {
    const query = (q ?? text).trim();
    if (!query) return;
    onExpandedChange?.(true);
    setLoading(true);
    setError(null);
    try {
      const filters = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a travel search assistant for an app in Augsburg that lists restaurants, hotels, experiences, and group events.
Parse the user's natural-language query into structured search filters. Be liberal with vibe_tags — extract every adjective the user implies (e.g. "romantic" → ["romantic"], "with a pool" → ["pool"], "cheap" → price_range [1]).
If the query mentions a price level (cheap, budget, mid-range, upscale, luxury), set price_range accordingly.
Map words: cheap/budget → [1], mid/moderate → [2], nice/upscale → [3], luxury/fine → [4]. "Affordable" → [1,2].
Cuisine words like sushi, pizza, italian, vegan → cuisine_tags.
If they say "hotels" → category=hotel; "restaurants/eat/food" → restaurant; "things to do/activities/experiences" → experience; "events/meetup" → event; otherwise "any".
The summary should be a friendly 5-8 word recap.

Query: "${query}"`,
        response_json_schema: SEARCH_SCHEMA
      });
      onApply({ query, filters });
    } catch (e) {
      setError('Could not parse search. Try simpler wording.');
    }
    setLoading(false);
  };

  const handleClear = () => {
    setText('');
    setError(null);
    onExpandedChange?.(false);
    onClear();
  };

  const handleFocus = () => {
    onExpandedChange?.(true);
    setShowExamples(true);
  };

  const handleBlur = () => {
    setTimeout(() => {
      setShowExamples(false);
      if (!text && !loading && !hasActive) onExpandedChange?.(false);
    }, 150);
  };

  const handleTextChange = (e) => {
    const nextText = e.target.value;
    setText(nextText);
    onExpandedChange?.(!!nextText || showExamples || loading || hasActive);
  };

  const hasActive = !!activeQuery;
  const isExpanded = showExamples || !!text || loading || hasActive;

  useEffect(() => {
    onExpandedChange?.(isExpanded);
  }, [isExpanded, onExpandedChange]);

  return (
    <div className="m-0">
      <div
        className="flex h-12 items-center gap-2 rounded-full border border-black/5 bg-[#F8F7F4]/55 px-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:border-[#571AFF]/30 hover:bg-[#F8F7F4] hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.85)]">
        
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
          style={{ background: '#571AFF' }}>
          
          <Sparkles size={15} color="#FFF" />
        </div>
        <input
          type="text"
          value={text}
          onChange={handleTextChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onKeyDown={(e) => {if (e.key === 'Enter') runSearch();}}
          placeholder="Try: romantic hotels with a pool"
          className="flex-1 bg-transparent outline-none font-inter"
          style={{ fontSize: '14px', color: '#222' }} />
        
        {loading ?
        <Loader2 size={18} className="animate-spin flex-shrink-0" color="#571AFF" /> :
        hasActive ?
        <button
          onClick={handleClear}
          aria-label="Clear search"
          className="w-7 h-7 flex items-center justify-center rounded-full flex-shrink-0"
          style={{ background: '#F0F0F0' }}>
          
            <X size={14} color="#222" />
          </button> :
        text ?
        <button
          onClick={() => runSearch()}
          className="font-semibold flex-shrink-0 [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif] text-xs"
          style={{ fontSize: '12px', height: '32px', padding: '0 14px', borderRadius: '99px', background: '#571AFF', color: '#FFF' }}>
          
            Search
          </button> :
        null}
      </div>

      {/* Active filter pill summary */}
      {hasActive && activeFilters?.summary &&
      <div className="mt-2 flex items-center gap-2 flex-wrap">
          <span
          className="font-poppins font-semibold inline-flex items-center gap-1.5"
          style={{ fontSize: '12px', color: '#571AFF', background: '#F0EAFF', padding: '5px 10px', borderRadius: '12px', border: '1px solid #D8CAFF' }}>
          
            <Sparkles size={11} /> {activeFilters.summary}
          </span>
        </div>
      }

      {/* Example chips when focused & nothing typed */}
      {showExamples && !text && !hasActive &&
      <div className="mt-2 flex flex-wrap gap-2">
          {EXAMPLES.map((ex) =>
        <button
          key={ex}
          onMouseDown={(e) => {e.preventDefault();setText(ex);runSearch(ex);}}
          className="font-inter"
          style={{ fontSize: '12px', padding: '6px 12px', borderRadius: '99px', background: '#F7F7F7', color: '#222', border: '1px solid #EBEBEB' }}>
          
              {ex}
            </button>
        )}
        </div>
      }

      {error &&
      <p className="font-inter mt-2" style={{ fontSize: '12px', color: '#C13515' }}>{error}</p>
      }
    </div>);

}