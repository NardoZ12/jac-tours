import { Clock, MapPin } from 'lucide-react';
import JoinActivityButton from './JoinActivityButton';

const CATEGORY_COLORS = {
  eat: '#D97757',
  stay: '#2A6DB5',
  do: '#7C3AED',
};

const CATEGORY_LABELS = {
  eat: 'Eat',
  stay: 'Stay',
  do: 'Do',
};

function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  const tomorrow = new Date(now); tomorrow.setDate(tomorrow.getDate() + 1);
  const isTomorrow = d.toDateString() === tomorrow.toDateString();
  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  if (isToday) return `Today · ${time}`;
  if (isTomorrow) return `Tomorrow · ${time}`;
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) + ` · ${time}`;
}

export default function ActivityCard({ activity, currentUser, onChange }) {
  const type = activity.category || 'do';
  const color = CATEGORY_COLORS[type] || '#7C3AED';
  const count = (activity.attendee_ids || []).length;
  const max = activity.max_attendees || 8;
  const names = activity.attendee_names || [];

  return (
    <div className="flex-shrink-0 rounded-2xl bg-white card-shadow overflow-hidden flex flex-col" style={{ width: '260px' }}>
      {/* Header bar with emoji + category color */}
      <div className="flex items-center gap-2 px-3 py-2.5" style={{ background: `${color}15` }}>
        <span style={{ fontSize: '20px' }}>{activity.emoji || '✨'}</span>
        <span className="font-poppins font-semibold uppercase tracking-wider" style={{ fontSize: '12px', color, letterSpacing: '0.08em' }}>
          {CATEGORY_LABELS[type] || type}
        </span>
        {activity.price > 0 ? (
          <span className="ml-auto font-neue" style={{ fontSize: '13px', color: '#72706A' }}>
            €{activity.price}
          </span>
        ) : (
          <span className="ml-auto font-poppins font-semibold" style={{ fontSize: '12px', color: '#16A34A', background: '#F0FDF4', padding: '2px 8px', borderRadius: '99px' }}>
            FREE
          </span>
        )}
      </div>

      <div className="p-3 flex-1 flex flex-col">
        <p className="font-poppins font-bold mb-1" style={{ fontSize: '14px', color: '#141413', lineHeight: 1.3 }}>
          {activity.name || activity.title}
        </p>

        <div className="flex items-center gap-1 mt-1">
          <Clock size={11} color="#72706A" />
          <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
            {formatTime(activity.start_time)} · {activity.duration_min || 60}min
          </p>
        </div>
        <div className="flex items-center gap-1 mt-1">
          <MapPin size={11} color="#72706A" />
          <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>
            {activity.location_name || activity.neighborhood}
          </p>
        </div>

        {/* Attendees */}
        <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: '1px solid #F0EFE9' }}>
          <div className="flex items-center gap-1">
            <div className="flex -space-x-1.5">
              {names.slice(0, 3).map((n, i) => (
                <div
                  key={i}
                  className="w-6 h-6 rounded-full flex items-center justify-center font-poppins font-bold text-white"
                  style={{ background: color, fontSize: '12px', border: '2px solid #FFF' }}
                >
                  {n[0]}
                </div>
              ))}
              {names.length === 0 && (
                <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: '#F0EFE9', fontSize: '12px' }}>+</div>
              )}
            </div>
            <span className="font-inter ml-1" style={{ fontSize: '12px', color: '#72706A' }}>
              {count}/{max} going
            </span>
          </div>
          <JoinActivityButton activity={activity} currentUser={currentUser} onChange={onChange} size="sm" />
        </div>
      </div>
    </div>
  );
}