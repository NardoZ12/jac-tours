import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { contentEntityForCategory } from '@/lib/contentTables';
import { Check } from 'lucide-react';
import ConfettiEffect from '@/components/ui/ConfettiEffect';

/**
 * One-tap join/leave button for an Activity.
 * - currentUser: result of base44.auth.me() (or null)
 * - activity: Activity entity
 * - onChange(updated): notifies parent so it can update local state
 */
export default function JoinActivityButton({ activity, currentUser, onChange, size = 'md' }) {
  const [busy, setBusy] = useState(false);
  const [confetti, setConfetti] = useState(false);

  const userId = currentUser?.id;
  const userName = currentUser?.full_name || 'You';
  const joined = !!userId && (activity.attendee_ids || []).includes(userId);
  const count = (activity.attendee_ids || []).length;
  const full = count >= (activity.max_attendees || 8) && !joined;

  const handleClick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    if (!userId) {
      // Not signed in — send to login so they can join.
      base44.auth.redirectToLogin?.();
      return;
    }
    setBusy(true);

    const ids = activity.attendee_ids || [];
    const names = activity.attendee_names || [];
    let nextIds, nextNames;

    if (joined) {
      const idx = ids.indexOf(userId);
      nextIds = ids.filter(x => x !== userId);
      nextNames = names.filter((_, i) => i !== idx);
    } else {
      if (full) { setBusy(false); return; }
      nextIds = [...ids, userId];
      nextNames = [...names, userName];
    }

    const newStatus = nextIds.length >= (activity.max_attendees || 8) ? 'full' : 'upcoming';

    try {
      const updated = await contentEntityForCategory(activity.category).update(activity.id, {
        attendee_ids: nextIds,
        attendee_names: nextNames,
        status: newStatus,
      });
      onChange?.({ ...activity, ...updated, attendee_ids: nextIds, attendee_names: nextNames, status: newStatus });
      if (!joined) {
        setConfetti(true);
        setTimeout(() => setConfetti(false), 1600);
      }
    } catch {}
    setBusy(false);
  };

  const sizes = {
    sm: { h: '30px', px: '12px', fs: '11px' },
    md: { h: '36px', px: '16px', fs: '12px' },
  };
  const s = sizes[size] || sizes.md;

  let bg, fg, label;
  if (!userId) { bg = '#E8E6DC'; fg = '#72706A'; label = 'Sign in to join'; }
  else if (joined) { bg = '#16A34A'; fg = '#FFFFFF'; label = 'Going'; }
  else if (full) { bg = '#E8E6DC'; fg = '#72706A'; label = 'Full'; }
  else { bg = '#141413'; fg = '#FFFFFF'; label = 'Join'; }

  return (
    <>
      <ConfettiEffect active={confetti} />
      <button
        onClick={handleClick}
        disabled={busy || full}
        className="font-poppins font-semibold inline-flex items-center justify-center gap-1 flex-shrink-0"
        style={{
          height: s.h, padding: `0 ${s.px}`, borderRadius: '99px',
          background: bg, color: fg, fontSize: s.fs,
          opacity: busy ? 0.6 : 1,
        }}
      >
        {joined && <Check size={12} />}
        {busy ? '…' : label}
      </button>
    </>
  );
}