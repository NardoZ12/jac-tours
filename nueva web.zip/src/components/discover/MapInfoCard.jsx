import { X, MapPin, Users, Clock, Star } from 'lucide-react';
import PrimaryButton from '../ui/PrimaryButton';

/**
 * Clean floating info card displayed at the bottom of the map when a pin is selected.
 * Renders different content per type: 'event' | 'place' | 'person'.
 */
export default function MapInfoCard({ selection, onClose, onPrimary }) {
  if (!selection) return null;
  const { type, item } = selection;

  const toneByType = { event: 'coral', place: 'green', person: 'dark' };
  const accentByType = { event: '#FF7849', place: '#A3CD7B', person: '#2A2342' };
  const tone = toneByType[type] || 'dark';
  const accent = accentByType[type] || '#2A2342';

  let title, subtitle, meta, primaryLabel, leadingVisual;

  if (type === 'event') {
    const going = (item.attendee_ids || []).length;
    const cap = item.max_attendees || 8;
    const time = item.start_time
      ? new Date(item.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : null;
    title = item.title;
    subtitle = item.location_name || item.neighborhood;
    meta = (
      <div className="flex items-center gap-3 mt-1.5">
        {time && (
          <span className="flex items-center gap-1 font-inter" style={{ fontSize: '12px', color: '#6B6962' }}>
            <Clock size={11} /> {time}
          </span>
        )}
        <span className="flex items-center gap-1 font-poppins font-semibold" style={{ fontSize: '12px', color: accent }}>
          <Users size={11} /> {going}/{cap} going
        </span>
      </div>
    );
    primaryLabel = 'View details';
    leadingVisual = (
      <div
        className="flex-shrink-0 flex items-center justify-center rounded-2xl"
        style={{ width: '52px', height: '52px', background: '#FFE5DC', fontSize: '24px' }}
      >
        {item.emoji || '✨'}
      </div>
    );
  } else if (type === 'place') {
    title = item.name;
    subtitle = `${item.sub_category || 'Experience'}${item.neighborhood ? ` · ${item.neighborhood}` : ''}`;
    meta = item.avg_rating ? (
      <div className="flex items-center gap-1 mt-1.5 font-poppins font-semibold" style={{ fontSize: '12px', color: '#141413' }}>
        <Star size={11} style={{ fill: '#F5B945', color: '#F5B945' }} />
        {item.avg_rating.toFixed(1)}
        {item.review_count ? <span className="font-inter font-normal" style={{ color: '#6B6962' }}>· {item.review_count} reviews</span> : null}
      </div>
    ) : (
      <div className="flex items-center gap-1 mt-1.5 font-inter" style={{ fontSize: '12px', color: '#6B6962' }}>
        <MapPin size={11} /> {item.city || 'Augsburg'}
      </div>
    );
    primaryLabel = 'View';
    leadingVisual = item.cover_image_url ? (
      <img
        src={item.cover_image_url}
        alt=""
        className="flex-shrink-0 object-cover"
        style={{ width: '52px', height: '52px', borderRadius: '14px' }}
      />
    ) : (
      <div
        className="flex-shrink-0 flex items-center justify-center rounded-2xl"
        style={{ width: '52px', height: '52px', background: '#E8F2DD', fontSize: '24px' }}
      >
        🎭
      </div>
    );
  } else {
    // person
    title = item.name;
    subtitle = `${item.neighborhood || ''}${item.distance_km != null ? ` · ${item.distance_km}km away` : ''}`;
    meta = item.looking_to_hangout ? (
      <div className="flex items-center gap-1 mt-1.5 font-poppins font-semibold" style={{ fontSize: '12px', color: '#16A34A' }}>
        <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: '#16A34A' }} />
        Open to hang out
      </div>
    ) : null;
    primaryLabel = 'Hangout';
    leadingVisual = (
      <div className="relative flex-shrink-0">
        <div
          className="flex items-center justify-center font-poppins font-bold text-white"
          style={{ width: '52px', height: '52px', borderRadius: '50%', background: item.color || '#D97757', fontSize: '17px' }}
        >
          {item.initials || item.name?.[0]}
        </div>
        {item.looking_to_hangout && (
          <span
            className="absolute -top-0.5 -right-0.5 rounded-full"
            style={{ width: '14px', height: '14px', background: '#16A34A', border: '2px solid #fff' }}
          />
        )}
      </div>
    );
  }

  return (
    <div
      className="absolute left-3 right-3 bottom-3 z-[30000] rounded-3xl bg-white card-shadow-elevated animate-fade-in-up"
      style={{ padding: '14px' }}
    >
      <div className="flex items-start gap-3">
        {leadingVisual}
        <div className="flex-1 min-w-0 pt-0.5">
          <p className="font-poppins font-bold truncate" style={{ fontSize: '15px', color: '#141413' }}>
            {title}
          </p>
          <p className="font-inter truncate mt-0.5" style={{ fontSize: '12px', color: '#6B6962' }}>
            {subtitle}
          </p>
          {meta}
        </div>
        <button
          onClick={onClose}
          aria-label="Close"
          className="flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-full press-shrink"
          style={{ background: '#F2EDE6' }}
        >
          <X size={14} color="#6B6962" />
        </button>
      </div>
      <div className="mt-3">
        <PrimaryButton tone={tone} size="sm" onClick={() => onPrimary?.(item)}>
          {primaryLabel} →
        </PrimaryButton>
      </div>
    </div>
  );
}