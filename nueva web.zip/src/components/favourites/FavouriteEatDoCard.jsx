import { Link } from 'react-router-dom';
import { MapPin, Star } from 'lucide-react';
import PriceRange from '@/components/ui/PriceRange';
import HeartButton from '@/components/ui/HeartButton';

const fallbackImage = 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80';

export default function FavouriteEatDoCard({ place, venue, path, onRemove }) {
  const isRestaurant = ['eat', 'restaurant'].includes(place.venue_category);
  const rating = Number(place.avg_rating || 4.7).toFixed(1);
  const location = place.neighborhood || place.address || 'Augsburg';
  const label = isRestaurant ? 'Restaurant' : 'Experience';
  const price = '€'.repeat(place.price_range || (isRestaurant ? 2 : 2));
  const Shell = ({ children }) => path ? <Link to={path} state={{ venue }} className="flex h-full flex-col">{children}</Link> : <div className="flex h-full flex-col">{children}</div>;

  return (
    <article className="group h-full w-full max-w-[360px] flex-[1_1_300px] overflow-hidden rounded-[28px] bg-white" style={{ border: '1px solid rgba(14,14,14,0.08)', boxShadow: '0 18px 44px rgba(14,14,14,0.08)' }}>
      <Shell>
        <div className="relative h-[372px] flex-shrink-0 overflow-hidden bg-roam-surface2">
          <img src={place.cover_image_url || fallbackImage} alt={place.venue_name} className="h-full w-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/[0.72] via-black/10 to-transparent" />
          <div className="absolute left-4 top-4 z-10"><HeartButton venue={venue} initialSaved initialSavedId={place.id} onChange={(isSaved) => !isSaved && onRemove(place.id)} /></div>
          <div className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5 text-roam-text">
            <Star size={13} fill="#0E0E0E" />
            <span className="font-inter text-xs font-bold">{rating}</span>
          </div>
          <div className="absolute bottom-4 left-4 right-4 text-white">
            <p className="mb-1 font-inter text-xs text-white/75">{label}</p>
            <h3 className="w-full text-[28px] leading-none tracking-[-0.04em] [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]">{place.venue_name}</h3>
          </div>
        </div>
        <div className="relative flex min-h-[190px] flex-1 flex-col p-5">
          <div className="mb-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 font-inter text-sm text-roam-muted"><MapPin size={15} /><span>{location}</span></div>
            {isRestaurant ? <PriceRange value={place.price_range || 2} /> : <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>{price}</span>}
          </div>
          <p className="font-inter text-sm leading-6 text-roam-secondary transition-all duration-500 ease-out group-hover:-translate-y-4 group-hover:opacity-0">{place.short_description || place.notes || 'Saved to your favourites.'}</p>
          <div className="mt-auto flex flex-wrap gap-2 transition-transform duration-500 ease-out group-hover:-translate-y-14" />
          <div className="absolute bottom-5 left-5 right-5 translate-y-5 opacity-0 transition-all duration-500 ease-out group-hover:translate-y-0 group-hover:opacity-100">
            <span className="inline-flex h-11 w-full items-center justify-center rounded-full font-inter text-sm font-semibold text-white" style={{ background: '#571AFF', boxShadow: '0 12px 28px rgba(87,26,255,0.28)' }}>Learn More</span>
          </div>
        </div>
      </Shell>
    </article>
  );
}