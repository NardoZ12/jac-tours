import { Link, useNavigate } from 'react-router-dom';
import { Star } from 'lucide-react';
import HeartButton from '@/components/ui/HeartButton';

const fallbackImage = 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80';

export default function FavouriteHotelCard({ place, venue, path, onRemove }) {
  const navigate = useNavigate();
  const rating = Number(place.avg_rating || 4.8).toFixed(1);
  const address = place.address || place.neighborhood || 'Augsburg';
  const price = '€'.repeat(place.price_range || 3);
  const Shell = ({ children }) => path ? <Link to={path} state={{ venue }} className="block h-full">{children}</Link> : <div className="h-full">{children}</div>;
  const handleBookNow = (event) => {
    event.preventDefault();
    event.stopPropagation();
    if (path) navigate(`${path}#book-now`, { state: { venue } });
  };

  return (
    <div className="group h-full w-full max-w-[360px] flex-[1_1_300px] overflow-visible">
      <Shell>
        <article className="relative aspect-square overflow-hidden rounded-[24px] bg-[#181818] cursor-pointer transition-transform duration-300 ease-out group-hover:-translate-y-1" style={{ boxShadow: '0 18px 44px rgba(14,14,14,0.10)' }}>
          <img src={place.cover_image_url || fallbackImage} alt={place.venue_name} loading="lazy" className="h-[118%] w-full object-cover transition-all duration-300 ease-out group-hover:scale-[1.06] group-hover:brightness-75" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/[0.96]" />
          <div className="absolute left-4 top-4 z-10"><HeartButton venue={venue} initialSaved initialSavedId={place.id} onChange={(isSaved) => !isSaved && onRemove(place.id)} /></div>
          <div className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5 text-roam-text">
            <Star size={13} fill="#0E0E0E" />
            <span className="font-inter text-xs font-bold">{rating}</span>
          </div>
          <div className="absolute bottom-[-30px] left-[18px] right-[18px] font-inter text-white transition-transform duration-300 ease-out group-hover:-translate-y-12">
            <h3 className="m-0 font-inter text-[18px] font-medium leading-tight tracking-[-0.03em] text-white">{place.venue_name}</h3>
            <p className="mt-2 flex justify-between gap-3 text-xs text-white/70">
              <span className="truncate">{address}</span>
              <span className="shrink-0"><span className="font-neue" style={{ fontSize: '13px', color: '#FFFFFF' }}>{price}</span> · Hotel</span>
            </p>
            <div className="mt-3 flex gap-2 translate-y-4 opacity-0 transition-all duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100">
              <span className="flex h-9 flex-1 items-center justify-center rounded-full border border-white/35 bg-white/10 text-xs font-semibold text-white transition-all duration-200 hover:border-[#571AFF] hover:bg-[#571AFF] hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]">Learn More</span>
              <span onClick={handleBookNow} className="flex h-9 flex-1 items-center justify-center rounded-full bg-white text-xs font-bold text-black transition-all duration-200 hover:bg-[#571AFF] hover:text-white hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]">Book Now</span>
            </div>
          </div>
        </article>
      </Shell>
    </div>
  );
}