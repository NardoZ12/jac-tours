import { useEffect, useRef, useState } from 'react';
import { CalendarDays, Users } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';

export const todayIso = () => new Date().toISOString().slice(0, 10);
export const nextIso = () => {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  return date.toISOString().slice(0, 10);
};

const formatDate = (isoDate) => {
  if (!isoDate) return '';
  const [year, month, day] = isoDate.split('-');
  return `${day}/${month}/${year}`;
};

const isoToDate = (isoDate) => {
  const [year, month, day] = isoDate.split('-').map(Number);
  return new Date(year, month - 1, day);
};

const dateToIso = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export default function PlannerInternalFilters({ startDate, endDate, people, onStartDateChange, onEndDateChange, onPeopleChange }) {
  const [dateOpen, setDateOpen] = useState(false);
  const filtersRef = useRef(null);

  useEffect(() => {
    if (!dateOpen) return;
    const handleOutsideClick = (event) => {
      if (filtersRef.current && !filtersRef.current.contains(event.target)) setDateOpen(false);
    };
    document.addEventListener('pointerdown', handleOutsideClick);
    return () => document.removeEventListener('pointerdown', handleOutsideClick);
  }, [dateOpen]);

  const handleDateRangeSelect = (range) => {
    if (!range?.from) {
      onStartDateChange('');
      onEndDateChange('');
      return;
    }
    onStartDateChange(dateToIso(range.from));
    onEndDateChange(range.to ? dateToIso(range.to) : '');
  };

  const clearDates = () => {
    onStartDateChange('');
    onEndDateChange('');
  };

  const dateRangeLabel = startDate ? [formatDate(startDate), endDate ? formatDate(endDate) : null].filter(Boolean).join(' — ') : 'Select dates';

  return (
    <div ref={filtersRef} className={`relative ${dateOpen ? 'z-[50000]' : 'z-50'} flex flex-col gap-2 sm:flex-row`}>
      <button type="button" aria-label="Choose trip dates" onClick={() => setDateOpen(!dateOpen)} className="min-h-[54px] min-w-[238px] rounded-full border border-black/5 bg-[#F8F7F4]/55 px-5 py-2 text-left shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 hover:-translate-y-0.5 hover:border-[#571AFF]/30 hover:bg-[#F8F7F4] hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.85)]">
        <p className="font-inter text-[12px] font-medium leading-none" style={{ color: '#8A8780' }}>Let&apos;s Plan Your Trip</p>
        <span className="mt-1.5 flex min-w-0 items-center gap-1.5 font-inter text-xs font-semibold" style={{ color: '#141413' }}>
          <CalendarDays size={14} color="#141413" className="shrink-0" />
          <span className="truncate">{dateRangeLabel}</span>
        </span>
      </button>

      <label className="relative flex min-h-[54px] min-w-[108px] cursor-pointer flex-col justify-center rounded-full border border-black/5 bg-[#F8F7F4]/55 px-5 py-2 text-left shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 hover:-translate-y-0.5 hover:border-[#571AFF]/30 hover:bg-[#F8F7F4] hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.85)]">
        <p className="font-inter text-[12px] font-medium leading-none" style={{ color: '#8A8780' }}>People</p>
        <span className="mt-1.5 flex items-center gap-1.5 font-inter text-xs font-semibold" style={{ color: '#141413' }}><Users size={14} color="#141413" />{people}</span>
        <select aria-label="Number of people" value={people} onChange={(event) => onPeopleChange(Number(event.target.value))} className="absolute -inset-px h-[calc(100%+2px)] w-[calc(100%+2px)] cursor-pointer rounded-full opacity-0">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((value) => <option key={value} value={value}>{value}</option>)}
        </select>
      </label>

      {dateOpen && (
        <div className="planner-date-popup fixed left-1/2 top-[76px] z-[50000] w-[calc(100vw-32px)] max-w-[330px] -translate-x-1/2 rounded-[28px] border border-black/10 bg-white p-2 text-left shadow-[0_18px_52px_rgba(14,14,14,0.16)] sm:absolute sm:top-[calc(100%+10px)] sm:w-[min(510px,calc(100vw-32px))] sm:max-w-none sm:p-3">
          <div className="mb-1.5 grid gap-1.5 sm:grid-cols-2">
            <div className="rounded-full border border-black/10 bg-white px-3 py-1.5"><p className="font-inter text-[11px] font-medium leading-none" style={{ color: '#8A8780' }}>from</p><span className="mt-1 flex items-center gap-1.5 font-inter text-[11px] font-semibold" style={{ color: '#141413' }}><CalendarDays size={13} color="#571AFF" />{formatDate(startDate) || 'Select date'}</span></div>
            <div className="rounded-full border border-black/10 bg-white px-3 py-1.5"><p className="font-inter text-[11px] font-medium leading-none" style={{ color: '#8A8780' }}>to</p><span className="mt-1 flex items-center gap-1.5 font-inter text-[11px] font-semibold" style={{ color: '#141413' }}><CalendarDays size={13} color="#571AFF" />{formatDate(endDate) || 'Optional'}</span></div>
          </div>
          <Calendar mode="range" selected={startDate ? { from: isoToDate(startDate), to: endDate ? isoToDate(endDate) : undefined } : undefined} onSelect={handleDateRangeSelect} className="w-full rounded-[24px] border border-black/10 bg-white p-2" classNames={{ month: 'w-full space-y-2', table: 'w-full border-collapse space-y-0.5', head_row: 'flex w-full justify-between', head_cell: 'w-7 text-center font-inter text-[11px] font-medium text-[#8A8780]', row: 'mt-1 flex w-full justify-between', cell: 'relative p-0 text-center text-xs focus-within:relative focus-within:z-20', day: 'h-7 w-7 rounded-full p-0 text-xs font-normal transition-all hover:bg-[#F7F4FF] hover:text-[#571AFF]', day_selected: 'bg-[#571AFF] text-white hover:bg-[#571AFF] hover:text-white focus:bg-[#571AFF] focus:text-white', day_range_start: 'day-range-start bg-[#571AFF] text-white rounded-full', day_range_end: 'day-range-end bg-[#571AFF] text-white rounded-full', day_range_middle: 'aria-selected:bg-[#F7F4FF] aria-selected:text-[#571AFF]' }} />
          {startDate && <button type="button" onClick={clearDates} className="mt-2 w-full rounded-full border border-black/10 bg-white px-4 py-2 font-inter text-xs font-semibold transition-colors hover:bg-[#F7F4FF]" style={{ color: '#571AFF' }}>Clear dates</button>}
          <button type="button" onClick={() => setDateOpen(false)} className="planner-date-apply-button mt-2 flex w-full items-center justify-center rounded-full bg-[#571AFF] px-4 py-3 font-inter text-sm font-semibold text-white shadow-[0_12px_28px_rgba(87,26,255,0.24)] transition-all hover:bg-[#0E0E0E] sm:hidden">Apply dates</button>
        </div>
      )}
    </div>
  );
}