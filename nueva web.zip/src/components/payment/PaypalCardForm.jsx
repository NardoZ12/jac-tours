import { useEffect, useRef, useState } from 'react';
import { Loader2, Lock } from 'lucide-react';
import {
  loadPaypalSdk,
  createCardOrder,
  capturePaypalOrder,
  startPaypalCheckout,
} from '@/lib/paypalCheckout';

const FIELD_STYLE = {
  input: { 'font-size': '14px', 'font-family': 'Inter, sans-serif', color: '#141413', padding: '0 16px' },
  '::placeholder': { color: '#9A978F' },
  '.invalid': { color: '#DC2626' },
};

const FIELD_BOX = { height: '48px', background: '#F0EFE9', border: '1.5px solid #E8E6DC', overflow: 'hidden' };

/**
 * Card payment on our own page using PayPal's secure card fields.
 * The buyer types card data here (no PayPal account needed); on success the
 * order is captured and `onPaid` is called.
 */
export default function PaypalCardForm({ amount, description, booking, onPaid }) {
  const [state, setState] = useState('loading'); // loading | ready | unavailable
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState(null);
  const cardFieldsRef = useRef(null);
  const latest = useRef({});
  latest.current = { amount, description, booking, onPaid };

  useEffect(() => {
    let cancelled = false;
    const ids = ['#pp-card-name', '#pp-card-number', '#pp-card-expiry', '#pp-card-cvv'];

    loadPaypalSdk()
      .then((paypal) => {
        if (cancelled) return;
        const fields = paypal.CardFields({
          style: FIELD_STYLE,
          createOrder: () => createCardOrder({ amount: latest.current.amount, description: latest.current.description }),
          onApprove: async (data) => {
            try {
              const result = await capturePaypalOrder({ orderId: data.orderID, booking: latest.current.booking });
              latest.current.onPaid(result);
            } catch (e) {
              setError(e.message);
              setPaying(false);
            }
          },
          onError: (err) => {
            setError(err?.message?.includes('declined') ? 'Tu tarjeta fue rechazada.' : 'No se pudo procesar el pago. Revisa los datos e inténtalo de nuevo.');
            setPaying(false);
          },
        });
        if (!fields.isEligible()) {
          setState('unavailable');
          return;
        }
        fields.NameField().render(ids[0]);
        fields.NumberField().render(ids[1]);
        fields.ExpiryField().render(ids[2]);
        fields.CVVField().render(ids[3]);
        cardFieldsRef.current = fields;
        setState('ready');
      })
      .catch((e) => {
        setError(e.message);
        setState('unavailable');
      });

    return () => {
      cancelled = true;
      cardFieldsRef.current = null;
      ids.forEach((id) => {
        const el = document.querySelector(id);
        if (el) el.innerHTML = '';
      });
    };
  }, []);

  const pay = async () => {
    if (!cardFieldsRef.current) return;
    setError(null);
    setPaying(true);
    try {
      await cardFieldsRef.current.submit();
    } catch {
      setError('Revisa los datos de tu tarjeta e inténtalo de nuevo.');
      setPaying(false);
    }
  };

  const goToPaypal = async () => {
    setError(null);
    setPaying(true);
    try {
      await startPaypalCheckout({ amount, description, booking });
    } catch (e) {
      setError(e.message);
      setPaying(false);
    }
  };

  return (
    <div>
      <p className="font-inter mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Datos de tu tarjeta</p>

      <div className="space-y-3 mb-4" style={{ display: state === 'unavailable' ? 'none' : 'block' }}>
        <div id="pp-card-name" className="rounded-2xl" style={FIELD_BOX} />
        <div id="pp-card-number" className="rounded-2xl" style={FIELD_BOX} />
        <div className="grid grid-cols-2 gap-3">
          <div id="pp-card-expiry" className="rounded-2xl" style={FIELD_BOX} />
          <div id="pp-card-cvv" className="rounded-2xl" style={FIELD_BOX} />
        </div>
      </div>

      {error && <p className="font-inter mb-2 text-center" style={{ fontSize: '12px', color: '#DC2626' }}>{error}</p>}

      {state === 'loading' && (
        <div className="flex items-center justify-center gap-2 py-2">
          <Loader2 size={16} className="animate-spin" color="#141413" />
          <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>Cargando pago seguro…</span>
        </div>
      )}

      {state === 'ready' && (
        <>
          <button onClick={pay} disabled={paying} className="btn-primary flex items-center justify-center gap-2">
            {paying ? <><Loader2 size={16} className="animate-spin" /> Procesando…</> : <><Lock size={14} /> Pagar ${amount}</>}
          </button>
          <p className="font-inter mt-3 text-center" style={{ fontSize: '11px', color: '#72706A' }}>
            Pago seguro con PayPal. No necesitas una cuenta de PayPal.
          </p>
        </>
      )}

      {state === 'unavailable' && (
        <>
          <p className="font-inter mb-3 text-center" style={{ fontSize: '12px', color: '#72706A' }}>
            El pago con tarjeta en esta página no está disponible ahora mismo.
          </p>
          <button onClick={goToPaypal} disabled={paying} className="btn-primary">
            {paying ? 'Redirigiendo…' : <>Continuar en PayPal · ${amount}</>}
          </button>
        </>
      )}
    </div>
  );
}