export default function FriendRow({ friend, onHangout }) {
  return (
    <div className="flex items-center gap-3 py-3 px-4 rounded-2xl bg-white" style={{ border: '1px solid #E8E6DC' }}>
      <div
        className="w-11 h-11 rounded-full flex items-center justify-center font-poppins font-semibold text-white flex-shrink-0"
        style={{ background: friend.color, fontSize: '14px' }}
      >
        {friend.initials}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{friend.name}</p>
        <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
          {friend.neighborhood} · {friend.distance_min} min away
        </p>
      </div>
      <button
        onClick={() => onHangout(friend)}
        className="font-poppins font-semibold text-white"
        style={{ fontSize: '12px', padding: '8px 14px', borderRadius: '10px', background: '#D97757' }}
      >
        Hang out?
      </button>
    </div>
  );
}