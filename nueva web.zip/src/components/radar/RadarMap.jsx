import { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Default Tel Aviv center (fallback)
const DEFAULT_CENTER = [32.0853, 34.7818];

// Build a custom HTML divIcon for a friend pin (initials in colored circle)
function friendIcon(friend) {
  const html = `
    <div style="
      width:40px;height:40px;border-radius:50%;
      background:${friend.color || '#D97757'};
      color:#fff;font-family:Poppins,sans-serif;font-weight:700;font-size:13px;
      display:flex;align-items:center;justify-content:center;
      border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.25);
    ">${friend.initials || friend.name?.[0] || '?'}</div>`;
  return L.divIcon({ html, className: '', iconSize: [40, 40], iconAnchor: [20, 20] });
}

const meIcon = L.divIcon({
  html: `<div style="
    width:18px;height:18px;border-radius:50%;
    background:#2A6DB5;border:3px solid #fff;box-shadow:0 0 0 6px rgba(42,109,181,0.25);
  "></div>`,
  className: '',
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

// Re-center the map when center changes
function Recenter({ center }) {
  const map = useMap();
  useEffect(() => { if (center) map.setView(center, map.getZoom()); }, [center, map]);
  return null;
}

export default function RadarMap({ friends = [], onSelectFriend }) {
  const [myLocation, setMyLocation] = useState(null);
  const [locError, setLocError] = useState(null);

  // Get user's GPS once on mount
  useEffect(() => {
    if (!navigator.geolocation) { setLocError('GPS not available'); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => setMyLocation([pos.coords.latitude, pos.coords.longitude]),
      () => setLocError('Location permission denied'),
      { enableHighAccuracy: false, timeout: 8000 }
    );
  }, []);

  const center = useMemo(() => {
    if (myLocation) return myLocation;
    if (friends.length) return [friends[0].lat, friends[0].lng];
    return DEFAULT_CENTER;
  }, [myLocation, friends]);

  return (
    <div className="relative" style={{ height: '420px' }}>
      <MapContainer
        center={center}
        zoom={14}
        scrollWheelZoom
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; OpenStreetMap'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Recenter center={center} />

        {/* My location */}
        {myLocation && (
          <>
            <Marker position={myLocation} icon={meIcon}>
              <Popup>You are here</Popup>
            </Marker>
            <Circle center={myLocation} radius={300} pathOptions={{ color: '#2A6DB5', fillColor: '#2A6DB5', fillOpacity: 0.08, weight: 1 }} />
          </>
        )}

        {/* Friend pins (fuzzy zone shown as circle, not exact pin) */}
        {friends.map(f => (
          <div key={f.id}>
            <Circle
              center={[f.lat, f.lng]}
              radius={250}
              pathOptions={{ color: f.color || '#D97757', fillColor: f.color || '#D97757', fillOpacity: 0.15, weight: 1 }}
            />
            <Marker position={[f.lat, f.lng]} icon={friendIcon(f)}>
              <Popup>
                <div style={{ minWidth: '180px', fontFamily: 'Inter, sans-serif' }}>
                  <p style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: '14px', color: '#141413', margin: 0 }}>
                    {f.name}
                  </p>
                  <p style={{ fontSize: '12px', color: '#72706A', margin: '2px 0 8px' }}>
                    {f.neighborhood} · {f.distance_km}km · {f.distance_min}m away
                  </p>
                  <button
                    onClick={() => onSelectFriend?.(f)}
                    style={{
                      width: '100%', height: '32px', borderRadius: '8px',
                      background: '#141413', color: '#fff', border: 'none',
                      fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: '12px',
                      cursor: 'pointer',
                    }}
                  >
                    Hangout →
                  </button>
                </div>
              </Popup>
            </Marker>
          </div>
        ))}
      </MapContainer>

      {/* Privacy / status pill overlay */}
      <div className="absolute top-3 left-3 z-[400] flex items-center gap-2 px-3 py-1.5 rounded-full bg-white card-shadow">
        <span className="pulse-dot" style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#16A34A', display: 'inline-block' }} />
        <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#141413' }}>
          Live · {friends.length} active
        </span>
      </div>

      {locError && (
        <div className="absolute bottom-3 left-3 right-3 z-[400] px-3 py-2 rounded-lg bg-white card-shadow">
          <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
            📍 {locError} · showing approximate area
          </p>
        </div>
      )}
    </div>
  );
}