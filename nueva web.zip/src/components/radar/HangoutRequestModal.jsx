import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';

const PRESETS = ['Lunch?', 'Coffee?', 'Drinks?'];

export default function HangoutRequestModal({ friend, onClose, onAccepted }) {
  const [message, setMessage] = useState('Lunch?');
  const [stage, setStage] = useState('compose'); // compose | sent
  const [secondsLeft, setSecondsLeft] = useState(15 * 60);
  const [requestId, setRequestId] = useState(null);

  useEffect(() => {
    if (stage !== 'sent') return;
    const id = setInterval(() => setSecondsLeft(s => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [stage]);

  // Auto-accept simulation after 4 seconds for demo
  useEffect(() => {
    if (stage !== 'sent') return;
    const t = setTimeout(() => {
      if (onAccepted) onAccepted({ id: requestId, friend, message });
    }, 4000);
    return () => clearTimeout(t);
  }, [stage, requestId, friend, message, onAccepted]);

  const send = async () => {
    setRequestId(`demo-${Date.now()}`);
    setStage('sent');
  };

  const m = Math.floor(secondsLeft / 60);
  const s = String(secondsLeft % 60).padStart(2, '0');

  return (
    <>
      <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
        <div className="flex justify-center pt-3 pb-4">
          <div className="w-10 h-1 rounded-full" style={{ background: '#E8E6DC' }} />
        </div>
        <div className="px-5 pb-8 relative">
          <button onClick={onClose} className="absolute top-0 right-5 w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>
            <X size={16} color="#141413" />
          </button>

          {stage === 'compose' ? (
            <>
              <h2 className="font-poppins font-bold mb-1" style={{ fontSize: '20px', color: '#141413' }}>Send to {friend.name}</h2>
              <p className="font-inter mb-4" style={{ fontSize: '13px', color: '#72706A' }}>{friend.neighborhood} · {friend.distance_min} min away</p>

              <div className="flex gap-2 mb-3 flex-wrap">
                {PRESETS.map(p => (
                  <button
                    key={p}
                    onClick={() => setMessage(p)}
                    className="font-poppins font-semibold"
                    style={{
                      fontSize: '13px', padding: '8px 16px', borderRadius: '99px',
                      background: message === p ? '#141413' : '#F0EFE9',
                      color: message === p ? '#FFF' : '#72706A',
                    }}
                  >{p}</button>
                ))}
              </div>

              <input
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Or type a message..."
                className="w-full font-inter outline-none mb-4"
                style={{ background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '12px', padding: '12px 16px', fontSize: '14px' }}
              />

              <button
                onClick={send}
                className="w-full font-poppins font-semibold text-white"
                style={{ height: '48px', borderRadius: '12px', background: '#D97757', fontSize: '14px' }}
              >
                Send request
              </button>
            </>
          ) : (
            <div className="text-center py-4">
              <div className="relative w-16 h-16 mx-auto mb-4">
                <span className="absolute inset-0 rounded-full pulse-dot" style={{ background: '#D97757', opacity: 0.2 }} />
                <span className="absolute inset-3 rounded-full pulse-dot" style={{ background: '#D97757', opacity: 0.5, animationDelay: '0.3s' }} />
                <div className="absolute inset-5 rounded-full" style={{ background: '#D97757' }} />
              </div>
              <h2 className="font-poppins font-bold mb-1" style={{ fontSize: '20px', color: '#141413' }}>
                Request sent!
              </h2>
              <p className="font-inter mb-4" style={{ fontSize: '14px', color: '#72706A' }}>
                Waiting for {friend.name.split(' ')[0]}...
              </p>
              <p className="font-poppins font-bold" style={{ fontSize: '24px', color: '#D97757' }}>{m}:{s}</p>
              <p className="font-inter mt-1" style={{ fontSize: '12px', color: '#B0AEA5' }}>Request expires in</p>
            </div>
          )}
        </div>
      </ResponsiveSheetShell>
    </>
  );
}