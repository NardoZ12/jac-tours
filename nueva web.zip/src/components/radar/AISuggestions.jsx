import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import VenuePhoto from '@/components/ui/VenuePhoto';
import { listContentByType } from '@/lib/contentTables';
import BookingSheet from '@/components/eat/BookingSheet';

export default function AISuggestions({ friend, message, onClose }) {
  const [loading, setLoading] = useState(true);
  const [suggestions, setSuggestions] = useState([]);
  const [bookingVenue, setBookingVenue] = useState(null);

  useEffect(() => {
    const generate = async () => {
      try {
        const me = await base44.auth.me().catch(() => null);
        const venues = await listContentByType('eat', '-avg_rating', 50);
        const venueList = (venues || []).slice(0, 8).map(v => ({
          id: v.id,
          name: v.name,
          neighborhood: v.neighborhood,
          cuisine: v.cuisine_tags?.[0] || v.sub_category,
        }));

        const myTaste = me?.taste_profile?.cuisines?.join(', ') || 'Mediterranean';
        const friendTaste = friend.taste?.cuisines?.join(', ') || 'Mediterranean';

        const res = await base44.integrations.Core.InvokeLLM({
          prompt: `Roam app. User wants to meet a friend.\nMy taste: ${myTaste}.\nFriend (${friend.name}, in ${friend.neighborhood}) taste: ${friendTaste}.\nMessage: "${message}".\nPick 3 best venues from this list halfway between us. Return JSON array of objects with venue_id, venue_name, reason (one short witty sentence why this place matches both), dist_a_minutes, dist_b_minutes.\nVenues: ${JSON.stringify(venueList)}`,
          response_json_schema: {
            type: 'object',
            properties: {
              suggestions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    venue_id: { type: 'string' },
                    venue_name: { type: 'string' },
                    reason: { type: 'string' },
                    dist_a_minutes: { type: 'number' },
                    dist_b_minutes: { type: 'number' },
                  },
                },
              },
            },
          },
        });

        const list = res?.suggestions?.slice(0, 3) || [];
        // Hydrate venue records
        const hydrated = await Promise.all(list.map(async s => {
          const v = (venues || []).find(x => x.id === s.venue_id) || (venues || [])[0];
          return { ...s, venue: v };
        }));
        setSuggestions(hydrated.filter(h => h.venue));
      } catch {
        // Fallback - top 3 restaurants
        const venues = await listContentByType('eat', '-avg_rating', 50);
        setSuggestions((venues || []).slice(0, 3).map(v => ({
          venue: v,
          venue_name: v.name,
          reason: 'A great match for both of you.',
          dist_a_minutes: 8,
          dist_b_minutes: 9,
        })));
      }
      setLoading(false);
    };
    generate();
  }, [friend, message]);

  return (
    <div className="fixed inset-0 z-[30000] overflow-y-auto" style={{ background: '#FAF9F5' }}>
      <div className="max-w-[430px] lg:max-w-3xl mx-auto pb-12">
        <div className="flex items-center px-5 pt-12 pb-4">
          <button onClick={onClose} className="w-10 h-10 flex items-center justify-center rounded-xl" style={{ background: '#F0EFE9' }}>
            <ArrowLeft size={18} color="#141413" />
          </button>
        </div>

        <div className="px-5 mb-5">
          <h1 className="font-poppins font-bold" style={{ fontSize: '22px', color: '#141413', letterSpacing: '-0.5px' }}>
            AI picked 3 spots for you
          </h1>
          <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>
            Halfway between you and {friend.neighborhood}
          </p>
        </div>

        <div className="px-5 space-y-4 lg:grid lg:grid-cols-2 lg:gap-4 lg:space-y-0">
          {loading ? (
            [0,1,2].map(i => (
              <div key={i} className="rounded-2xl overflow-hidden card-shadow bg-white">
                <div className="skeleton w-full" style={{ height: '160px' }} />
                <div className="p-3 space-y-2">
                  <div className="skeleton h-4 w-2/3 rounded" />
                  <div className="skeleton h-3 w-full rounded" />
                </div>
              </div>
            ))
          ) : suggestions.map((s, i) => (
            <div key={i} className="rounded-2xl overflow-hidden card-shadow bg-white">
              <VenuePhoto venue={s.venue} height={160} rounded="0" />
              <div className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>{s.venue.name}</p>
                    <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
                      {s.venue.cuisine_tags?.[0] || s.venue.sub_category} · {s.venue.neighborhood}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#141413' }}>
                      You: {s.dist_a_minutes}m
                    </p>
                    <p className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#141413' }}>
                      {friend.name.split(' ')[0]}: {s.dist_b_minutes}m
                    </p>
                  </div>
                </div>

                <div className="mt-3 pl-3 italic font-inter" style={{ fontSize: '13px', color: '#141413', borderLeft: '3px solid #D97757', lineHeight: 1.5 }}>
                  {s.reason}
                </div>

                <button
                  onClick={() => setBookingVenue(s.venue)}
                  className="w-full font-poppins font-semibold text-white mt-4"
                  style={{ height: '44px', borderRadius: '12px', background: '#141413', fontSize: '14px' }}
                >
                  Book this →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {bookingVenue && (
        <BookingSheet
          venue={bookingVenue}
          selectedTime="13:00"
          selectedDate="Today"
          partySize={2}
          onClose={() => { setBookingVenue(null); onClose(); }}
        />
      )}
    </div>
  );
}