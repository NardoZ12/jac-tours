import { useIsDesktop } from '@/hooks/useBreakpoint';

/**
 * Responsive shell for bottom sheets / modals.
 * - Mobile (< 1024px): bottom-anchored sheet (current behavior)
 * - Desktop (≥ 1024px): right-side slide-in panel (480px wide, full height)
 *
 * Drop in around any existing sheet body — no inner markup changes needed.
 * Renders:
 *   <ResponsiveSheetShell onClose={...} zIndex={30000}>
 *     {existing sheet content}
 *   </ResponsiveSheetShell>
 */
 export default function ResponsiveSheetShell({ children, onClose, zIndex = 30000, contentClassName = '', contentStyle }) {
  const isDesktop = useIsDesktop();
  const effectiveZIndex = Math.max(zIndex, 30000);
  const backdropZ = effectiveZIndex - 1;

  if (isDesktop) {
    return (
      <>
        <div
          className="fixed inset-0"
          style={{ background: 'rgba(0,0,0,0.5)', zIndex: backdropZ }}
          onClick={onClose}
        />
        <div
          className={`fixed top-0 right-0 h-screen w-full max-w-[480px] bg-white flex flex-col ${contentClassName}`}
          style={{
            zIndex: effectiveZIndex,
            boxShadow: '-12px 0 32px rgba(0,0,0,0.18)',
            animation: 'slideInFromRight 280ms cubic-bezier(0.22, 1, 0.36, 1) both',
            ...contentStyle,
          }}
        >
          <style>{`
            @keyframes slideInFromRight {
              from { transform: translateX(40px); opacity: 0; }
              to   { transform: translateX(0);    opacity: 1; }
            }
          `}</style>
          {children}
        </div>
      </>
    );
  }

  // Mobile — preserve original bottom-sheet behavior
  return (
    <>
      <div
        className="fixed inset-0"
        style={{ background: 'rgba(0,0,0,0.5)', zIndex: backdropZ }}
        onClick={onClose}
      />
      <div
        className={`fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bottom-sheet bg-white flex flex-col ${contentClassName}`}
        style={{ zIndex: effectiveZIndex, maxHeight: '92vh', ...contentStyle }}
      >
        {children}
      </div>
    </>
  );
}