import { Star } from 'lucide-react';

export default function RatingStars({ rating, reviewCount, size = 14, showCount = true }) {
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    stars.push(
      <Star
        key={i}
        size={size}
        style={{
          fill: i <= Math.round(rating) ? '#D97757' : '#E8E6DC',
          color: i <= Math.round(rating) ? '#D97757' : '#E8E6DC',
        }}
      />
    );
  }
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center gap-0.5">{stars}</div>
      {rating && (
        <span className="font-poppins font-semibold text-roam-text" style={{ fontSize: '13px' }}>
          {rating.toFixed(1)}
        </span>
      )}
      {showCount && reviewCount != null && (
        <span className="font-inter text-roam-muted" style={{ fontSize: '12px' }}>
          ({reviewCount})
        </span>
      )}
    </div>
  );
}