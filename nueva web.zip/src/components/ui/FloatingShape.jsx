import { motion } from 'framer-motion';

/**
 * Decorative floating blob — infinite gentle drift + rotation.
 * Use behind hero sections for ambient motion.
 */
export default function FloatingShape({ className, style, duration = 10, delay = 0, float = 24 }) {
  return (
    <motion.div
      className={className}
      style={style}
      animate={{ y: [0, -float, 0], x: [0, float * 0.35, 0], rotate: [0, 8, 0] }}
      transition={{ duration, delay, repeat: Infinity, ease: 'easeInOut' }}
    />
  );
}