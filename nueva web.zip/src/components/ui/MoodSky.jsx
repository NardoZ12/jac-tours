/**
 * MoodSky — the Wander signature element.
 * A grainy, hand-painted-feeling gradient sky mapped to a time-of-day mood.
 * Pass `mood` = 'dawn' | 'morning' | 'midday' | 'golden' | 'dusk' | 'night'
 * or omit to auto-detect from current time.
 */

const SKIES = {
  dawn: {
    gradient: 'linear-gradient(160deg, #1a1333 0%, #3d2052 30%, #c4607a 65%, #f2a07b 85%, #fdd89a 100%)',
    label: 'Dawn',
  },
  morning: {
    gradient: 'linear-gradient(160deg, #c9e8f7 0%, #a8d4f0 25%, #7ab8e0 50%, #f7c98b 80%, #fde8c2 100%)',
    label: 'Morning',
  },
  midday: {
    gradient: 'linear-gradient(160deg, #4fa3d4 0%, #74bde8 35%, #a8d8f0 60%, #d4ecf9 85%, #f0f8ff 100%)',
    label: 'Midday',
  },
  golden: {
    gradient: 'linear-gradient(160deg, #2a1f0e 0%, #7a3b1e 25%, #c4622a 50%, #e8943a 70%, #f7c96a 88%, #fde9aa 100%)',
    label: 'Golden hour',
  },
  dusk: {
    gradient: 'linear-gradient(160deg, #0d0d1a 0%, #1e1438 30%, #6b3070 55%, #b05a7a 75%, #e08a7a 92%, #f7c4a0 100%)',
    label: 'Dusk',
  },
  night: {
    gradient: 'linear-gradient(160deg, #050510 0%, #0a0a24 40%, #111438 70%, #1a1f50 88%, #22286a 100%)',
    label: 'Night',
  },
};

function getMoodFromHour() {
  const h = new Date().getHours();
  if (h >= 5 && h < 7) return 'dawn';
  if (h >= 7 && h < 11) return 'morning';
  if (h >= 11 && h < 16) return 'midday';
  if (h >= 16 && h < 19) return 'golden';
  if (h >= 19 && h < 21) return 'dusk';
  return 'night';
}

/**
 * Tiny SVG grain overlay — gives the hand-painted feel.
 * Rendered as a data-URI background on top of the gradient.
 */
const GRAIN_SVG = `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.08'/%3E%3C/svg%3E")`;

export default function MoodSky({ mood, height = 140, children, className = '' }) {
  const key = mood || getMoodFromHour();
  const sky = SKIES[key] || SKIES.golden;

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      style={{ height, background: sky.gradient }}
    >
      {/* Grain overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: GRAIN_SVG, backgroundRepeat: 'repeat', opacity: 0.6 }}
      />
      {children}
    </div>
  );
}

export { SKIES, getMoodFromHour };