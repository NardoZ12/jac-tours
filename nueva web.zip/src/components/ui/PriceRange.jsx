export default function PriceRange({ value, className = '' }) {
  return (
    <span className={`font-neue ${className}`} style={{ fontSize: '13px', color: className.includes('text-white') ? '#FFFFFF' : '#72706A' }}>
      {'€'.repeat(value)}
      <span style={{ opacity: 0.3 }}>{'€'.repeat(4 - value)}</span>
    </span>);

}