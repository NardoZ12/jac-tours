import { motion } from 'framer-motion';

/**
 * Scroll-triggered reveal wrapper. Fades + slides children into view once.
 */
export default function Reveal({ children, delay = 0, y = 28, x = 0, duration = 0.6, className, style, once = true, amount = 0.15 }) {
  return (
    <motion.div
      className={className}
      style={style}
      initial={{ opacity: 0, y, x }}
      whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once, amount }}
      transition={{ duration, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}