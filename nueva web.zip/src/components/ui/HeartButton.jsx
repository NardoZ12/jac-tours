import { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getSavedPlaceMap, setSavedInCache } from '@/lib/savedPlacesCache';

/**
 * Reusable Heart save toggle for venue cards & detail pages.
 * - Loads existing SavedPlace state on mount (per current user + venue).
 * - Toggles create/delete on tap with optimistic UI.
 *
 * Variants:
 *  - "overlay" (default): white heart on translucent dark circle, for use on photos.
 *  - "ghost": dark heart on light surface, for use on light backgrounds.
 */
export default function HeartButton({ venue, variant = 'overlay', size = 16, className = '', initialSaved = false, initialSavedId = null, onChange }) {
  const [saved, setSaved] = useState(initialSaved);
  const [savedId, setSavedId] = useState(initialSavedId);

  useEffect(() => {
    if (!venue?.id || initialSaved) return;
    let cancelled = false;
    getSavedPlaceMap().then((m) => {
      const rec = m[venue.id];
      if (!cancelled && rec) {
        setSaved(true);
        setSavedId(rec.id);
      }
    });
    return () => { cancelled = true; };
  }, [venue?.id, initialSaved]);

  const handleToggle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!venue?.id) return;
    const next = !saved;
    setSaved(next);
    onChange?.(next);
    const user = await base44.auth.me().catch(() => null);
    if (!user) return;
    if (next) {
      const created = await base44.entities.SavedPlace.create({
        user_id: user.id,
        venue_id: venue.id,
        venue_name: venue.name,
        venue_category: venue.category,
        cover_image_url: venue.cover_image_url,
        neighborhood: venue.neighborhood,
        address: venue.address,
        price_range: venue.price_range,
        avg_rating: venue.avg_rating,
        short_description: venue.short_description
      });
      setSavedId(created.id);
      setSavedInCache(venue.id, created);
    } else if (savedId) {
      await base44.entities.SavedPlace.delete(savedId);
      setSavedId(null);
      setSavedInCache(venue.id, null);
    }
  };

  const isOverlay = variant === 'overlay';
  const bg = isOverlay ? 'rgba(0,0,0,0.45)' : '#FFFFFF';
  const iconColor = isOverlay ? 'white' : (saved ? '#EC4899' : '#141413');
  const fill = saved ? (isOverlay ? 'white' : '#EC4899') : 'none';

  return (
    <button
      type="button"
      onClick={handleToggle}
      aria-label={saved ? 'Remove from favorites' : 'Save to favorites'}
      aria-pressed={saved}
      className={`relative z-20 w-9 h-9 flex items-center justify-center rounded-full press-shrink ${className}`}
      style={{ background: bg, backdropFilter: isOverlay ? 'blur(6px)' : undefined, boxShadow: isOverlay ? undefined : '0 1px 4px rgba(20,20,19,0.08)' }}
    >
      <Heart size={size} color={iconColor} fill={fill} />
    </button>
  );
}