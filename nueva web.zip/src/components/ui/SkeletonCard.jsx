export default function SkeletonCard({ height = 280, className = '' }) {
  return (
    <div className={`rounded-2xl overflow-hidden card-shadow bg-white ${className}`}>
      <div className={`skeleton w-full`} style={{ height: `${height * 0.65}px` }} />
      <div className="p-3 space-y-2">
        <div className="skeleton h-4 w-3/4 rounded" />
        <div className="skeleton h-3 w-1/2 rounded" />
        <div className="flex gap-2 mt-2">
          <div className="skeleton h-7 w-16 rounded-lg" />
          <div className="skeleton h-7 w-16 rounded-lg" />
          <div className="skeleton h-7 w-16 rounded-lg" />
        </div>
      </div>
    </div>
  );
}