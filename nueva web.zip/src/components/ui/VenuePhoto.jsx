import { useState } from 'react';

const CUISINE_GRADIENTS = {
  Japanese: 'linear-gradient(135deg,#1a1208,#2d1e0a)',
  Italian: 'linear-gradient(135deg,#160810,#250d18)',
  Israeli: 'linear-gradient(135deg,#0a1210,#0f1e18)',
  Mediterranean: 'linear-gradient(135deg,#060c0a,#0c1a15)',
  hotel: 'linear-gradient(135deg,#051020,#0a1e3a)',
  experience: 'linear-gradient(135deg,#051205,#0a2010)',
  default: 'linear-gradient(135deg,#0a0a14,#141420)',
};

export function venueGradient(venue) {
  if (venue?.category === 'hotel') return CUISINE_GRADIENTS.hotel;
  if (venue?.category === 'experience') return CUISINE_GRADIENTS.experience;
  const cuisine = venue?.cuisine_tags?.[0] || venue?.sub_category;
  return CUISINE_GRADIENTS[cuisine] || CUISINE_GRADIENTS.default;
}

export default function VenuePhoto({ venue, height = 200, className = '', children, rounded = '16px 16px 0 0' }) {
  const [errored, setErrored] = useState(false);
  const grad = venueGradient(venue);
  const showImg = venue?.cover_image_url && !errored;

  return (
    <div className={`relative overflow-hidden ${className}`} style={{ height: `${height}px`, background: grad, borderRadius: rounded }}>
      {showImg && (
        <img
          src={venue.cover_image_url}
          alt={venue.name}
          onError={() => setErrored(true)}
          className="absolute inset-0 w-full h-full object-cover"
          loading="lazy"
        />
      )}
      {/* Bottom dark gradient overlay */}
      <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.84) 0%, transparent 60%)' }} />
      {children}
    </div>
  );
}