export default function VerticalBadge({ type, className = '' }) {
  const config = {
    eat:   { label: 'EAT',   bg: '#FF385C' },
    stay:  { label: 'STAY',  bg: '#0071C2' },
    do:    { label: 'DO',    bg: '#008A05' },
    today: { label: 'TODAY', bg: '#FFB400' },
  };
  const c = config[type] || config.eat;
  return (
    <span
      className={`font-poppins font-semibold text-white inline-block ${className}`}
      style={{
        fontSize: '12px',
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        background: c.bg,
        padding: '3px 8px',
        borderRadius: '8px',
      }}
    >
      {c.label}
    </span>
  );
}