import { forwardRef } from 'react';

/**
 * Roam primary action button — consistent rounded shape, soft drop shadow,
 * and tactile press feedback. Used for the most prominent CTAs across the app
 * (Book / Confirm / Continue / Join / Hangout).
 *
 * Props:
 *   - tone: 'dark' (default) | 'coral' | 'green' | 'sky'
 *   - size: 'md' (default, h=48) | 'lg' (h=52) | 'sm' (h=40)
 *   - disabled, onClick, children, className, style
 */
const TONES = {
  dark:  { bg: '#1F1B2E', shadow: '0 6px 18px rgba(31, 27, 46, 0.28)' },
  coral: { bg: '#FF7849', shadow: '0 8px 22px rgba(255, 120, 73, 0.35)' },
  green: { bg: '#4A7A35', shadow: '0 6px 18px rgba(74, 122, 53, 0.30)' },
  sky:   { bg: '#0EA5E9', shadow: '0 6px 18px rgba(14, 165, 233, 0.30)' },
};

const SIZES = {
  sm: { height: '40px', radius: '14px', font: '13px' },
  md: { height: '48px', radius: '16px', font: '14px' },
  lg: { height: '52px', radius: '18px', font: '14px' },
};

const PrimaryButton = forwardRef(function PrimaryButton(
  { tone = 'dark', size = 'md', disabled = false, children, className = '', style = {}, ...rest },
  ref
) {
  const t = TONES[tone] || TONES.dark;
  const s = SIZES[size] || SIZES.md;
  return (
    <button
      ref={ref}
      disabled={disabled}
      className={`w-full font-poppins font-semibold press-shrink ${className}`}
      style={{
        height: s.height,
        borderRadius: s.radius,
        fontSize: s.font,
        background: disabled ? '#E8E6DC' : t.bg,
        color: disabled ? '#B0AEA5' : '#FFFFFF',
        boxShadow: disabled ? 'none' : t.shadow,
        border: 'none',
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
});

export default PrimaryButton;