export default function FilterChips({ chips, selected, onSelect, className = '' }) {
  return (
    <div className={`flex gap-2 overflow-x-auto scrollbar-hide px-5 ${className}`}>
      {chips.map((chip) => {
        const active = selected === chip || (Array.isArray(selected) && selected.includes(chip));
        return (
          <button
            key={chip}
            onClick={() => onSelect(chip)}
            className="flex-shrink-0 font-poppins font-semibold transition-all"
            style={{
              fontSize: '12px',
              padding: '8px 16px',
              borderRadius: '99px',
              background: active ? '#141413' : '#F0EFE9',
              color: active ? '#FFFFFF' : '#72706A',
              border: 'none',
              whiteSpace: 'nowrap',
            }}
          >
            {chip}
          </button>
        );
      })}
    </div>
  );
}