import { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

/**
 * Horizontal scroll gallery for venue/place photos.
 * Shows cover image + gallery_images in a swipeable strip with a lightbox.
 */
export default function VenueGallery({ venue, max = 8 }) {
  const [lightbox, setLightbox] = useState(null);

  const photos = [
    venue.cover_image_url,
    ...(Array.isArray(venue.gallery_images) ? venue.gallery_images : []),
  ].filter(Boolean).slice(0, max);

  if (photos.length <= 1) return null;

  const openLightbox = (index) => setLightbox(index);
  const closeLightbox = () => setLightbox(null);
  const prev = () => setLightbox((i) => (i - 1 + photos.length) % photos.length);
  const next = () => setLightbox((i) => (i + 1) % photos.length);

  return (
    <>
      <div className="mt-6">
        <h2 className="font-poppins font-semibold mb-3" style={{ fontSize: '20px', color: '#141413' }}>Galería</h2>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide -mx-5 px-5 pb-2" style={{ scrollSnapType: 'x mandatory' }}>
          {photos.map((url, i) => (
            <button
              key={i}
              type="button"
              onClick={() => openLightbox(i)}
              className="flex-shrink-0 overflow-hidden rounded-2xl press-shrink"
              style={{
                width: i === 0 ? '260px' : '200px',
                height: '200px',
                scrollSnapAlign: 'start',
                border: '1px solid rgba(14,14,14,0.08)',
              }}
            >
              <img src={url} alt={`${venue.name} ${i + 1}`} className="h-full w-full object-cover" loading="lazy" />
            </button>
          ))}
        </div>
      </div>

      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[40000] flex items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.92)' }}
          onClick={closeLightbox}
        >
          <button
            className="absolute top-5 right-5 w-10 h-10 flex items-center justify-center rounded-full"
            style={{ background: 'rgba(255,255,255,0.15)' }}
            onClick={closeLightbox}
          >
            <X size={20} color="#FFFFFF" />
          </button>
          <button
            className="absolute left-3 w-11 h-11 flex items-center justify-center rounded-full"
            style={{ background: 'rgba(255,255,255,0.15)' }}
            onClick={(e) => { e.stopPropagation(); prev(); }}
          >
            <ChevronLeft size={24} color="#FFFFFF" />
          </button>
          <img
            src={photos[lightbox]}
            alt={`${venue.name} ${lightbox + 1}`}
            className="max-w-[92vw] max-h-[82vh] object-contain rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            className="absolute right-3 w-11 h-11 flex items-center justify-center rounded-full"
            style={{ background: 'rgba(255,255,255,0.15)' }}
            onClick={(e) => { e.stopPropagation(); next(); }}
          >
            <ChevronRight size={24} color="#FFFFFF" />
          </button>
          <span className="absolute bottom-6 left-1/2 -translate-x-1/2 font-inter text-white" style={{ fontSize: '13px', opacity: 0.8 }}>
            {lightbox + 1} / {photos.length}
          </span>
        </div>
      )}
    </>
  );
}