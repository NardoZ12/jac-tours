import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority";

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-semibold font-poppins transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-roam-coral/40 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.97] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-roam-coral text-white shadow-roam-soft hover:bg-[#571AFF] hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]",
        destructive:
          "bg-destructive text-destructive-foreground shadow-roam-soft hover:bg-[#571AFF] hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]",
        outline:
          "border border-roam-border bg-white text-roam-text shadow-roam-soft hover:border-[#571AFF] hover:bg-[#571AFF] hover:text-white hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]",
        secondary:
          "bg-roam-peach text-roam-text hover:bg-[#571AFF] hover:text-white hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]",
        ghost: "text-roam-text hover:bg-[#571AFF] hover:text-white hover:shadow-[0_12px_28px_rgba(87,26,255,0.28)]",
        link: "text-roam-coral underline-offset-4 hover:underline rounded-none",
      },
      size: {
        default: "h-10 px-5 py-2",
        sm: "h-8 px-3 text-xs",
        lg: "h-12 px-8 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"
  return (
    (<Comp
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      {...props} />)
  );
})
Button.displayName = "Button"

export { Button, buttonVariants }