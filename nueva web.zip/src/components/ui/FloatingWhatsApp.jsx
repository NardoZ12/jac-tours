import { MessageCircle } from 'lucide-react';

const WHATSAPP = '18293026170';
const LINK = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent('Hola, quiero información sobre sus tours y traslados')}`;

export default function FloatingWhatsApp() {
  return (
    <a
      href={LINK}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Contactar por WhatsApp"
      className="fixed right-4 z-[30000] flex items-center justify-center rounded-full transition-transform hover:scale-110"
      style={{
        bottom: 'calc(80px + env(safe-area-inset-bottom, 0px))',
        width: '56px',
        height: '56px',
        background: '#25D366',
        boxShadow: '0 6px 20px rgba(37,211,102,0.45), 0 2px 8px rgba(14,14,14,0.18)',
      }}
    >
      <span className="absolute inset-0 rounded-full animate-ping" style={{ background: '#25D366', opacity: 0.35, animationDuration: '2s' }} />
      <MessageCircle size={28} color="#FFFFFF" className="relative z-10" />
    </a>
  );
}