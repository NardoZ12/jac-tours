import { useState } from 'react';
import { ShoppingCart, Check } from 'lucide-react';
import { useCart } from '@/lib/CartContext';

/**
 * Replaces the Heart (favorites) button on venue cards.
 * Adds the venue to the shopping cart with a default configuration.
 * Variants match HeartButton: "overlay" (on photos) and "ghost" (on light).
 */
export default function AddToCartButton({ venue, variant = 'overlay', size = 16, className = '' }) {
  const { items, addItem } = useCart();
  const inCart = items.some((i) => i.venueId === venue.id);
  const [justAdded, setJustAdded] = useState(false);

  const category = venue.category || 'do';
  const path = category === 'stay' ? `/stay/${venue.id}` : category === 'eat' ? `/place/${venue.id}` : `/do/${venue.id}`;

  const handle = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!venue?.id) return;
    const pricePerPerson = venue.price || 60;
    const groupSize = 2;
    addItem({
      key: `${venue.id}:regular`,
      venueId: venue.id,
      venueName: venue.name,
      cover_image_url: venue.cover_image_url,
      category,
      tier: 'regular',
      tierLabel: 'Regular',
      groupSize,
      pricePerPerson,
      total: pricePerPerson * groupSize,
      path,
      sub_category: venue.sub_category,
      duration: venue.duration,
    });
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1200);
  };

  const isOverlay = variant === 'overlay';
  const bg = isOverlay ? 'rgba(0,0,0,0.45)' : '#FFFFFF';
  const iconColor = isOverlay ? 'white' : '#141413';

  return (
    <button
      type="button"
      onClick={handle}
      aria-label={inCart ? 'En el carrito' : 'Agregar al carrito'}
      className={`relative z-20 w-9 h-9 flex items-center justify-center rounded-full press-shrink ${className}`}
      style={{ background: bg, backdropFilter: isOverlay ? 'blur(6px)' : undefined, boxShadow: isOverlay ? undefined : '0 1px 4px rgba(20,20,19,0.08)' }}
    >
      {justAdded ? <Check size={size} color="#B6F02D" /> : <ShoppingCart size={size} color={iconColor} fill={inCart && !isOverlay ? '#141413' : 'none'} />}
    </button>
  );
}