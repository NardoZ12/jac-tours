import { useState } from 'react';
import { X } from 'lucide-react';
import ConfettiEffect from '../ui/ConfettiEffect';
import BookingConfirmation from '../booking/BookingConfirmation';
import { incrementSlotBooking, labelToIso } from '@/lib/timeslots';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';

const DIETARY = ['Vegetarian','Vegan','Gluten-free','Halal','Kosher','Dairy-free','Nut-free'];

function genCode() {
  return 'R' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

export default function BookingSheet({ venue, selectedTime, selectedDate, partySize, onClose }) {
  const [step, setStep] = useState(0);
  const [requests, setRequests] = useState('');
  const [dietary, setDietary] = useState([]);
  const [loading, setLoading] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const [code, setCode] = useState('');
  const [bookingId, setBookingId] = useState(null);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const confirm = async () => {
    setLoading(true);
    setError(null);
    const confirmationCode = genCode();
    const isoDate = labelToIso(selectedDate);
    try {
      await incrementSlotBooking(venue.id, isoDate, selectedTime || '20:00');
      setCode(confirmationCode);
      setBookingId(null);
      setConfetti(true);
      setTimeout(() => setSuccess(true), 500);
    } catch (e) {
      setError(e?.message || 'Could not complete booking. Please try again.');
    }
    setLoading(false);
  };

  const toggleDietary = (d) => setDietary(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d]);

  return (
    <>
      <ConfettiEffect active={confetti} />
      <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-4 flex-shrink-0">
          <div className="w-8 h-1 rounded-full" style={{ background: '#E8E6DC' }} />
        </div>

        <div className="px-5 overflow-y-auto flex-1" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 32px)' }}>
          {/* Close */}
          <button onClick={onClose} className="absolute top-4 right-5 w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>
            <X size={16} color="#141413" />
          </button>

          {success ? (
            <BookingConfirmation
              booking={{
                confirmationCode: code,
                bookingId,
                venue,
                type: 'eat',
                dateLabel: selectedDate || 'Today',
                timeLabel: selectedTime || '20:00',
                partyLabel: `${partySize || 2} ${(partySize || 2) > 1 ? 'guests' : 'guest'}`,
                note: requests || null,
              }}
              onClose={onClose}
            />
          ) : step === 0 ? (
            /* Step 1 */
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Confirming your table</h2>
              <div className="rounded-2xl p-4 mb-6" style={{ background: '#F0EFE9' }}>
                <div className="space-y-2">
                  {[
                    ['Venue', venue.name],
                    ['Date', selectedDate || 'Today'],
                    ['Time', selectedTime || '20:00'],
                    ['Guests', `${partySize || 2} persons`],
                  ].map(([l, v]) => (
                    <div key={l} className="flex items-center justify-between">
                      <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{l}</span>
                      <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
              <button onClick={() => setStep(1)} className="btn-primary">
                Continue →
              </button>
            </>
          ) : step === 1 ? (
            /* Step 2 */
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Your details</h2>
              <div className="space-y-4 mb-4">
                <div>
                  <label className="block font-inter font-medium mb-1.5" style={{ fontSize: '13px', color: '#72706A' }}>Special requests</label>
                  <textarea
                    value={requests}
                    onChange={e => setRequests(e.target.value)}
                    placeholder="Occasion, seating preference..."
                    rows={3}
                    className="w-full font-inter outline-none resize-none"
                    style={{ background: '#FFF', border: '1.5px solid #E8E6DC', borderRadius: '12px', padding: '12px 16px', fontSize: '14px' }}
                  />
                </div>
                <div>
                  <label className="block font-inter font-medium mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Dietary restrictions</label>
                  <div className="flex flex-wrap gap-2">
                    {DIETARY.map(d => (
                      <button key={d} onClick={() => toggleDietary(d)} className="font-poppins font-semibold" style={{
                        fontSize: '12px', padding: '6px 14px', borderRadius: '99px',
                        background: dietary.includes(d) ? '#1F1B2E' : '#FFF1EC',
                        color: dietary.includes(d) ? '#FFF' : '#72706A',
                      }}>{d}</button>
                    ))}
                  </div>
                </div>
              </div>
              <button onClick={() => setStep(2)} className="btn-primary">
                Continue →
              </button>
            </>
          ) : (
            /* Step 3 */
            <>
              <h2 className="font-poppins font-bold mb-4" style={{ fontSize: '20px', color: '#141413' }}>Confirm your booking</h2>
              <div className="rounded-2xl p-4 mb-4" style={{ background: '#F0EFE9' }}>
                <div className="space-y-2">
                  {[
                    ['Venue', venue.name],
                    ['Date', selectedDate || 'Today'],
                    ['Time', selectedTime || '20:00'],
                    ['Guests', `${partySize || 2} persons`],
                  ].map(([l, v]) => (
                    <div key={l} className="flex items-center justify-between">
                      <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{l}</span>
                      <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
              <p className="font-inter mb-4 text-center" style={{ fontSize: '12px', color: '#72706A' }}>
                ✓ Free cancellation up to 24h before
              </p>
              {error && (
                <p className="font-inter mb-2 text-center" style={{ fontSize: '12px', color: '#DC2626' }}>{error}</p>
              )}
              <button
                onClick={confirm}
                disabled={loading}
                className="btn-primary"
              >
                {loading ? 'Booking...' : 'Confirm booking'}
              </button>
              <p className="font-inter text-center mt-2 flex items-center justify-center gap-1" style={{ fontSize: '12px', color: '#72706A' }}>
                🔒 100% free cancellation
              </p>
            </>
          )}
        </div>
      </ResponsiveSheetShell>
    </>
  );
}