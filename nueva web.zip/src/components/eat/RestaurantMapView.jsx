import { useNavigate } from 'react-router-dom';
import DiscoverMap from '@/components/discover/DiscoverMap';

const FALLBACK_POINTS = [
  [48.3687, 10.8979],
  [48.3645, 10.8990],
  [48.3698, 10.9075],
  [48.3658, 10.9021],
  [48.3679, 10.8953],
  [48.3651, 10.9046],
  [48.3712, 10.8941],
  [48.3636, 10.8994],
  [48.3701, 10.9187],
  [48.3628, 10.8896],
  [48.3748, 10.8829],
  [48.3792, 10.9145],
];

export default function RestaurantMapView({ restaurants = [], loading = false, category = 'eat', label = 'restaurants', pathPrefix = '/place' }) {
  const navigate = useNavigate();
  const mapRestaurants = restaurants.map((restaurant, index) => {
    if (restaurant.lat && restaurant.lng) return { ...restaurant, category: restaurant.category || category };
    const [lat, lng] = FALLBACK_POINTS[index % FALLBACK_POINTS.length];
    const offset = Math.floor(index / FALLBACK_POINTS.length) * 0.00035;
    return { ...restaurant, category: restaurant.category || category, lat: lat + offset, lng: lng + offset };
  });

  return (
    <section className="px-5 md:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="activity-map-frame overflow-hidden rounded-[32px] border border-white/70 bg-white shadow-[0_18px_44px_rgba(14,14,14,0.10)]">
          {loading ? <div className="activity-map-skeleton skeleton" style={{ height: '620px' }} /> : <DiscoverMap events={[]} places={mapRestaurants} people={[]} showEvents={false} showPlaces showPeople={false} onSelectPlace={(place) => navigate(`${pathPrefix}/${place.id}`)} />}
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 font-inter text-xs text-[#72706A]">
          <span className="rounded-full bg-white px-3 py-2">Augsburg center</span>
          <span className="rounded-full bg-white px-3 py-2">{mapRestaurants.length} {label}</span>
          <span className="rounded-full bg-white px-3 py-2">€ pricing</span>
        </div>
      </div>
    </section>
  );
}