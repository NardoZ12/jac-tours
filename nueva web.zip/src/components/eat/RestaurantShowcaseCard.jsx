import { Link } from 'react-router-dom';
import { MapPin, Star } from 'lucide-react';
import PriceRange from '@/components/ui/PriceRange';
import AddToCartButton from '@/components/ui/AddToCartButton';

export default function RestaurantShowcaseCard({ venue, frameless = false }) {
  const cardVenue = { ...venue, category: venue.category || 'eat' };
  const path = `/place/${venue.id}`;
  const CardShell = ({ children }) => <Link to={path} state={{ venue: cardVenue }} className="flex h-full flex-col">{children}</Link>;

  return (
    <article className="group h-full overflow-hidden rounded-[28px] bg-white" style={{ border: frameless ? '0' : '1px solid rgba(14,14,14,0.08)', boxShadow: frameless ? 'none' : '0 18px 44px rgba(14,14,14,0.08)' }}>
      <CardShell>
        <div className="relative h-[372px] flex-shrink-0 overflow-hidden bg-roam-surface2">
          <img src={venue.cover_image_url} alt={venue.name} className={`h-full w-full object-cover ${frameless ? '' : 'transition-transform duration-1000 ease-out group-hover:scale-105'}`} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/[0.66] via-black/10 to-transparent" />
          <div className="absolute left-4 top-4 rounded-full px-3 py-1.5 text-[12px] font-semibold uppercase tracking-[0.14em] text-white hidden" style={{ background: 'rgba(255,255,255,0.14)', border: '1px solid rgba(255,255,255,0.22)', backdropFilter: 'blur(14px)' }}>
            {venue.is_demo ? 'Concept' : 'Eat'}
          </div>
          <div className="absolute left-4 top-4 z-10"><AddToCartButton venue={cardVenue} /></div>
          <div className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-white px-2.5 py-1.5 text-roam-text">
            <Star size={13} fill="#0E0E0E" />
            <span className="font-inter text-xs font-bold">{venue.avg_rating?.toFixed(1)}</span>
          </div>
          <div className="absolute bottom-4 left-4 right-4 text-white">
            <p className="mb-1 font-inter text-xs text-white/75">{venue.sub_category}</p>
            <h3 className="w-full text-[28px] leading-none tracking-[-0.04em] [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]">{venue.name}</h3>
          </div>
        </div>
        <div className="relative flex min-h-[190px] flex-1 flex-col p-5">
          <div className="mb-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 font-inter text-sm text-roam-muted">
              <MapPin size={15} />
              <span>{venue.neighborhood}</span>
            </div>
            <PriceRange value={venue.price_range || 2} />
          </div>
          <p className="font-inter text-sm leading-6 text-roam-secondary transition-all duration-500 ease-out md:group-hover:-translate-y-4 md:group-hover:opacity-0">{venue.short_description}</p>
          <div className="mt-auto flex flex-wrap gap-2 transition-transform duration-500 ease-out md:group-hover:-translate-y-14">
            {(venue.cuisine_tags || []).slice(0, 3).map((tag) =>
            <span key={tag} className="rounded-full px-3 py-1.5 font-inter text-xs font-semibold" style={{ background: '#F2F1EE', color: '#3A3A3A' }}>{tag}</span>
            )}
          </div>
          <div className="absolute bottom-5 left-5 right-5 translate-y-0 opacity-100 md:translate-y-5 md:opacity-0 transition-all duration-500 ease-out md:group-hover:translate-y-0 md:group-hover:opacity-100">
            <span className="inline-flex h-11 w-full items-center justify-center rounded-full font-inter text-sm font-semibold text-white" style={{ background: '#571AFF', boxShadow: frameless ? 'none' : '0 12px 28px rgba(87,26,255,0.28)' }}>
              Learn More
            </span>
          </div>
        </div>
      </CardShell>
    </article>);

}