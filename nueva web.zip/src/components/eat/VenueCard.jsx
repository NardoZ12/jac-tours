import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import RatingStars from '../ui/RatingStars';
import PriceRange from '../ui/PriceRange';
import VenuePhoto from '../ui/VenuePhoto';
import HeartButton from '../ui/HeartButton';
import { getSlotsForVenue, isSlotSoldOut, todayIso } from '@/lib/timeslots';

export default function VenueCard({ venue, showSlots = true }) {
  const [slots, setSlots] = useState([]);
  const path = `/place/${venue.id}`;

  useEffect(() => {
    if (showSlots && venue.category === 'restaurant') {
      getSlotsForVenue(venue.id, todayIso()).then(setSlots);
    }
  }, [venue.id, venue.category, showSlots]);

  const hasDeal = venue._deal;
  const availableSlots = slots.filter(s => !isSlotSoldOut(s)).slice(0, 4);

  return (
    <div className="rounded-2xl overflow-hidden card-shadow bg-white">
      <Link to={path}>
        <VenuePhoto venue={venue} height={200} rounded="0">
          {/* Category badge top-left */}
          <div className="absolute top-3 left-3 flex gap-2 z-10">
            <span className="font-poppins font-semibold text-white" style={{ fontSize: '12px', letterSpacing: '0.06em', textTransform: 'uppercase', background: 'rgba(0,0,0,0.55)', padding: '4px 10px', borderRadius: '8px' }}>
              {venue.category === 'hotel' ? 'STAY' : venue.category === 'experience' ? 'DO' : 'EAT'}
            </span>
          </div>

          {/* Rating badge top-right */}
          {venue.avg_rating && (
            <div className="absolute top-3 right-3 z-10 flex items-center gap-1 bg-white" style={{ padding: '4px 8px', borderRadius: '8px' }}>
              <span style={{ color: '#0E0E0E', fontSize: '12px' }}>★</span>
              <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#141413' }}>{venue.avg_rating.toFixed(1)}</span>
            </div>
          )}

          {/* Save button bottom-right */}
          <div className="absolute bottom-3 right-3 z-10">
            <HeartButton venue={venue} />
          </div>

          {/* Cuisine on photo bottom-left */}
          {venue.cuisine_tags?.[0] && (
            <div className="absolute bottom-3 left-3 z-10">
              <span className="font-poppins font-semibold text-white" style={{ fontSize: '12px', textShadow: '0 1px 4px rgba(0,0,0,0.6)' }}>
                {venue.cuisine_tags[0]} · {venue.neighborhood}
              </span>
            </div>
          )}
        </VenuePhoto>
      </Link>

      {/* Content */}
      <div className="px-3.5 pt-3 pb-3">
        <Link to={path} className="flex items-start justify-between">
          <h3 className="font-poppins font-semibold flex-1" style={{ fontSize: '16px', color: '#141413' }}>{venue.name}</h3>
          <PriceRange value={venue.price_range || 2} />
        </Link>

        {/* Time slots / waitlist */}
        {showSlots && venue.category === 'restaurant' && (
          <div className="flex gap-2 mt-2.5 flex-wrap">
            {availableSlots.length > 0 ? (
              availableSlots.map(s => (
                <Link
                  key={s.id}
                  to={`/eat/${venue.id}?time=${s.time}&date=${s.date}`}
                  className="font-poppins font-semibold"
                  style={{
                    fontSize: '12px', padding: '5px 11px', borderRadius: '8px',
                    background: '#F0EFE9', color: '#141413',
                  }}
                >
                  {s.time}
                </Link>
              ))
            ) : (
              <Link to={path} className="font-poppins font-semibold" style={{ fontSize: '12px', color: '#888580' }}>
                Join waitlist →
              </Link>
            )}
          </div>
        )}

        {/* Flash deal banner */}
        {hasDeal && (
          <div className="mt-2.5 -mx-3.5 px-3.5 py-2" style={{ background: '#0E0E0E' }}>
            <p className="font-poppins font-semibold text-white" style={{ fontSize: '12px' }}>
              {venue._deal.discount_value}% off · Limited time
            </p>
          </div>
        )}
      </div>
    </div>
  );
}