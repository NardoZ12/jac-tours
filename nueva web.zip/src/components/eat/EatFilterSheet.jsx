import { useState } from 'react';
import { X, Check } from 'lucide-react';
import ResponsiveSheetShell from '@/components/ui/ResponsiveSheetShell';

const PRICES = [
  { value: 1, label: '€' },
  { value: 2, label: '€€' },
  { value: 3, label: '€€€' },
  { value: 4, label: '€€€€' },
];

const SORTS = [
  { value: 'rating', label: 'Top rated' },
  { value: 'trending', label: 'Trending' },
  { value: 'price_low', label: 'Price: low to high' },
  { value: 'price_high', label: 'Price: high to low' },
];

const CONFIG = {
  eat: {
    title: 'Restaurant filters',
    quickTitle: 'Show me',
    quick: ['Open now', 'With deals'],
    priceTitle: 'Price range',
    primaryTitle: 'Cuisine',
    primary: ['Italian', 'Japanese', 'Israeli', 'Mediterranean', 'Vegan', 'Asian', 'American', 'French'],
    secondaryTitle: 'Vibe',
    secondary: ['Romantic', 'Casual', 'Outdoor', 'Trendy', 'Family-friendly', 'Quiet', 'Lively', 'Date night'],
  },
  stay: {
    title: 'Hotel filters',
    quickTitle: 'Show me',
    quick: ['Available tonight', 'Best value'],
    priceTitle: 'Nightly budget',
    primaryTitle: 'Stay type',
    primary: ['Boutique', '5-star', 'Design Hotel', 'Spa Hotel', 'Quiet Stay', 'Historic Rooms'],
    secondaryTitle: 'Amenities & vibe',
    secondary: ['With pool', 'Breakfast', 'Rooftop', 'Romantic', 'Old Town', 'Waterside'],
  },
  do: {
    title: 'Experience filters',
    quickTitle: 'Show me',
    quick: ['Available today', 'Low cost'],
    priceTitle: 'Budget',
    primaryTitle: 'Experience type',
    primary: ['Sights', 'Tours', 'Culture', 'Outdoor', 'Museums', 'Nightlife', 'Workshops', 'Family'],
    secondaryTitle: 'Mood & format',
    secondary: ['Historic', 'Guided', 'Local', 'Calm', 'Hands-on', 'Social', 'Art', 'Food'],
  },
  map: {
    title: 'Map filters',
    quickTitle: 'Show me',
    quick: ['Bookable only', 'Low cost'],
    priceTitle: 'Price range',
    primaryTitle: 'Place type',
    primary: ['Restaurants', 'Hotels', 'Sights'],
    secondaryTitle: 'Mood & format',
    secondary: ['Romantic', 'Outdoor', 'Luxury', 'Quiet', 'History', 'Music', 'Creative', 'Rooftop'],
  },
};

const EMPTY = { cuisines: [], vibes: [], prices: [], openNow: false, withDeals: false, sort: 'rating' };

export default function EatFilterSheet({ initial, onApply, onClose, category = 'eat' }) {
  const config = CONFIG[category] || CONFIG.eat;
  const [state, setState] = useState({ ...EMPTY, ...(initial || {}) });

  const toggle = (key, value) => {
    setState((s) => {
      const arr = s[key] || [];
      return { ...s, [key]: arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value] };
    });
  };

  const count = state.cuisines.length + state.vibes.length + state.prices.length + (state.openNow ? 1 : 0) + (state.withDeals ? 1 : 0);

  return (
    <ResponsiveSheetShell onClose={onClose} zIndex={30000}>
      <div className="flex flex-shrink-0 justify-center pb-2 pt-3 lg:hidden">
        <div className="h-1 w-10 rounded-full" style={{ background: '#E8E6DC' }} />
      </div>

      <div className="flex flex-shrink-0 items-center justify-between px-5 pb-4 pt-2" style={{ borderBottom: '1px solid #F0EFE9' }}>
        <button type="button" onClick={() => setState(EMPTY)} className="rounded-full px-3 py-2 font-inter text-sm transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#F2F1EE] hover:text-[#141413] hover:shadow-[0_8px_18px_rgba(14,14,14,0.08)]" style={{ color: '#72706A' }}>
          Reset
        </button>
        <h2 className="font-bold [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]" style={{ fontSize: '17px', color: '#141413' }}>{config.title}</h2>
        <button type="button" aria-label="Close filters" onClick={onClose} className="flex h-9 w-9 items-center justify-center rounded-full bg-[#F0EFE9] text-[#141413] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#141413] hover:text-white hover:shadow-[0_10px_22px_rgba(14,14,14,0.16)]">
          <X size={16} color="currentColor" />
        </button>
      </div>

      <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">
        <Section title={config.quickTitle}>
          <div className="flex flex-wrap gap-2">
            <ToggleChip active={state.openNow} onClick={() => setState((s) => ({ ...s, openNow: !s.openNow }))}>{config.quick[0]}</ToggleChip>
            <ToggleChip active={state.withDeals} onClick={() => setState((s) => ({ ...s, withDeals: !s.withDeals }))}>{config.quick[1]}</ToggleChip>
          </div>
        </Section>

        <Section title={config.priceTitle}>
          <div className="flex gap-2">
            {PRICES.map((p) => (
              <ToggleChip key={p.value} active={state.prices.includes(p.value)} onClick={() => toggle('prices', p.value)}>{p.label}</ToggleChip>
            ))}
          </div>
        </Section>

        <Section title={config.primaryTitle}>
          <div className="flex flex-wrap gap-2">
            {config.primary.map((item) => (
              <ToggleChip key={item} active={state.cuisines.includes(item)} onClick={() => toggle('cuisines', item)}>{item}</ToggleChip>
            ))}
          </div>
        </Section>

        <Section title={config.secondaryTitle}>
          <div className="flex flex-wrap gap-2">
            {config.secondary.map((item) => (
              <ToggleChip key={item} active={state.vibes.includes(item)} onClick={() => toggle('vibes', item)}>{item}</ToggleChip>
            ))}
          </div>
        </Section>

        <Section title="Sort by">
          <div className="space-y-1">
            {SORTS.map((sort) => (
              <button type="button" key={sort.value} onClick={() => setState((prev) => ({ ...prev, sort: sort.value }))} className="flex w-full items-center justify-between rounded-2xl px-3 py-2.5 transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#F7F4FF] hover:shadow-[0_8px_18px_rgba(87,26,255,0.10)]">
                <span className="font-inter text-sm" style={{ color: '#141413' }}>{sort.label}</span>
                {state.sort === sort.value && <Check size={16} color="#571AFF" />}
              </button>
            ))}
          </div>
        </Section>
      </div>

      <div className="flex-shrink-0 px-5 py-4" style={{ borderTop: '1px solid #F0EFE9', background: '#FFFFFF' }}>
        <button type="button" onClick={() => { onApply(state); onClose(); }} className="w-full rounded-full bg-[#571AFF] font-inter text-[15px] font-semibold text-white transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#0E0E0E] hover:shadow-[0_12px_28px_rgba(14,14,14,0.28)]" style={{ height: '50px' }}>
          Show results{count > 0 ? ` · ${count} filter${count > 1 ? 's' : ''}` : ''}
        </button>
      </div>
    </ResponsiveSheetShell>
  );
}

function Section({ title, children }) {
  return (
    <div>
      <p className="mb-3 font-semibold [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]" style={{ fontSize: '14px', color: '#141413' }}>{title}</p>
      {children}
    </div>
  );
}

function ToggleChip({ active, onClick, children }) {
  return (
    <button type="button" onClick={onClick} className={`rounded-full px-4 py-2.5 font-semibold transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-[0_10px_20px_rgba(87,26,255,0.14)] [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif] ${active ? 'bg-[#571AFF] text-white hover:bg-[#0E0E0E]' : 'bg-white text-[#141413] hover:border-[#571AFF] hover:bg-[#F7F4FF]'}`} style={{ fontSize: '13px', border: active ? '1.5px solid #571AFF' : '1.5px solid #E8E6DC' }}>
      {children}
    </button>
  );
}