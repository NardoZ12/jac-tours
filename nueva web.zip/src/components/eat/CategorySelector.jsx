import { useNavigate, useLocation } from 'react-router-dom';
import { UtensilsCrossed, BedDouble, Compass, Heart, Sparkles, Newspaper } from 'lucide-react';

const CATEGORIES = [
  { key: 'highlights', label: 'Highlights', icon: Sparkles, path: '/' },
  { key: 'eat', label: 'Eat', icon: UtensilsCrossed, path: '/eat' },
  { key: 'stay', label: 'Stay', icon: BedDouble, path: '/stay' },
  { key: 'do', label: 'Do', icon: Compass, path: '/do' },
  { key: 'favourites', label: 'Favourites', icon: Heart, path: '/favourites' },
  { key: 'blog', label: 'Blog', icon: Newspaper, path: '/blog' },
];

export default function CategorySelector({ active = 'eat' }) {
  const navigate = useNavigate();
  const location = useLocation();

  const currentKey = CATEGORIES.find(c => c.path === location.pathname)?.key || active;

  return (
    <div className="mx-auto max-w-md px-5">
      <div
        className="grid grid-cols-3 gap-2 rounded-3xl bg-white p-3 shadow-[0_8px_28px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.9)]"
        style={{ border: '1px solid rgba(14,14,14,0.06)' }}
      >
        {CATEGORIES.map(({ key, label, icon: Icon, path }) => {
          const isActive = currentKey === key;
          return (
            <button
              key={key}
              onClick={() => navigate(path)}
              className="flex flex-col items-center justify-center gap-1.5 rounded-2xl py-3 transition-all duration-200"
              style={{
                background: isActive ? '#5c2eff' : 'transparent',
                color: isActive ? '#FFFFFF' : '#000000',
                boxShadow: isActive ? '0 8px 22px rgba(92,46,255,0.35)' : 'none',
              }}
            >
              <Icon size={22} color={isActive ? '#FFFFFF' : '#000000'} strokeWidth={1.8} />
              <span className="font-inter text-[12px] font-medium tracking-tight">{label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}