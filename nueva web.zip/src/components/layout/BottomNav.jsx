import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, User } from 'lucide-react';

// Wander: ink black active, warm gray inactive
const ACTIVE = '#0E0E0E';
const INACTIVE_TEXT = 'rgba(14, 14, 14, 0.4)';
const LOGO_URL = 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/872b6c8a4_3.png';

const tabs = [
  { id: 'today', label: 'Inicio', path: '/' },
  { id: 'do', label: 'Tours', path: '/do' },
  { id: 'traslado', label: 'Traslado', path: '/traslado' },
  { id: 'yates', label: 'Yates', path: '/yates' },
  { id: 'favorites', label: 'Carrito', path: '/cart' },
  { id: 'profile', label: 'Perfil', path: '/profile' },
];

export default function BottomNav() {
  const location = useLocation();
  const [logoRotation, setLogoRotation] = useState(0);

  useEffect(() => {
    let frame = null;

    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        setLogoRotation(window.scrollY * 0.09);
        frame = null;
      });
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header className="tab-bar">
      <nav className="flex items-center justify-between w-full px-4 h-12" aria-label="Main navigation">
        <Link to="/" className="flex items-center press-shrink flex-shrink-0" aria-label="Jac Tour and Transfers">
          <img src={LOGO_URL} alt="Jac Tour and Transfers" className="h-7 w-7 rounded-md" style={{ display: 'block' }} />
        </Link>

        <div className="flex items-center justify-center gap-3 min-w-0 mr-2">
          {tabs.filter((tab) => !['favorites', 'profile'].includes(tab.id)).map((tab) => {
            const active = isActive(tab.path);
            return (
              <Link
                key={tab.id}
                to={tab.path}
                aria-label={tab.label}
                className="flex items-center justify-center h-full relative press-shrink"
              >
                <span
                  className="font-poppins transition-colors duration-200"
                  style={{
                    fontSize: '12px',
                    fontWeight: active ? 700 : 500,
                    letterSpacing: '0.01em',
                    color: active ? ACTIVE : INACTIVE_TEXT,
                  }}
                >
                  {tab.label}
                </span>
              </Link>
            );
          })}
        </div>

        <div className="flex items-center justify-end gap-2 flex-shrink-0">
          {tabs.filter((tab) => ['favorites', 'profile'].includes(tab.id)).map((tab) => {
            const active = isActive(tab.path);
            const Icon = tab.id === 'favorites' ? ShoppingCart : User;
            return (
              <Link
                key={tab.id}
                to={tab.path}
                aria-label={tab.label}
                className="flex items-center justify-center h-full relative press-shrink"
              >
                <Icon
                  size={18}
                  strokeWidth={active ? 2.4 : 2}
                  style={{
                    color: active ? ACTIVE : INACTIVE_TEXT,
                    transition: 'all 200ms cubic-bezier(0.22, 1, 0.36, 1)',
                  }}
                />
              </Link>
            );
          })}
        </div>
      </nav>
    </header>
  );
}