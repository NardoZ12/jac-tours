import { Link } from 'react-router-dom';
import { MapPin, MessageCircle, Instagram, Star, Landmark, Mail } from 'lucide-react';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion';

const WHATSAPP = '18293026170';
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent('Hola, quiero información sobre sus tours y traslados')}`;

const FAQS = [
  { q: '¿Cómo reservo un tour o traslado?', a: 'Puedes reservar directamente desde la página de cada tour o traslado, o escribirnos por WhatsApp para recibir una cotización personalizada. Te confirmamos disponibilidad y detalles en minutos.' },
  { q: '¿El precio incluye transporte ida y vuelta?', a: 'Sí. Todos nuestros tours incluyen transporte ida y vuelta desde tu hotel o punto de encuentro en Punta Cana y Bávaro, salvo que se indique lo contrario.' },
  { q: '¿Qué métodos de pago aceptan?', a: 'Aceptamos PayPal, tarjetas de crédito/débito y pago en efectivo al conductor. Para reservas online se requiere un depósito del 30% y el resto se paga el día del servicio.' },
  { q: '¿Puedo cancelar o modificar mi reserva?', a: 'Sí. Las cancelaciones con más de 48 horas de anticipación tienen reembolso completo. Para modificaciones de fecha, contáctanos por WhatsApp y lo gestionamos sin costo.' },
  { q: '¿Qué pasa si llueve el día del tour?', a: 'La mayoría de los tours operan con lluvia ligera. Si el clima impide realizar la actividad de forma segura, te ofrecemos reprogramar o un reembolso completo.' },
  { q: '¿Hacen traslados desde el aeropuerto (PUJ)?', a: 'Sí. Realizamos traslados privados desde y hacia el Aeropuerto Internacional de Punta Cana (PUJ) hacia cualquier hotel o destino de la región. Calcula tu tarifa en la sección de Traslados.' },
  { q: '¿Puedo reservar para grupos grandes?', a: 'Por supuesto. Contamos con vehículos desde 1 hasta 49 personas (Starex, Hiace, Coaster y Universe). Escríbenos para grupos y obten un precio especial.' },
];

export default function SiteFooter() {
  return (
    <footer className="relative" style={{ background: '#121623', color: '#E8E6DC' }}>
      <div className="mx-auto max-w-6xl px-5 py-14">
        {/* Quiénes somos + Ministerio */}
        <div className="grid gap-8 md:grid-cols-[1.4fr_1fr]">
          <div>
            <h3 className="font-poppins" style={{ fontSize: '22px', color: '#FFFFFF', letterSpacing: '-0.02em' }}>Jac Tour and Transfers</h3>
            <p className="font-inter mt-3" style={{ fontSize: '13px', lineHeight: 1.7, color: '#A8A6A0' }}>
              Somos una operadora de tours y traslados en Punta Cana, República Dominicana. Con más de 10 años de experiencia,
              ofrecemos excursiones a las mejores islas y destinos del país, traslados privados seguros y experiencias
              auténticas con guías locales bilingües. Operador turístico autorizado por el Ministerio de Turismo.
            </p>
            <div className="mt-5 flex items-center gap-3">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"
                className="flex items-center justify-center rounded-full transition-transform hover:scale-110"
                style={{ width: '42px', height: '42px', background: '#25D366' }}>
                <MessageCircle size={20} color="#FFFFFF" />
              </a>
              <a href="https://www.instagram.com/jac.tours/" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                className="flex items-center justify-center rounded-full transition-transform hover:scale-110"
                style={{ width: '42px', height: '42px', background: '#E1306C' }}>
                <Instagram size={20} color="#FFFFFF" />
              </a>
              <a href="https://www.tripadvisor.es/Attraction_Review-g147293-d33956057-Reviews-JAC_Tours_Punta_Cana-Punta_Cana_La_Altagracia_Province_Dominican_Republic.html"
                target="_blank" rel="noopener noreferrer" aria-label="Tripadvisor"
                className="flex items-center justify-center rounded-full transition-transform hover:scale-110"
                style={{ width: '42px', height: '42px', background: '#00AA6C' }}>
                <Star size={20} color="#FFFFFF" />
              </a>
            </div>
          </div>

          {/* Ministerio de Turismo — badge placeholder */}
          <div className="flex items-center justify-start md:justify-end">
            <div className="flex items-center gap-3 rounded-2xl px-4 py-3" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}>
              <Landmark size={28} color="#FFFFFF" />
              <div>
                <p className="font-inter font-semibold" style={{ fontSize: '12px', color: '#FFFFFF' }}>Ministerio de Turismo</p>
                <p className="font-inter" style={{ fontSize: '10px', color: '#A8A6A0' }}>República Dominicana · Operador autorizado</p>
              </div>
            </div>
          </div>
        </div>

        {/* Contacto + Ubicación + Documentación */}
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          <div>
            <h4 className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#FFFFFF' }}>Contacto</h4>
            <ul className="mt-3 space-y-2.5 font-inter" style={{ fontSize: '13px' }}>
              <li>
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 transition-colors hover:text-white" style={{ color: '#A8A6A0' }}>
                  <MessageCircle size={15} color="#25D366" /> WhatsApp: +1 (829) 302-6170
                </a>
              </li>
              <li className="flex items-center gap-2" style={{ color: '#A8A6A0' }}>
                <Mail size={15} color="#A8A6A0" /> info@jactours.com.do
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#FFFFFF' }}>Ubicación</h4>
            <p className="mt-3 flex items-start gap-2 font-inter" style={{ fontSize: '13px', color: '#A8A6A0', lineHeight: 1.6 }}>
              <MapPin size={15} color="#571AFF" className="mt-0.5 shrink-0" />
              Bávaro, Punta Cana<br />La Altagracia, República Dominicana
            </p>
          </div>

          <div>
            <h4 className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#FFFFFF' }}>Documentación</h4>
            <ul className="mt-3 space-y-2 font-inter" style={{ fontSize: '13px' }}>
              <li><Link to="/privacy-policy" className="transition-colors hover:text-white" style={{ color: '#A8A6A0' }}>Política de privacidad</Link></li>
              <li><Link to="/terms" className="transition-colors hover:text-white" style={{ color: '#A8A6A0' }}>Términos y condiciones</Link></li>
              <li><Link to="/accessibility-statement" className="transition-colors hover:text-white" style={{ color: '#A8A6A0' }}>Declaración de accesibilidad</Link></li>
            </ul>
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-12">
          <h4 className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#FFFFFF' }}>Preguntas frecuentes</h4>
          <Accordion type="single" collapsible className="mt-3">
            {FAQS.map((f, i) => (
              <AccordionItem key={i} value={`item-${i}`} style={{ borderColor: 'rgba(255,255,255,0.10)' }}>
                <AccordionTrigger className="font-inter font-medium" style={{ fontSize: '13px', color: '#FFFFFF' }}>
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="font-inter" style={{ fontSize: '12px', color: '#A8A6A0', lineHeight: 1.6 }}>
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 flex flex-col items-center gap-2 text-center md:flex-row md:justify-between md:text-left" style={{ borderTop: '1px solid rgba(255,255,255,0.10)' }}>
          <span className="font-inter" style={{ fontSize: '11px', color: '#72706A' }}>© 2026 Jac Tour and Transfers · Punta Cana, República Dominicana</span>
          <nav className="flex flex-wrap justify-center gap-x-4 gap-y-1.5 font-inter" style={{ fontSize: '11px' }}>
            <Link to="/privacy-policy" className="transition-colors hover:text-white" style={{ color: '#72706A' }}>Privacidad</Link>
            <Link to="/terms" className="transition-colors hover:text-white" style={{ color: '#72706A' }}>Términos</Link>
            <Link to="/accessibility-statement" className="transition-colors hover:text-white" style={{ color: '#72706A' }}>Accesibilidad</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}