import { useIsDesktop } from '@/hooks/useBreakpoint';
import AppLayout from './AppLayout';
import DesktopLayout from './DesktopLayout';

/**
 * Picks the right shell for the current viewport.
 * < 768px → mobile (bottom tab bar, 430px clamped)
 * ≥ 768px → desktop/tablet (top horizontal nav, full-width fluid)
 *
 * Both shells render the same nested <Route> tree via <Outlet />,
 * so page components and features are identical across breakpoints.
 */
export default function ResponsiveLayout() {
  const isDesktop = useIsDesktop();
  return isDesktop ? <DesktopLayout /> : <AppLayout />;
}