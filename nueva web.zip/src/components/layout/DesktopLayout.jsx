import { Outlet } from 'react-router-dom';
import TopNav from './TopNav';
import TodayFooter from '@/components/today/TodayFooter';
import SiteFooter from './SiteFooter';
import FloatingWhatsApp from '@/components/ui/FloatingWhatsApp';

/**
 * Desktop shell: floating pill nav overlaid on a hero background + full-width fluid content.
 */
export default function DesktopLayout() {
  return (
    <div className="min-h-screen relative" style={{ background: '#F8F7F4' }}>
      <TopNav />
      <main className="w-full">
        <Outlet />
        <TodayFooter />
        <SiteFooter />
      </main>
      <FloatingWhatsApp />
    </div>
  );
}