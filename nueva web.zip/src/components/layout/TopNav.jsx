import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Sun, Compass, ShoppingCart, Car, Sailboat, User } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const ACTIVE = '#0E0E0E';
const INACTIVE = '#555550';
const LOGO_URL = 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/872b6c8a4_3.png';

const links = [
{ id: 'today', label: 'Inicio', icon: Sun, path: '/' },
{ id: 'do', label: 'Tours', icon: Compass, path: '/do' },
{ id: 'traslado', label: 'Traslado', icon: Car, path: '/traslado' },
{ id: 'yates', label: 'Yates', icon: Sailboat, path: '/yates' }];


export default function TopNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [logoRotation, setLogoRotation] = useState(0);
  const [isHeaderHidden, setIsHeaderHidden] = useState(false);
  const [hoveredNav, setHoveredNav] = useState(null);
  const [hoveredAction, setHoveredAction] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    let frame = null;
    let lastScrollY = window.scrollY;

    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const currentScrollY = window.scrollY;
        const scrollingUp = currentScrollY < lastScrollY - 2;
        const distanceToBottom = document.documentElement.scrollHeight - (currentScrollY + window.innerHeight);
        const nearBottom = distanceToBottom <= 140;

        setLogoRotation(currentScrollY * 0.09);
        setIsHeaderHidden(nearBottom && !scrollingUp && currentScrollY > 40);
        if (scrollingUp) setIsHeaderHidden(false);

        lastScrollY = currentScrollY;
        frame = null;
      });
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const isActive = (path) =>
  path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  const initial = (user?.full_name || 'U').trim().charAt(0).toUpperCase();

  return (
    <header
      className="sticky top-0 left-0 right-0 z-[20000] flex justify-center px-6 pb-2"
      style={{
        paddingTop: '1vh',
        transform: isHeaderHidden ? 'translateY(-120%)' : 'translateY(0)',
        opacity: isHeaderHidden ? 0 : 1,
        pointerEvents: isHeaderHidden ? 'none' : 'auto',
        transition: 'transform 360ms cubic-bezier(0.22, 1, 0.36, 1), opacity 260ms ease'
      }}>
      <div
        className="flex items-center justify-between px-3 h-14 w-full"
        style={{
          maxWidth: '820px',
          background: '#FFFFFF',
          borderRadius: '999px',
          border: '1px solid #E8E6DC',
          boxShadow: '0 2px 12px rgba(14,14,14,0.08)'
        }}>
        
        {/* Brand */}
        <Link to="/" className="flex items-center press-shrink ml-1" aria-label="Jac Tour and Transfers">
          <img src={LOGO_URL} alt="Jac Tour and Transfers" className="h-9 w-9 rounded-lg" style={{ display: 'block' }} />
        </Link>

        {/* Primary nav */}
        <nav className="flex items-center gap-1">
          {links.map((l) => {
            const active = isActive(l.path);
            const hovered = hoveredNav === l.id;
            const Icon = l.icon;
            return (
              <Link
                key={l.id}
                to={l.path}
                onMouseEnter={() => setHoveredNav(l.id)}
                onMouseLeave={() => setHoveredNav(null)}
                className="flex items-center gap-2 px-4 py-2 rounded-full press-shrink"
                style={{
                  background: hovered ? '#E7F0FF' : active ? 'rgba(14,14,14,0.08)' : 'transparent',
                  color: active ? ACTIVE : INACTIVE,
                  boxShadow: hovered ? '0 10px 22px rgba(87,26,255,0.22)' : '0 0 0 rgba(0,0,0,0)',
                  transition: 'background 180ms ease, box-shadow 180ms ease, transform 180ms ease, color 180ms ease'
                }}>
                
                <Icon size={16} strokeWidth={active ? 2.4 : 2} />
                <span
                  className="[font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]"
                  style={{
                    fontSize: '13px',
                    fontWeight: active ? 700 : 500,
                    letterSpacing: '0.01em'
                  }}>
                  
                  {l.label}
                </span>
              </Link>);

          })}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/cart')}
            onMouseEnter={() => setHoveredAction('favorites')}
            onMouseLeave={() => setHoveredAction(null)}
            aria-label="Carrito"
            className="w-9 h-9 flex items-center justify-center rounded-full press-shrink"
            style={{ background: hoveredAction === 'favorites' ? '#571AFF' : 'rgba(14,14,14,0.07)', boxShadow: hoveredAction === 'favorites' ? '0 12px 28px rgba(87,26,255,0.28)' : '0 0 0 rgba(0,0,0,0)', transition: 'background 180ms ease, box-shadow 180ms ease' }}>
            
            <ShoppingCart size={17} color={hoveredAction === 'favorites' ? '#FFFFFF' : '#0E0E0E'} />
          </button>
          <button
            onClick={() => navigate('/profile')}
            onMouseEnter={() => setHoveredAction('profile')}
            onMouseLeave={() => setHoveredAction(null)}
            aria-label="Profile"
            className="w-9 h-9 flex items-center justify-center rounded-full press-shrink overflow-hidden"
            style={{ background: hoveredAction === 'profile' ? '#571AFF' : '#0E0E0E', boxShadow: hoveredAction === 'profile' ? '0 12px 28px rgba(87,26,255,0.28)' : '0 0 0 rgba(0,0,0,0)', transition: 'background 180ms ease, box-shadow 180ms ease' }}>
            
            {user?.avatar_url ?
            <img src={user.avatar_url} alt="" className="w-full h-full object-cover" /> :
            user ?
            <span className="font-bold text-white [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]" style={{ fontSize: '14px' }}>{initial}</span> :

            <User size={17} color="#FFFFFF" />
            }
          </button>
        </div>
      </div>
    </header>);

}