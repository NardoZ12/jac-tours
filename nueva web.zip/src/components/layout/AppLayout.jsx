import { Outlet } from 'react-router-dom';
import BottomNav from './BottomNav';
import TodayFooter from '@/components/today/TodayFooter';
import SiteFooter from './SiteFooter';
import FloatingWhatsApp from '@/components/ui/FloatingWhatsApp';

export default function AppLayout() {
  return (
    <div className="roam-app">
      <div className="pb-20">
        <Outlet />
        <TodayFooter />
        <SiteFooter />
      </div>
      <BottomNav />
      <FloatingWhatsApp />
    </div>
  );
}