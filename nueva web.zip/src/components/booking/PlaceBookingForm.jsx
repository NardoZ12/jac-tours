import { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, Check, ChevronDown, Clock } from 'lucide-react';

const fieldClass = 'mt-2 h-11 w-full rounded-2xl border border-[#DDDBD5] bg-white px-4 text-sm text-roam-text outline-none transition-all duration-200 hover:border-[#571AFF] hover:shadow-[0_8px_22px_rgba(87,26,255,0.10)] focus:border-[#571AFF] focus:shadow-[0_8px_22px_rgba(87,26,255,0.14)]';

function formatDateLabel(date) {
  return date.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short' });
}

function formatIsoDateLabel(value) {
  return formatDateLabel(new Date(`${value}T00:00:00`));
}

function DateTimePickerField({ label, name, value, onChange, type }) {
  const [open, setOpen] = useState(false);
  const pickerRef = useRef(null);
  const isDate = type === 'date';
  const toIsoDate = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const today = useMemo(() => {
    const date = new Date();
    date.setHours(0, 0, 0, 0);
    return date;
  }, []);
  const [displayedMonth, setDisplayedMonth] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const timeOptions = useMemo(() => Array.from({ length: 11 }, (_, index) => {
    const totalMinutes = 17 * 60 + index * 30;
    const hours = String(Math.floor(totalMinutes / 60)).padStart(2, '0');
    const minutes = String(totalMinutes % 60).padStart(2, '0');
    return { value: `${hours}:${minutes}`, label: `${hours}:${minutes}` };
  }), []);
  const monthOptions = useMemo(() => Array.from({ length: 12 }, (_, index) => {
    const date = new Date(today.getFullYear(), today.getMonth() + index, 1);
    return {
      value: `${date.getFullYear()}-${date.getMonth()}`,
      label: date.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }),
      date,
    };
  }), [today]);
  const calendarDays = useMemo(() => {
    const start = new Date(displayedMonth);
    start.setDate(displayedMonth.getDate() - displayedMonth.getDay());
    return Array.from({ length: 42 }, (_, index) => {
      const date = new Date(start);
      date.setDate(start.getDate() + index);
      const disabled = date < today;
      return { date, value: toIsoDate(date), disabled };
    });
  }, [displayedMonth, today]);

  useEffect(() => {
    if (!open) return;
    const handleOutsideClick = (event) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('touchstart', handleOutsideClick);
    document.addEventListener('click', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
      document.removeEventListener('click', handleOutsideClick);
    };
  }, [open]);

  const Icon = isDate ? CalendarDays : Clock;
  const startValue = isDate ? (value?.from || '') : '';
  const endValue = isDate ? (value?.to || '') : '';
  const fieldValue = isDate ? (startValue && endValue ? `${startValue} to ${endValue}` : '') : value;
  const selectedLabel = isDate
    ? (startValue && endValue ? `${formatIsoDateLabel(startValue)} — ${formatIsoDateLabel(endValue)}` : startValue ? `${formatIsoDateLabel(startValue)} — select end date` : '')
    : (timeOptions.find((option) => option.value === value)?.label || '');
  const handleDateSelect = (dayValue) => {
    if (!startValue || endValue || dayValue < startValue) {
      onChange({ from: dayValue, to: '' });
      return;
    }
    onChange({ from: startValue, to: dayValue });
    setOpen(false);
  };

  return (
    <label ref={pickerRef} className="relative block text-xs font-semibold text-roam-secondary">
      {label}*
      <button type="button" onClick={() => setOpen((current) => !current)} className={`${fieldClass} flex items-center justify-between text-left`}>
        <span className={fieldValue ? 'text-roam-text' : 'text-roam-muted'}>{selectedLabel || (isDate ? 'Choose dates' : 'Choose time')}</span>
        <span className="flex items-center gap-2 text-roam-text">
          <Icon size={16} strokeWidth={1.8} />
          <ChevronDown size={15} className={`transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
        </span>
      </button>
      <input required tabIndex={-1} aria-hidden="true" name={name} value={fieldValue} onChange={() => {}} className="pointer-events-none absolute bottom-0 left-0 h-px w-px opacity-0" />
      {open && (
        <div className="absolute bottom-[calc(100%+8px)] left-1/2 z-[30000] w-full -translate-x-1/2 rounded-[24px] border border-[#DDDBD5] bg-[#F8F7F4] p-3 shadow-[0_20px_48px_rgba(14,14,14,0.14)] md:bottom-auto md:top-[calc(100%+8px)]">
          {isDate ? (
            <div className="font-inter">
              <div className="mb-3 flex items-center justify-between gap-3 rounded-2xl bg-white px-3 py-2 text-roam-text">
                <div className="relative flex-1">
                  <select
                    value={`${displayedMonth.getFullYear()}-${displayedMonth.getMonth()}`}
                    onChange={(event) => {
                      const nextMonth = monthOptions.find((month) => month.value === event.target.value);
                      if (nextMonth) setDisplayedMonth(nextMonth.date);
                    }}
                    className="h-9 w-full appearance-none rounded-full border border-[#DDDBD5] bg-[#F8F7F4] px-3 pr-12 font-inter text-sm font-bold text-roam-text outline-none transition-all duration-200 hover:border-[#571AFF] focus:border-[#571AFF]"
                  >
                    {monthOptions.map((month) => <option key={month.value} value={month.value}>{month.label}</option>)}
                  </select>
                  <ChevronDown size={15} className="pointer-events-none absolute right-5 top-1/2 -translate-y-1/2 text-roam-text" />
                </div>
                <CalendarDays size={16} />
              </div>
              <div className="mb-2 grid grid-cols-7 gap-1 text-center text-[10px] font-bold uppercase tracking-[0.12em] text-roam-muted">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => <span key={`${day}-${index}`}>{day}</span>)}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {calendarDays.map((day) => {
                  const rangeEdge = day.value === startValue || day.value === endValue;
                  const inRange = startValue && endValue && day.value > startValue && day.value < endValue;
                  const muted = day.date.getMonth() !== displayedMonth.getMonth();
                  return (
                    <button
                      key={day.value}
                      type="button"
                      disabled={day.disabled}
                      onClick={() => handleDateSelect(day.value)}
                      className={`flex h-9 items-center justify-center rounded-full text-sm transition-all duration-200 ${rangeEdge ? 'bg-[#571AFF] text-white shadow-[0_10px_22px_rgba(87,26,255,0.24)]' : inRange ? 'bg-[#F0E9FF] text-[#571AFF]' : day.disabled ? 'cursor-not-allowed text-[#C8C6C0]' : muted ? 'bg-white/60 text-roam-muted hover:bg-black hover:text-white' : 'bg-white text-roam-text hover:bg-black hover:text-white hover:shadow-[0_10px_22px_rgba(14,14,14,0.12)]'}`}
                    >
                      {day.date.getDate()}
                    </button>
                  );
                })}
              </div>
              {startValue && <button type="button" onClick={() => onChange({ from: '', to: '' })} className="mt-3 w-full rounded-full border border-[#DDDBD5] bg-white px-4 py-2 font-inter text-xs font-bold transition-all duration-200 hover:bg-[#F7F4FF]" style={{ color: '#571AFF' }}>Clear dates</button>}
              </div>
          ) : (
            <div className="grid gap-1">
              {timeOptions.map((option) => {
                const active = option.value === value;
                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => { onChange(option.value); setOpen(false); }}
                    className={`flex h-10 items-center justify-between rounded-2xl px-3 font-inter text-sm transition-all duration-200 ${active ? 'bg-[#571AFF] text-white shadow-[0_10px_22px_rgba(87,26,255,0.22)]' : 'bg-white text-roam-text hover:bg-black hover:text-white hover:shadow-[0_10px_22px_rgba(14,14,14,0.12)]'}`}
                  >
                    <span>{option.label}</span>
                    {active && <Check size={15} />}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}
    </label>
  );
}

export default function PlaceBookingForm({ placeName, category }) {
  const [bookingSent, setBookingSent] = useState(false);
  const [bookingDate, setBookingDate] = useState({ from: '', to: '' });
  const [bookingTime, setBookingTime] = useState('');
  const timeFieldLabel = category === 'stay' || category === 'hotel' ? 'Preferred Check-In Time' : 'Time';

  const handleBookingSubmit = (event) => {
    event.preventDefault();
    setBookingSent(true);
    event.currentTarget.reset();
    setBookingDate({ from: '', to: '' });
    setBookingTime('');
  };

  return (
    <form onSubmit={handleBookingSubmit} className="mt-6 space-y-4 font-inter">
      <div className="space-y-4">
        <label className="text-xs font-semibold text-roam-secondary">Name*
          <input required name="name" className={fieldClass} />
        </label>
        <label className="text-xs font-semibold text-roam-secondary">Surname*
          <input required name="surname" className={fieldClass} />
        </label>
      </div>
      <div className="space-y-4">
        <DateTimePickerField label="Dates" name="dates" type="date" value={bookingDate} onChange={setBookingDate} />
        <DateTimePickerField label={timeFieldLabel} name="time" type="time" value={bookingTime} onChange={setBookingTime} />
      </div>
      <label className="block text-xs font-semibold text-roam-secondary">Phone
        <input name="phone" type="tel" className={fieldClass} />
      </label>
      <label className="block text-xs font-semibold text-roam-secondary">Email*
        <input required name="email" type="text" inputMode="email" autoComplete="email" pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="Enter a valid email address" className={fieldClass} />
      </label>
      <label className="block text-xs font-semibold text-roam-secondary">Message
        <textarea name="message" rows="4" className="mt-2 w-full resize-none rounded-2xl border border-[#DDDBD5] bg-white px-4 py-3 text-sm text-roam-text outline-none transition-all duration-200 hover:border-[#571AFF] hover:shadow-[0_8px_22px_rgba(87,26,255,0.10)] focus:border-[#571AFF] focus:shadow-[0_8px_22px_rgba(87,26,255,0.14)]" />
      </label>
      <button type="submit" className="flex h-12 w-full items-center justify-center rounded-full bg-[#571AFF] font-inter text-sm font-bold text-white shadow-[0_12px_28px_rgba(87,26,255,0.28)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-black hover:shadow-[0_16px_34px_rgba(14,14,14,0.22)] active:translate-y-0">Book Now</button>
      {bookingSent && <p className="text-center text-xs font-semibold text-[#2A6B3A]">Your booking request for {placeName} has been sent.</p>}
    </form>
  );
}