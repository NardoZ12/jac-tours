import { Check, Calendar, Clock, Users, MapPin, MessageSquare, Plus, ChevronRight, User, Phone, Plane, Luggage } from 'lucide-react';

/**
 * Shared post-booking confirmation screen for all booking types (eat / stay / do).
 *
 * Props:
 *  - booking: { confirmationCode, venue, type, dateLabel, timeLabel, partyLabel, total?, currency? }
 *  - onClose: () => void
 *
 * Displays a polished receipt + lets the user attach the booking to one of their existing trips.
 */
const TYPE_ACCENT = {
  eat:   { color: '#FF7849', label: 'Reservation', emoji: '🍽️' },
  stay:  { color: '#7AB8DD', label: 'Stay',        emoji: '🏨' },
  do:    { color: '#A3CD7B', label: 'Experience',  emoji: '✨' },
};

export default function BookingConfirmation({ booking, onClose }) {
  const accent = TYPE_ACCENT[booking.type] || TYPE_ACCENT.eat;
  const trips = [];
  const loadingTrips = false;
  const savingTripId = null;
  const savedTripId = null;

  const addToTrip = () => {};

  const rows = [
    booking.tier       && { Icon: Check,    label: 'Tier',   value: booking.tier },
    booking.dateLabel  && { Icon: Calendar, label: 'Date',  value: booking.dateLabel },
    booking.timeLabel  && { Icon: Clock,    label: 'Time',  value: booking.timeLabel },
    booking.partyLabel && { Icon: Users,    label: 'Guests', value: booking.partyLabel },
    booking.venue?.address && { Icon: MapPin, label: 'Where', value: booking.venue.address },
    booking.pickupLabel && { Icon: MapPin, label: 'Pickup', value: booking.pickupLabel },
    booking.note && { Icon: MessageSquare, label: 'Note', value: booking.note },
    booking.customerName && { Icon: User, label: 'Name', value: booking.customerName },
    booking.customerPhone && { Icon: Phone, label: 'Phone', value: booking.customerPhone },
    booking.flightNumber && { Icon: Plane, label: 'Flight', value: booking.flightNumber },
    booking.luggageCount && { Icon: Luggage, label: 'Luggage', value: booking.luggageCount },
  ].filter(Boolean);

  return (
    <div className="text-left animate-fade-in-up">
      {/* Hero check + code */}
      <div className="flex flex-col items-center text-center mb-5">
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mb-3"
          style={{ background: accent.color, boxShadow: `0 8px 24px ${accent.color}44` }}
        >
          <Check size={30} strokeWidth={3} color="white" />
        </div>
        <p className="font-poppins font-semibold uppercase tracking-wide" style={{ fontSize: '12px', color: accent.color, letterSpacing: '0.08em' }}>
          {accent.label} confirmed
        </p>
        <h2 className="font-poppins font-bold mt-1" style={{ fontSize: '22px', color: '#141413' }}>
          You're all set!
        </h2>
        <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>
          Confirmation code
        </p>
        <p className="font-poppins font-bold mt-0.5" style={{ fontSize: '20px', color: '#141413', letterSpacing: '0.04em' }}>
          {booking.confirmationCode}
        </p>
      </div>

      {/* Venue card */}
      <div className="rounded-2xl p-4 mb-4" style={{ background: '#FFFFFF', border: '1.5px solid #EFEAE3' }}>
        <div className="flex items-start gap-3">
          {booking.venue?.cover_image_url ? (
            <img
              src={booking.venue.cover_image_url}
              alt={booking.venue.name}
              className="flex-shrink-0 w-12 h-12 rounded-xl object-cover"
            />
          ) : (
            <div
              className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: `${accent.color}1A`, fontSize: '22px' }}
            >
              {accent.emoji}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="font-poppins font-bold truncate" style={{ fontSize: '16px', color: '#141413' }}>
              {booking.venue.name}
            </p>
            {booking.venue.neighborhood && (
              <p className="font-inter truncate" style={{ fontSize: '13px', color: '#72706A' }}>
                {booking.venue.neighborhood}{booking.venue.city ? ` · ${booking.venue.city}` : ''}
              </p>
            )}
          </div>
          {booking.total != null && (
            <div className="text-right">
              <p className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>
                {booking.currency === 'USD' ? '$' : '€'}{Number(booking.total).toLocaleString()}
              </p>
              <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Total</p>
            </div>
          )}
        </div>

        <div className="mt-3 pt-3 space-y-2" style={{ borderTop: '1px solid #F2EDE6' }}>
          {rows.map(({ Icon, label, value }) => (
            <div key={label} className="flex items-start gap-2.5">
              <Icon size={14} color="#72706A" className="mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0 flex items-baseline justify-between gap-3">
                <span className="font-inter flex-shrink-0" style={{ fontSize: '12px', color: '#72706A' }}>{label}</span>
                <span className="font-poppins font-semibold text-right truncate" style={{ fontSize: '13px', color: '#141413' }}>{value}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add to trip */}
      <div className="mb-4">
        <p className="font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>
          Trip planning
        </p>
        {loadingTrips ? (
          <div className="skeleton rounded-xl" style={{ height: '52px' }} />
        ) : trips.length === 0 ? (
          <div className="rounded-xl p-3 flex items-center gap-2" style={{ background: '#F2EDE6' }}>
            <Plus size={16} color="#72706A" />
            <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>
              No trips yet — create one from Trips later
            </span>
          </div>
        ) : (
          <div className="space-y-2">
            {trips.map(t => {
              const isSaving = savingTripId === t.id;
              const isSaved = savedTripId === t.id;
              const disabled = !!savedTripId && !isSaved;
              return (
                <button
                  key={t.id}
                  onClick={() => addToTrip(t)}
                  disabled={isSaving || isSaved || disabled}
                  className="w-full press-shrink rounded-xl p-3 flex items-center gap-3 text-left"
                  style={{
                    background: isSaved ? `${accent.color}14` : '#FFFFFF',
                    border: `1.5px solid ${isSaved ? accent.color : '#EFEAE3'}`,
                    opacity: disabled ? 0.5 : 1,
                  }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-poppins font-semibold truncate" style={{ fontSize: '14px', color: '#141413' }}>
                      {t.title}
                    </p>
                    <p className="font-inter truncate" style={{ fontSize: '12px', color: '#72706A' }}>
                      {t.destination_city}{t.start_date ? ` · ${t.start_date}` : ''}
                    </p>
                  </div>
                  {isSaved ? (
                    <span className="font-poppins font-semibold flex items-center gap-1" style={{ fontSize: '12px', color: accent.color }}>
                      <Check size={14} /> Added
                    </span>
                  ) : isSaving ? (
                    <span className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Saving…</span>
                  ) : (
                    <ChevronRight size={18} color="#B0AEA5" />
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Done */}
      <button onClick={onClose} className="btn-primary">Done</button>
      <p className="font-inter text-center mt-2" style={{ fontSize: '12px', color: '#72706A' }}>
        We'll send you a reminder before your {accent.label.toLowerCase()}
      </p>
    </div>
  );
}