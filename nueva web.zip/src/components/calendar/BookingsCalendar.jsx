import { useMemo, useState } from 'react';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, addMonths, subMonths, isSameDay, isSameMonth, startOfWeek, endOfWeek } from 'date-fns';
import { ChevronLeft, ChevronRight, UtensilsCrossed, BedDouble, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const TYPE_META = {
  eat:  { label: 'Restaurant', color: '#0E0E0E', Icon: UtensilsCrossed, route: (b) => `/eat/${b.venue_id}` },
  stay: { label: 'Hotel',      color: '#3A3A3A', Icon: BedDouble,       route: (b) => `/stay/${b.venue_id}` },
  do:   { label: 'Experience', color: '#888580', Icon: Sparkles,        route: (b) => `/do/${b.venue_id}` },
};

const STATUS_META = {
  confirmed: { label: 'Confirmed', color: '#16A34A', bg: '#E7F6EC' },
  pending:   { label: 'Pending',   color: '#D97706', bg: '#FEF3E2' },
  cancelled: { label: 'Cancelled', color: '#DC2626', bg: '#FCE8E8' },
  completed: { label: 'Completed', color: '#6B6962', bg: '#F0EFE9' },
  no_show:   { label: 'No-show',   color: '#6B6962', bg: '#F0EFE9' },
};

const DOW = ['S','M','T','W','T','F','S'];

/**
 * Parse a booking's primary date (YYYY-MM-DD or ISO check_in).
 * Returns a Date or null.
 */
function bookingDate(b) {
  const raw = b?.date || b?.check_in;
  if (!raw) return null;
  try { return parseISO(raw.length === 10 ? raw : raw.slice(0, 10)); } catch { return null; }
}

/**
 * Visual calendar that groups bookings by day.
 * Pass any list of Booking entities. The component groups them itself.
 */
export default function BookingsCalendar({ bookings = [], emptyHint = 'No bookings yet — your reservations will appear here.' }) {
  const [cursor, setCursor] = useState(new Date());

  // Group bookings by ISO day
  const byDay = useMemo(() => {
    const map = {};
    for (const b of bookings) {
      const d = bookingDate(b);
      if (!d) continue;
      const key = format(d, 'yyyy-MM-dd');
      (map[key] ||= []).push(b);
    }
    return map;
  }, [bookings]);

  const monthStart = startOfMonth(cursor);
  const monthEnd = endOfMonth(cursor);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const gridEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const days = eachDayOfInterval({ start: gridStart, end: gridEnd });

  // Upcoming bookings list (next 8, on or after today)
  const today = new Date(); today.setHours(0,0,0,0);
  const upcoming = useMemo(() =>
    [...bookings]
      .map(b => ({ b, d: bookingDate(b) }))
      .filter(x => x.d && x.d >= today)
      .sort((a, b) => a.d - b.d)
      .slice(0, 8)
  , [bookings, today]);

  return (
    <div className="rounded-2xl bg-white card-shadow overflow-hidden">
      {/* Month header */}
      <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: '1px solid #F2EDE6' }}>
        <button
          onClick={() => setCursor(c => subMonths(c, 1))}
          className="w-8 h-8 flex items-center justify-center rounded-lg"
          style={{ background: '#F0EFE9' }}
          aria-label="Previous month"
        >
          <ChevronLeft size={16} color="#141413" />
        </button>
        <p className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#141413' }}>
          {format(cursor, 'MMMM yyyy')}
        </p>
        <button
          onClick={() => setCursor(c => addMonths(c, 1))}
          className="w-8 h-8 flex items-center justify-center rounded-lg"
          style={{ background: '#F0EFE9' }}
          aria-label="Next month"
        >
          <ChevronRight size={16} color="#141413" />
        </button>
      </div>

      {/* Day-of-week strip */}
      <div className="grid grid-cols-7 px-2 pt-2">
        {DOW.map((d, i) => (
          <div key={i} className="text-center font-poppins font-semibold" style={{ fontSize: '12px', color: '#B0AEA5', padding: '4px 0' }}>{d}</div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1 px-2 pb-2">
        {days.map(day => {
          const key = format(day, 'yyyy-MM-dd');
          const items = byDay[key] || [];
          const inMonth = isSameMonth(day, cursor);
          const isToday = isSameDay(day, new Date());
          const types = [...new Set(items.map(i => i.booking_type))].slice(0, 3);

          const allCancelled = items.length > 0 && items.every(i => i.status === 'cancelled');
          const hasPending = items.some(i => i.status === 'pending');

          return (
            <div
              key={key}
              className="aspect-square rounded-lg flex flex-col items-center justify-start py-1"
              style={{
                background: isToday ? '#F0EFE9' : 'transparent',
                border: isToday ? '1.5px solid #0E0E0E' : '1.5px solid transparent',
                opacity: inMonth ? 1 : 0.35,
              }}
            >
              <span
                className="font-poppins font-semibold"
                style={{
                  fontSize: '12px',
                  color: isToday ? '#0E0E0E' : '#141413',
                  textDecoration: allCancelled ? 'line-through' : 'none',
                }}
              >
                {format(day, 'd')}
              </span>
              <div className="flex gap-0.5 mt-1 items-center">
                {types.map(t => (
                  <span
                    key={t}
                    className="rounded-full"
                    style={{ width: '5px', height: '5px', background: TYPE_META[t]?.color || '#B0AEA5' }}
                  />
                ))}
                {hasPending && (
                  <span className="rounded-full" style={{ width: '5px', height: '5px', background: '#D97706' }} />
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Upcoming timeline */}
      <div className="px-4 py-3" style={{ borderTop: '1px solid #F2EDE6' }}>
        <p className="font-poppins font-semibold mb-2" style={{ fontSize: '13px', color: '#141413' }}>
          Upcoming
        </p>
        {upcoming.length === 0 ? (
          <p className="font-inter py-2" style={{ fontSize: '13px', color: '#B0AEA5' }}>{emptyHint}</p>
        ) : (
          <div className="space-y-2">
            {upcoming.map(({ b, d }) => {
              const meta = TYPE_META[b.booking_type] || TYPE_META.eat;
              const Icon = meta.Icon;
              return (
                <Link
                  key={b.id}
                  to={meta.route(b)}
                  className="flex items-center gap-3 rounded-xl p-2 press-shrink"
                  style={{ background: '#F8F7F4' }}
                >
                  {/* Date column */}
                  <div className="flex-shrink-0 w-12 text-center rounded-lg py-1.5" style={{ background: '#FFF', border: `1.5px solid ${meta.color}` }}>
                    <p className="font-poppins font-semibold" style={{ fontSize: '12px', color: meta.color, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                      {format(d, 'MMM')}
                    </p>
                    <p className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413', lineHeight: 1 }}>
                      {format(d, 'd')}
                    </p>
                  </div>
                  {/* Body */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
                      <Icon size={11} color={meta.color} />
                      <span className="font-poppins font-semibold" style={{ fontSize: '12px', color: meta.color, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                        {meta.label}
                      </span>
                      {(() => {
                        const s = STATUS_META[b.status];
                        if (!s) return null;
                        return (
                          <span
                            className="font-poppins font-semibold inline-flex items-center gap-1"
                            style={{ fontSize: '12px', color: s.color, background: s.bg, padding: '2px 6px', borderRadius: '99px', letterSpacing: '0.04em', textTransform: 'uppercase' }}
                          >
                            <span className="rounded-full" style={{ width: '5px', height: '5px', background: s.color }} />
                            {s.label}
                          </span>
                        );
                      })()}
                    </div>
                    <p
                      className="font-poppins font-semibold truncate"
                      style={{
                        fontSize: '14px',
                        color: '#141413',
                        textDecoration: b.status === 'cancelled' ? 'line-through' : 'none',
                        opacity: b.status === 'cancelled' ? 0.6 : 1,
                      }}
                    >
                      {b.venue_name || 'Booking'}
                    </p>
                    <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
                      {b.time || (b.check_in ? format(parseISO(b.check_in), 'HH:mm') : '')}
                      {b.party_size ? ` · ${b.party_size} ${b.party_size > 1 ? 'guests' : 'guest'}` : ''}
                    </p>
                  </div>
                  <span className="font-inter flex-shrink-0" style={{ fontSize: '13px', color: meta.color }}>→</span>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-3 px-4 py-2.5"         style={{ background: '#F8F7F4', borderTop: '1px solid #DDDBD5' }}>
        {Object.entries(TYPE_META).map(([key, m]) => (
          <div key={key} className="flex items-center gap-1.5">
            <span className="rounded-full" style={{ width: '6px', height: '6px', background: m.color }} />
            <span className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>{m.label}s</span>
          </div>
        ))}
      </div>
    </div>
  );
}