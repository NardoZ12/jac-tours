import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sailboat, Clock, Users, Check, ArrowLeft, Anchor, Waves, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import Reveal from '@/components/ui/Reveal';
import { notifyQuote } from '@/lib/notifyQuote';

// TODO: Update with your real WhatsApp number (country code + number, no symbols)
const WHATSAPP_NUMBER = '18090000000';

const YACHTS = [
  {
    id: 'pamela1',
    name: 'PAMELA-1',
    capacity: 20,
    hours: 6,
    desc: 'Catamarán de lujo con tobogán acuático y amplias áreas de descanso. Ideal para grupos grandes y celebraciones especiales.',
    img: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/39c6b5a0f_A8V3uOUR9NSxoww5eNQkFOSMkE89f9.jpg',
    gallery: [
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/aa93de87f_A8V3uOUR9NSxoww5eNQkFOSMkEd6a3.jpg',
    ],
  },
  {
    id: 'cranchi',
    name: 'Cranchi 50',
    capacity: 12,
    hours: 4,
    desc: 'Yate motor italiano con cabinas de lujo, interior en caoba y sofás de cuerocrema. Elegancia y confort en alta mar.',
    img: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/4cd552bc5_BUbbTfUE4LBHKQMHDqhqseATlck63d7.jpg',
    gallery: [
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/8c2f726e2_BUbbTfUE4LBHKQMHDqhqseATlck2616.jpg',
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/fcd32abb9_bVHTZZAvi5LA347Q1bBed03Ucw1c2a.jpg',
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/089576272_bVHTZZAvi5LA347Q1bBed03Ucwd39c.jpg',
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/8b3fe186c_aCoQNhRkZvyNAAZGHYXMX3MI0fd3d.jpg',
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/1ecf3e4e2_aCoQNhRkZvyNAAZGHYXMX3MI0367a.jpg',
    ],
  },
  {
    id: 'express',
    name: 'Express Cruiser',
    capacity: 8,
    hours: 4,
    desc: 'Crucero deportivo ágil y elegante, perfecto para recorridos costeros y excursiones rápidas por la costa caribeña.',
    img: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/0d41f7572_34bQyUpR0C5CAzdTDmURhOfkT94b2db.jpg',
    gallery: [
      'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/67532582f_34bQyUpR0C5CAzdTDmURhOfkT94b351.jpg',
    ],
  },
];

const EMBARK = [
  'Marina Cap Cana',
  'Marina Punta Cana (Bávaro)',
  'Puerto de Casa de Campo (La Romana)',
  'Puerto de Santo Domingo',
];

const TIMES = ['08:00','09:00','10:00','11:00','12:00','13:00','14:00'];

const EXTRA_LABELS = { catering: 'Catering gourmet', bar: 'Open Bar Premium', snorkel: 'Equipo de snorkel', dj: 'DJ a bordo' };

function buildWhatsAppLink(yacht, embark, date, time, guests, extras) {
  const extrasList = Object.entries(extras).filter(([, v]) => v).map(([k]) => EXTRA_LABELS[k]);
  const lines = [
    '¡Hola Jac Tour and Transfers! 👋',
    '',
    'Me gustaría cotizar el alquiler de un yate:',
    '',
    `🛥️ Yate: ${yacht.name}`,
    `📍 Embarque: ${embark}`,
    `📅 Fecha: ${date ? format(date, "EEE, MMM d") : 'Por definir'}`,
    `⏰ Hora: ${time}`,
    `👥 Invitados: ${guests}`,
    `⏱️ Duración: ${yacht.hours}h`,
  ];
  if (extrasList.length) lines.push(`✨ Extras: ${extrasList.join(', ')}`);
  lines.push('', '¿Me pueden enviar la cotización? ¡Gracias!');
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join('\n'))}`;
}

export default function Yates() {
  const today = new Date();
  const [yacht, setYacht] = useState('pamela1');
  const [embark, setEmbark] = useState(EMBARK[0]);
  const [date, setDate] = useState(null);
  const [showCal, setShowCal] = useState(false);
  const [time, setTime] = useState(TIMES[2]);
  const [guests, setGuests] = useState(6);
  const [extras, setExtras] = useState({ catering: false, bar: false, snorkel: true, dj: false });

  const selected = YACHTS.find((y) => y.id === yacht);
  const toggleExtra = (key) => setExtras((e) => ({ ...e, [key]: !e[key] }));

  const quoteHref = buildWhatsAppLink(selected, embark, date, time, guests, extras);
  const extrasList = Object.entries(extras).filter(([, v]) => v).map(([k]) => EXTRA_LABELS[k]);

  const quoteDetails = (y, src) => ({
    type: 'Yate',
    yacht: y.name,
    embark,
    date: date ? format(date, "EEE, MMM d") : 'Por definir',
    time,
    guests,
    extras: extrasList,
    source: src,
  });

  return (
    <div className="min-h-screen" style={{ background: '#F8F7F4' }}>
      {/* Hero */}
      <section className="relative" style={{ background: 'linear-gradient(135deg, #051c2c 0%, #0a3a5c 55%, #127a8c 100%)' }}>
        <div className="mx-auto max-w-7xl px-5 md:px-8 py-16 md:py-24 text-center">
          <motion.div
            className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 mb-5"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}>
            <Sailboat size={14} color="#FFFFFF" />
            <span className="font-inter text-white font-semibold" style={{ fontSize: '12px', letterSpacing: '0.04em' }}>Chárter de yates de lujo</span>
          </motion.div>
          <motion.h1
            className="font-poppins font-normal text-white"
            style={{ fontSize: 'clamp(36px, 6vw, 64px)', lineHeight: 1.05, letterSpacing: '-0.04em' }}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}>
            Reserva tu yate
          </motion.h1>
          <motion.p
            className="mx-auto mt-4 font-inter text-white/80"
            style={{ maxWidth: '540px', fontSize: '15px', lineHeight: 1.6 }}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3, ease: 'easeOut' }}>
            Navega por las aguas turquesas del Caribe a bordo de yates y catamaranes privados con tripulación profesional. Saona, Catalina, Palmarosa y más.
          </motion.p>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-5 md:px-8 py-12 md:py-16">
        {/* Yacht selection */}
        <Reveal><h2 className="font-poppins font-bold mb-4" style={{ fontSize: '24px', color: '#141413' }}>Selecciona tu yate</h2></Reveal>
        <div className="grid gap-5 sm:grid-cols-2 mb-10">
          {YACHTS.map((y, i) => {
            const active = yacht === y.id;
            return (
              <motion.div
                key={y.id}
                onClick={() => setYacht(y.id)}
                className="rounded-[24px] overflow-hidden transition-all press-shrink cursor-pointer"
                style={{
                  background: '#FFFFFF',
                  border: `2px solid ${active ? '#571AFF' : '#E8E6DC'}`,
                  boxShadow: active ? '0 16px 36px rgba(87,26,255,0.18)' : '0 6px 18px rgba(14,14,14,0.06)',
                }}
                initial={{ opacity: 0, y: 36 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -6 }}
              >
                <div className="relative h-[200px]" style={{ background: 'linear-gradient(135deg, #0a3a5c, #127a8c)' }}>
                  <img src={y.img} alt={y.name} className="w-full h-full object-cover" onError={(e) => { e.target.style.display = 'none'; }} />
                  <div className="absolute top-3 right-3 rounded-full px-3 py-1 flex items-center gap-1" style={{ background: 'rgba(255,255,255,0.95)' }}>
                    <Users size={12} color="#141413" /><span className="font-inter font-bold" style={{ fontSize: '12px', color: '#141413' }}>{y.capacity}</span>
                  </div>
                  {active && <div className="absolute top-3 left-3 w-7 h-7 rounded-full flex items-center justify-center" style={{ background: '#571AFF' }}><Check size={16} color="#FFFFFF" /></div>}
                </div>
                <div className="p-5">
                  <h3 className="font-poppins font-bold" style={{ fontSize: '18px', color: '#141413' }}>{y.name}</h3>
                  <div className="flex items-center gap-3 mt-1 font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
                    <span className="flex items-center gap-1"><Clock size={12} />{y.hours}h</span>
                    <span className="flex items-center gap-1"><Users size={12} />hasta {y.capacity}</span>
                  </div>
                  <p className="font-inter mt-2" style={{ fontSize: '13px', color: '#3A3A3A', lineHeight: 1.5 }}>{y.desc}</p>
                  <a
                    href={buildWhatsAppLink(y, embark, date, time, guests, extras)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => { e.stopPropagation(); notifyQuote(quoteDetails(y, 'Yates - tarjeta')); }}
                    className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-full font-inter font-semibold transition-all press-shrink"
                    style={{ height: '44px', fontSize: '13px', background: '#25D366', color: '#FFFFFF', boxShadow: '0 6px 18px rgba(37,211,102,0.30)' }}
                  >
                    <MessageCircle size={15} /> Cotizar por WhatsApp
                  </a>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Booking form */}
        <Reveal>
        <div className="rounded-[28px] bg-white p-6 md:p-8" style={{ boxShadow: '0 18px 44px rgba(14,14,14,0.08)' }}>
          <h2 className="font-poppins font-bold mb-5" style={{ fontSize: '22px', color: '#141413' }}>Detalles de la cotización</h2>

          <div className="grid gap-5 md:grid-cols-2">
            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Punto de embarque</label>
              <select
                value={embark}
                onChange={(e) => setEmbark(e.target.value)}
                className="w-full rounded-2xl px-4 py-3 font-inter"
                style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '52px' }}
              >
                {EMBARK.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>

            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Fecha</label>
              <button
                onClick={() => setShowCal((s) => !s)}
                className="w-full rounded-2xl px-4 py-3 flex items-center gap-2 text-left"
                style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', minHeight: '52px' }}
              >
                <Clock size={16} color="#571AFF" />
                <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{date ? format(date, 'EEE, MMM d') : 'Selecciona fecha'}</span>
              </button>
              {showCal && (
                <div className="mt-2 rounded-2xl" style={{ background: '#FFF', border: '1.5px solid #E8E6DC' }}>
                  <div className="flex justify-center">
                    <Calendar mode="single" selected={date || undefined} onSelect={(d) => { if (d) { setDate(d); setShowCal(false); } }} disabled={{ before: today }} numberOfMonths={1} />
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Hora de salida</label>
              <div className="flex flex-wrap gap-2">
                {TIMES.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTime(t)}
                    className="font-poppins font-semibold rounded-xl px-3"
                    style={{ height: '40px', fontSize: '13px', background: t === time ? '#141413' : '#F0EFE9', color: t === time ? '#FFF' : '#141413', border: '1.5px solid ' + (t === time ? '#141413' : '#E8E6DC') }}
                  >{t}</button>
                ))}
              </div>
            </div>

            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Número de invitados</label>
              <div className="flex items-center gap-3 rounded-2xl px-4 py-2" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', minHeight: '52px' }}>
                <button onClick={() => setGuests((g) => Math.max(1, g - 1))} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#FFFFFF' }}><Users size={14} color="#141413" /></button>
                <span className="font-poppins font-bold flex-1 text-center" style={{ fontSize: '16px', color: '#141413' }}>{guests}</span>
                <button onClick={() => setGuests((g) => Math.min(selected.capacity, g + 1))} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#FFFFFF' }}><Users size={14} color="#141413" /></button>
              </div>
              <p className="font-inter mt-1" style={{ fontSize: '11px', color: '#72706A' }}>Capacidad máxima {selected.capacity} invitados</p>
            </div>
          </div>

          {/* Extras */}
          <div className="mt-5">
            <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Extras opcionales</label>
            <div className="grid gap-2 sm:grid-cols-2">
              {Object.entries(EXTRA_LABELS).map(([key, label]) => {
                const on = extras[key];
                return (
                  <button
                    key={key}
                    onClick={() => toggleExtra(key)}
                    className="flex items-center justify-between rounded-2xl px-4 py-3"
                    style={{ background: on ? '#F3EFFF' : '#F0EFE9', border: `1.5px solid ${on ? '#571AFF' : '#E8E6DC'}` }}
                  >
                    <span className="font-poppins font-semibold" style={{ fontSize: '13px', color: '#141413' }}>{label}</span>
                    <div className="w-5 h-5 rounded-md flex items-center justify-center" style={{ background: on ? '#571AFF' : '#FFFFFF', border: '1.5px solid ' + (on ? '#571AFF' : '#C8C6C0') }}>
                      {on && <Check size={12} color="#FFFFFF" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Summary + WhatsApp CTA */}
          <div className="mt-6 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4" style={{ background: '#F0EFE9' }}>
            <div>
              <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{selected.name} · {selected.hours}h · {guests} invitados</p>
              <p className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#141413' }}>Cotización personalizada</p>
            </div>
            <a
              href={quoteHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => notifyQuote(quoteDetails(selected, 'Yates - resumen'))}
              className="inline-flex items-center justify-center gap-2 rounded-full font-inter font-semibold transition-all press-shrink whitespace-nowrap"
              style={{ height: '52px', padding: '0 32px', fontSize: '14px', background: '#25D366', color: '#FFFFFF', boxShadow: '0 8px 24px rgba(37,211,102,0.32)' }}
            >
              <MessageCircle size={18} /> Cotizar por WhatsApp <ArrowLeft size={16} className="rotate-180" />
            </a>
          </div>
          {!date && <p className="font-inter text-center mt-2" style={{ fontSize: '12px', color: '#72706A' }}>Selecciona una fecha para incluir en la cotización</p>}
        </div>
        </Reveal>

        {/* Features */}
        <div className="grid gap-4 sm:grid-cols-3 mt-12">
          {[
            { Icon: Anchor, title: 'Tripulación profesional', desc: 'Capitán y marineros licenciados' },
            { Icon: Waves, title: 'Itinerarios a medida', desc: 'Saona, Catalina, Palmarosa y más' },
            { Icon: Check, title: 'Todo incluido', desc: 'Bebidas, snorkel y hielo a bordo' },
          ].map(({ Icon, title, desc }, i) => (
            <Reveal key={title} delay={i * 0.1}>
            <motion.div
              className="rounded-2xl bg-white p-5"
              style={{ boxShadow: '0 4px 14px rgba(14,14,14,0.05)' }}
              whileHover={{ y: -6, boxShadow: '0 14px 28px rgba(87,26,255,0.14)' }}
              transition={{ duration: 0.25 }}>
              <Icon size={22} color="#571AFF" />
              <h3 className="font-poppins font-bold mt-2" style={{ fontSize: '15px', color: '#141413' }}>{title}</h3>
              <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A', lineHeight: 1.5 }}>{desc}</p>
            </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}