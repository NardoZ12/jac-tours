import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Trash2, Plus, Minus } from 'lucide-react';
import { useCart } from '@/lib/CartContext';
import CartCheckoutSheet from '@/components/cart/CartCheckoutSheet';

export default function Cart() {
  const { items, removeItem, updateGroupSize, total, count } = useCart();
  const [checkout, setCheckout] = useState(false);

  const isEmpty = items.length === 0;

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      <section className="relative overflow-hidden px-5 pt-16 pb-8 md:px-8 md:pt-24">
        <div className="absolute inset-0 pointer-events-none opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)', maskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)' }} />
        <div className="relative mx-auto max-w-7xl text-center">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-[0_12px_28px_rgba(14,14,14,0.08)]"><ShoppingCart size={24} fill="#0E0E0E" /></div>
          <h1 className="[font-family:'Libre_Baskerville',_serif] text-[55px] font-normal leading-[0.92] tracking-[-0.06em] text-roam-text">Carrito</h1>
          <p className="mx-auto mt-6 max-w-xl font-inter text-sm leading-7 text-roam-secondary md:text-sm">Tus experiencias seleccionadas, listas para reservar juntas.</p>
        </div>
      </section>

      <section className="px-5 md:px-8">
        <div className="mx-auto flex max-w-[1120px] flex-col gap-4">
          {isEmpty ? (
            <div className="w-full max-w-xl mx-auto rounded-[28px] bg-white py-16 text-center" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#F8F7F4] text-roam-text">
                <ShoppingCart size={28} strokeWidth={1.8} />
              </div>
              <p className="mt-3 font-inter text-xl font-semibold text-roam-text">Tu carrito está vacío</p>
              <p className="mt-1 font-inter text-sm text-roam-muted">Toca el carrito en cualquier tour para agregarlo aquí.</p>
              <Link to="/do" className="inline-flex mt-5 h-11 items-center justify-center rounded-full px-6 font-inter text-sm font-semibold text-white" style={{ background: '#571AFF', boxShadow: '0 12px 28px rgba(87,26,255,0.28)' }}>Ver tours</Link>
            </div>
          ) : (
            <>
              {items.map((item) => (
                <div key={item.key} className="flex gap-4 rounded-[24px] bg-white p-4" style={{ border: '1px solid rgba(14,14,14,0.08)', boxShadow: '0 8px 24px rgba(14,14,14,0.06)' }}>
                  <Link to={item.path} className="flex-shrink-0">
                    <img src={item.cover_image_url} alt={item.venueName} className="w-24 h-24 rounded-2xl object-cover" />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <Link to={item.path}><h3 className="font-poppins font-semibold truncate" style={{ fontSize: '15px', color: '#141413' }}>{item.venueName}</h3></Link>
                        <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>{item.tierLabel} · {item.sub_category || ''}</p>
                      </div>
                      <button onClick={() => removeItem(item.key)} className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }} aria-label="Eliminar">
                        <Trash2 size={15} color="#72706A" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-3">
                        <button onClick={() => updateGroupSize(item.key, Math.max(1, item.groupSize - 1))} className="w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}><Minus size={14} color="#141413" /></button>
                        <span className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#141413' }}>{item.groupSize}</span>
                        <button onClick={() => updateGroupSize(item.key, item.groupSize + 1)} className="w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}><Plus size={14} color="#141413" /></button>
                        <span className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>personas</span>
                      </div>
                      <span className="font-poppins font-bold" style={{ fontSize: '16px', color: '#141413' }}>${item.total}</span>
                    </div>
                  </div>
                </div>
              ))}

              <div className="rounded-[24px] bg-white p-5 mt-2" style={{ border: '1px solid rgba(14,14,14,0.08)', boxShadow: '0 8px 24px rgba(14,14,14,0.06)' }}>
                <div className="flex items-center justify-between mb-4">
                  <span className="font-poppins font-semibold" style={{ fontSize: '16px', color: '#141413' }}>Total ({count} personas)</span>
                  <span className="font-poppins font-bold" style={{ fontSize: '22px', color: '#141413' }}>${total}</span>
                </div>
                <button onClick={() => setCheckout(true)} className="btn-primary">Reservar carrito</button>
              </div>
            </>
          )}
        </div>
      </section>

      {checkout && <CartCheckoutSheet onClose={() => setCheckout(false)} />}
    </div>
  );
}