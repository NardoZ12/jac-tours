import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, Clock, ArrowRight, Search } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import CategorySelector from '@/components/eat/CategorySelector';

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');

  useEffect(() => {
    base44.entities.BlogPost.filter({ status: 'published' }, '-published_date', 50)
      .then((data) => { setPosts(data || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const categories = ['all', ...Array.from(new Set(posts.map(p => p.category).filter(Boolean)))];

  const filtered = posts.filter(p => {
    const matchSearch = !search || (p.title || '').toLowerCase().includes(search.toLowerCase()) || (p.excerpt || '').toLowerCase().includes(search.toLowerCase());
    const matchCategory = category === 'all' || p.category === category;
    return matchSearch && matchCategory;
  });

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      {/* Hero */}
      <section className="px-5 pt-6 pb-2">
        <div className="mx-auto max-w-5xl">
          <p className="font-inter text-xs font-semibold uppercase tracking-[0.18em]" style={{ color: '#72706A' }}>Jac Tour and Transfers · Blog</p>
          <h1 className="mt-2 font-poppins font-bold" style={{ fontSize: '42px', lineHeight: 1, letterSpacing: '-0.04em', color: '#141413' }}>Guías de viaje y<br />experiencias en<br />Punta Cana</h1>
          <p className="mt-4 font-inter" style={{ fontSize: '15px', color: '#3A3A3A', lineHeight: 1.6, maxWidth: '460px' }}>
            Consejos, rutas, gastronomía y todo lo que necesitas saber para tu viaje a República Dominicana.
          </p>
        </div>
      </section>

      {/* Category nav */}
      <div className="px-5 mt-4">
        <CategorySelector active="blog" />
      </div>

      {/* Search + filter */}
      <section className="px-5 mt-6">
        <div className="mx-auto max-w-5xl">
          <div className="relative mb-4">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: '#72706A' }} />
            <input
              type="text"
              placeholder="Buscar artículos..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-2xl pl-12 pr-4 py-3 font-inter"
              style={{ background: '#FFFFFF', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '48px' }}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
            {categories.map(c => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className="flex-shrink-0 rounded-full px-4 py-2 font-inter font-semibold transition-all"
                style={{
                  fontSize: '13px',
                  background: category === c ? '#141413' : '#FFFFFF',
                  color: category === c ? '#FFFFFF' : '#141413',
                  border: '1.5px solid ' + (category === c ? '#141413' : '#E8E6DC'),
                }}
              >
                {c === 'all' ? 'Todos' : c}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Posts grid */}
      <section className="px-5 mt-6">
        <div className="mx-auto max-w-5xl">
          {loading ? (
            <div className="grid gap-5 sm:grid-cols-2">
              {[1, 2, 3, 4].map(i => <div key={i} className="skeleton" style={{ height: '320px', borderRadius: '24px' }} />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-poppins font-semibold" style={{ fontSize: '20px', color: '#141413' }}>No hay artículos todavía</p>
              <p className="mt-2 font-inter" style={{ fontSize: '14px', color: '#72706A' }}>Vuelve pronto, estamos preparando contenido para ti.</p>
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2">
              {filtered.map(post => (
                <Link
                  key={post.id}
                  to={`/blog/${post.slug || post.id}`}
                  className="group overflow-hidden rounded-[24px] bg-white press-shrink"
                  style={{ border: '1px solid rgba(14,14,14,0.08)', boxShadow: '0 12px 28px rgba(14,14,14,0.06)' }}
                >
                  <div className="relative h-[200px] overflow-hidden">
                    {post.cover_image_url ? (
                      <img src={post.cover_image_url} alt={post.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    ) : (
                      <div className="h-full w-full" style={{ background: 'linear-gradient(135deg, #571AFF, #B6F02D)' }} />
                    )}
                    {post.category && (
                      <span className="absolute top-3 left-3 rounded-full px-3 py-1.5 font-inter font-semibold" style={{ fontSize: '11px', background: 'rgba(255,255,255,0.92)', color: '#141413', backdropFilter: 'blur(8px)' }}>
                        {post.category}
                      </span>
                    )}
                  </div>
                  <div className="p-5">
                    <div className="flex items-center gap-3 mb-2 font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
                      {post.published_date && (
                        <span className="inline-flex items-center gap-1">
                          <CalendarDays size={13} />
                          {new Date(post.published_date).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </span>
                      )}
                      {post.reading_time_min && (
                        <span className="inline-flex items-center gap-1">
                          <Clock size={13} />
                          {post.reading_time_min} min
                        </span>
                      )}
                    </div>
                    <h2 className="font-poppins font-bold" style={{ fontSize: '20px', lineHeight: 1.2, color: '#141413' }}>{post.title}</h2>
                    {post.excerpt && <p className="mt-2 font-inter" style={{ fontSize: '14px', color: '#3A3A3A', lineHeight: 1.55 }}>{post.excerpt}</p>}
                    <span className="mt-4 inline-flex items-center gap-1 font-inter font-semibold" style={{ fontSize: '13px', color: '#571AFF' }}>
                      Leer más <ArrowRight size={15} />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}