import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowLeft, Heart, LogOut, MapPin, Sun } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import MyBookingsTab from '@/components/profile/MyBookingsTab';
import { findContentByIds } from '@/lib/contentTables';

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [venuesById, setVenuesById] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const u = await base44.auth.me().catch(() => null);
      setUser(u);
      if (u?.id) {
        setBookings([]);
      }
      setLoading(false);
    };
    load();
  }, []);

  if (loading) return <div className="min-h-screen" style={{ background: '#F8F7F4' }} />;

  const displayName = user?.full_name || 'Explorer';

  const handleSignOut = async () => {
    await base44.auth.logout('/');
  };

  return (
    <div className="min-h-screen px-5 pb-24 pt-10 md:px-8 md:pt-16" style={{ background: '#F8F7F4' }}>
      <div className="pointer-events-none fixed inset-0 opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)', maskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)' }} />

      <main className="relative mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-black/[0.06] bg-white/80 text-[#141413] shadow-[0_8px_22px_rgba(14,14,14,0.08)] backdrop-blur-xl transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#141413] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.16)]"
            aria-label="Go back"
          >
            <ArrowLeft size={18} />
          </button>
          <button
            type="button"
            onClick={handleSignOut}
            className="inline-flex items-center gap-2 rounded-full border border-black/[0.06] bg-white/80 px-4 py-3 font-inter text-sm font-semibold text-[#141413] shadow-[0_8px_22px_rgba(14,14,14,0.08)] backdrop-blur-xl transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#141413] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.16)]"
          >
            <LogOut size={16} />
            Sign out
          </button>
        </div>

        <section className="overflow-hidden rounded-[36px] border border-white/70 bg-white/78 p-5 shadow-[0_18px_44px_rgba(14,14,14,0.10),inset_0_1px_0_rgba(255,255,255,0.70)] backdrop-blur-[24px] md:p-8">
          <div className="text-center md:text-left">
            <div>
              <p className="mb-3 font-inter text-xs font-semibold uppercase tracking-[0.18em] text-[#72706A]">Profile</p>
              <h1 className="[font-family:'Libre_Baskerville',_serif] text-[55px] font-normal leading-[0.92] tracking-[-0.06em] text-[#0E0E0E] md:text-[72px]">
                {displayName}
              </h1>
              <p className="mt-5 max-w-xl font-inter text-sm leading-7 text-[#555550] md:text-base">
                {user?.email || 'Your Roam account'}
              </p>

              <div className="mt-6 flex flex-wrap justify-center gap-2 md:justify-start">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-black/[0.06] bg-[#F8F7F4] px-4 py-2 font-inter text-xs font-semibold text-[#555550]">
                  <MapPin size={13} /> {user?.city || 'Augsburg'}
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-black/[0.06] bg-[#F8F7F4] px-4 py-2 font-inter text-xs font-semibold text-[#555550]">
                  <Sun size={13} /> {user?.explorer_streak || 0} day streak
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-black/[0.06] bg-[#F8F7F4] px-4 py-2 font-inter text-xs font-semibold text-[#555550]">
                  <Heart size={13} /> Explorer
                </span>
              </div>

              <div className="mt-7 flex justify-center md:justify-start">
                <Link
                  to="/favourites"
                  className="inline-flex items-center gap-2 rounded-full bg-[#0E0E0E] px-5 py-3 font-inter text-sm font-semibold text-white shadow-[0_12px_28px_rgba(14,14,14,0.18)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:bg-[#571AFF] hover:shadow-[0_16px_34px_rgba(87,26,255,0.24)]"
                >
                  <Heart size={16} />
                  Saved places
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-8 rounded-[32px] border border-white/70 bg-white/78 p-5 shadow-[0_14px_34px_rgba(14,14,14,0.08)] backdrop-blur-[20px] md:p-7">
          <div className="mb-4 flex items-end justify-between gap-4">
            <div>
              <p className="font-inter text-xs font-semibold uppercase tracking-[0.18em] text-[#72706A]">Trips</p>
              <h2 className="mt-1 [font-family:'Libre_Baskerville',_serif] text-4xl font-normal tracking-[-0.05em] text-[#0E0E0E]">My bookings</h2>
            </div>
            <span className="rounded-full bg-[#F8F7F4] px-3 py-1.5 font-inter text-xs font-semibold text-[#555550]">{bookings.length}</span>
          </div>
          <MyBookingsTab bookings={bookings} venuesById={venuesById} />
        </section>
      </main>
    </div>
  );
}