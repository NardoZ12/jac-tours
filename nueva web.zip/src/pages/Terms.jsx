import { Link } from 'react-router-dom';

export default function Terms() {
  return (
    <main className="min-h-screen px-6 py-20" style={{ background: '#F8F7F4' }}>
      <div className="mx-auto max-w-3xl">
        <Link to="/" className="font-inter text-sm text-[#8A8780] hover:text-[#141413]">← Volver al inicio</Link>
        <h1 className="mt-8 [font-family:'Libre_Baskerville',_serif] text-5xl font-normal tracking-[-0.05em] text-[#141413]">Términos y condiciones</h1>
        <div className="mt-8 space-y-6 font-inter text-sm leading-7 text-[#5F5C56]">
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>1. Aceptación de los términos</h2>
            <p>Al reservar cualquier tour o traslado con Jac Tour and Transfers, el cliente acepta los presentes términos y condiciones en su totalidad.</p>
          </section>
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>2. Reservas y confirmación</h2>
            <p>Toda reserva está sujeta a disponibilidad. La confirmación se realiza al recibir el depósito del 30% o el pago total, según el servicio. El saldo restante se abona el día del servicio en efectivo o tarjeta.</p>
          </section>
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>3. Cancelaciones y reembolsos</h2>
            <p>Cancelaciones con más de 48 horas de anticipación: reembolso del 100%. Entre 24 y 48 horas: 50% de reembolso. Menos de 24 horas o no-show: sin reembolso. Las cancelaciones por clima extremo se reprograman sin costo.</p>
          </section>
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>4. Transporte y puntualidad</h2>
            <p>Los horarios de recogida se confirman el día anterior. El cliente debe estar listo 10 minutos antes. No nos hacemos responsables por retrasos causados por el cliente. Los traslados incluyen espera de 30 minutos tras la llegada del vuelo.</p>
          </section>
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>5. Responsabilidad</h2>
            <p>Jac Tour and Transfers actúa como operador de los servicios descritos. No nos hacemos responsables por incidentes derivados del comportamiento del cliente, condiciones climáticas, o decisiones de terceros proveedores durante las excursiones.</p>
          </section>
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>6. Datos personales</h2>
            <p>Los datos proporcionados se utilizan únicamente para gestionar la reserva y mejorar el servicio. Consulta nuestra <Link to="/privacy-policy" className="text-[#571AFF] underline">política de privacidad</Link> para más información.</p>
          </section>
          <section>
            <h2 className="font-poppins font-semibold text-[#141413]" style={{ fontSize: '16px' }}>7. Contacto</h2>
            <p>Para cualquier consulta o reclamación, contáctanos por WhatsApp al +1 (829) 302-6170 o al correo info@jactours.com.do.</p>
          </section>
        </div>
      </div>
    </main>
  );
}