import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, CalendarDays, Clock, Tag } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { base44 } from '@/api/base44Client';

export default function BlogPost() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.BlogPost.filter({ slug }, '-published_date', 1)
      .then((data) => {
        setPost(data?.[0] || null);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [slug]);

  if (loading) return <div className="min-h-screen" style={{ background: '#F8F7F4' }}><div className="skeleton w-full" style={{ height: '400px' }} /></div>;
  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#F8F7F4' }}>
        <div className="text-center">
          <h1 className="font-poppins font-bold" style={{ fontSize: '32px', color: '#141413' }}>Artículo no encontrado</h1>
          <Link to="/blog" className="mt-4 inline-flex h-11 items-center justify-center rounded-full bg-[#141413] px-6 font-inter text-sm font-semibold text-white">Volver al blog</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      {/* Hero image */}
      <div className="relative h-[300px] md:h-[420px] overflow-hidden">
        {post.cover_image_url && (
          <img src={post.cover_image_url} alt={post.title} className="absolute inset-0 h-full w-full object-cover" />
        )}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7), rgba(0,0,0,0.2))' }} />
        <button
          onClick={() => navigate(-1)}
          className="absolute top-12 left-5 z-10 w-10 h-10 flex items-center justify-center rounded-full"
          style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}
        >
          <ArrowLeft size={20} color="white" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 p-5 md:p-10">
          <div className="mx-auto max-w-3xl">
            {post.category && (
              <span className="inline-block rounded-full px-3 py-1.5 font-inter font-semibold mb-3" style={{ fontSize: '12px', background: 'rgba(255,255,255,0.92)', color: '#141413' }}>
                {post.category}
              </span>
            )}
            <h1 className="font-poppins font-bold text-white" style={{ fontSize: '32px', lineHeight: 1.1, letterSpacing: '-0.03em' }}>{post.title}</h1>
            <div className="flex items-center gap-4 mt-3 font-inter text-white" style={{ fontSize: '13px', opacity: 0.85 }}>
              {post.author && <span>Por {post.author}</span>}
              {post.published_date && (
                <span className="inline-flex items-center gap-1">
                  <CalendarDays size={14} />
                  {new Date(post.published_date).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}
                </span>
              )}
              {post.reading_time_min && (
                <span className="inline-flex items-center gap-1">
                  <Clock size={14} />
                  {post.reading_time_min} min de lectura
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <article className="px-5 mt-6">
        <div className="mx-auto max-w-3xl">
          {post.excerpt && (
            <p className="font-poppins font-semibold mb-5" style={{ fontSize: '18px', lineHeight: 1.5, color: '#3A3A3A' }}>{post.excerpt}</p>
          )}
          <div className="font-inter prose-content" style={{ fontSize: '16px', lineHeight: 1.75, color: '#141413' }}>
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </div>

          {/* SEO keywords */}
          {Array.isArray(post.seo_keywords) && post.seo_keywords.length > 0 && (
            <div className="mt-8 pt-6" style={{ borderTop: '1px solid #E8E6DC' }}>
              <div className="flex items-center gap-2 mb-3">
                <Tag size={15} style={{ color: '#72706A' }} />
                <span className="font-inter font-semibold" style={{ fontSize: '13px', color: '#72706A' }}>Etiquetas</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {post.seo_keywords.map(kw => (
                  <span key={kw} className="rounded-full px-3 py-1.5 font-inter font-semibold" style={{ fontSize: '12px', background: '#F2F1EE', color: '#3A3A3A' }}>{kw}</span>
                ))}
              </div>
            </div>
          )}

          <div className="mt-8">
            <Link to="/blog" className="inline-flex h-11 items-center justify-center rounded-full bg-[#141413] px-6 font-inter text-sm font-semibold text-white">
              ← Volver al blog
            </Link>
          </div>
        </div>
      </article>
    </div>
  );
}