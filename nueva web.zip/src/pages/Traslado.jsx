import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Car, Clock, Users, MapPin, Check, Navigation, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import Reveal from '@/components/ui/Reveal';
import TransferMapPicker from '@/components/traslado/TransferMapPicker';
import TimePicker from '@/components/traslado/TimePicker';

const VEHICLES = [
  { id: 'starex',   name: 'Starex',   minPax: 1,  maxPax: 6,  baseRate: 3.5,  rateAfter15: 2,   desc: '1 a 6 personas · aire acondicionado', image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/58d341a4b_generated_image.png' },
  { id: 'hiace',    name: 'Hiace',     minPax: 7,  maxPax: 11, baseRate: 4,    rateAfter15: 3,   desc: '7 a 11 personas · cómodo para grupos', image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/a8261d81c_generated_image.png' },
  { id: 'coaster',  name: 'Coaster',   minPax: 12, maxPax: 22, baseRate: 10,   rateAfter15: 4,   desc: '12 a 22 personas · ideal para grupos grandes', image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/24bd48c99_generated_image.png' },
  { id: 'universe', name: 'Universe',  minPax: 23, maxPax: 49, baseRate: 15,   rateAfter15: 6,   desc: '23 a 49 personas · autobús de lujo', image: 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/7ad834011_generated_image.png' },
];

function calcPrice(vehicle, km) {
  if (!km || km <= 0) return 0;
  if (km <= 15) return Math.round(km * vehicle.baseRate * 100) / 100;
  const extra = km - 15;
  return Math.round((15 * vehicle.baseRate + extra * vehicle.rateAfter15) * 100) / 100;
}

function genCode() {
  return 'TR' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

export default function Traslado() {
  const today = new Date();
  const [step, setStep] = useState(1);
  const [vehicle, setVehicle] = useState('starex');
  const [pickup, setPickup] = useState(null);
  const [destination, setDestination] = useState(null);
  const [date, setDate] = useState(null);
  const [showCal, setShowCal] = useState(false);
  const [time, setTime] = useState('10:00');
  const [passengers, setPassengers] = useState(2);
  const [notes, setNotes] = useState('');
  const [roundTrip, setRoundTrip] = useState(false);
  const [distance, setDistance] = useState(0);

  const [submitting, setSubmitting] = useState(false);
  const [confirmation, setConfirmation] = useState(null);

  const selectedVehicle = VEHICLES.find((v) => v.id === vehicle);
  const oneWay = calcPrice(selectedVehicle, distance);
  const total = oneWay * (roundTrip ? 2 : 1);

  const canSubmit = pickup && date && destination && distance > 0;

  // Clamp passengers when vehicle changes
  useEffect(() => {
    setPassengers((p) => Math.min(Math.max(p, selectedVehicle.minPax), selectedVehicle.maxPax));
  }, [vehicle, selectedVehicle.minPax, selectedVehicle.maxPax]);

  const submit = () => {
    if (!canSubmit) return;
    setSubmitting(true);
    setTimeout(() => {
      setConfirmation({
        code: genCode(),
        vehicle: selectedVehicle,
        pickup: pickup.name,
        destination: destination.name,
        date: format(date, 'EEE, MMM d'),
        time,
        passengers,
        km: distance,
        roundTrip,
        total,
      });
      setSubmitting(false);
    }, 700);
  };

  const reset = () => {
    setConfirmation(null);
    setDate(null);
    setPickup(null);
  };

  if (confirmation) {
    return (
      <div className="min-h-screen" style={{ background: '#F8F7F4' }}>
        <div className="mx-auto max-w-2xl px-5 md:px-8 py-16 md:py-24">
          <div className="rounded-[28px] bg-white p-8 text-center" style={{ boxShadow: '0 18px 44px rgba(14,14,14,0.10)' }}>
            <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4" style={{ background: '#0E0E0E' }}>
              <Check size={30} strokeWidth={3} color="#FFFFFF" />
            </div>
            <p className="font-inter font-semibold uppercase tracking-wide" style={{ fontSize: '12px', color: '#571AFF', letterSpacing: '0.08em' }}>Traslado confirmado</p>
            <h1 className="font-poppins font-bold mt-1" style={{ fontSize: '26px', color: '#141413' }}>¡Todo listo!</h1>
            <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A' }}>Código de confirmación</p>
            <p className="font-poppins font-bold mt-0.5" style={{ fontSize: '22px', color: '#141413', letterSpacing: '0.04em' }}>{confirmation.code}</p>

            <div className="mt-6 rounded-2xl p-5 text-left" style={{ background: '#F0EFE9' }}>
              <div className="space-y-3">
                <Row label="Vehículo" value={confirmation.vehicle.name} />
                <Row label="Recogida" value={confirmation.pickup} />
                <Row label="Destino" value={confirmation.destination} />
                <Row label="Fecha" value={confirmation.date} />
                <Row label="Hora" value={confirmation.time} />
                <Row label="Pasajeros" value={`${confirmation.passengers}`} />
                <Row label="Distancia" value={`${confirmation.km} KM`} />
                <Row label="Tipo" value={confirmation.roundTrip ? 'Ida y vuelta' : 'Solo ida'} />
                <div className="flex items-center justify-between pt-3" style={{ borderTop: '1px solid #E8E6DC' }}>
                  <span className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#141413' }}>Total</span>
                  <span className="font-poppins font-bold" style={{ fontSize: '18px', color: '#141413' }}>${confirmation.total} USD</span>
                </div>
              </div>
            </div>

            <p className="font-inter mt-4" style={{ fontSize: '12px', color: '#72706A' }}>
              Te enviaremos un recordatorio antes de tu traslado. Conductor asignado 24h antes.
            </p>
            <button onClick={reset} className="btn-primary mt-6">Reservar otro traslado</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: '#F8F7F4' }}>
      {/* Hero */}
      <section className="relative overflow-hidden" style={{ minHeight: '460px' }}>
        <img
          src="https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/133c285b5_generated_image.png"
          alt="Chofer recogiendo clientes en el aeropuerto de Punta Cana"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(10,20,40,0.25) 0%, rgba(10,20,40,0.45) 100%)' }} />
        <div className="relative mx-auto max-w-3xl px-5 md:px-8 py-16 md:py-24 flex flex-col items-center text-center">
          <motion.div
            className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 mb-5"
            style={{ background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.25)' }}
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}>
            <Navigation size={14} color="#FFFFFF" />
            <span className="font-inter text-white font-semibold" style={{ fontSize: '12px', letterSpacing: '0.04em' }}>Servicio privado de transporte</span>
          </motion.div>
          <motion.div
            className="rounded-[28px] px-6 py-7 md:px-10 md:py-9"
            style={{
              background: 'rgba(255,255,255,0.14)',
              backdropFilter: 'blur(20px) saturate(160%)',
              WebkitBackdropFilter: 'blur(20px) saturate(160%)',
              border: '1px solid rgba(255,255,255,0.30)',
              boxShadow: '0 12px 40px rgba(10,20,40,0.25), inset 0 1px 0 rgba(255,255,255,0.35)',
            }}
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}>
            <h1
              className="font-poppins font-normal text-white"
              style={{ fontSize: 'clamp(32px, 6vw, 56px)', lineHeight: 1.05, letterSpacing: '-0.04em', textShadow: '0 2px 12px rgba(0,0,0,0.3)' }}>
              Reserva tu traslado
            </h1>
            <p
              className="mx-auto mt-3 font-inter text-white"
              style={{ maxWidth: '460px', fontSize: '14px', lineHeight: 1.6, textShadow: '0 1px 8px rgba(0,0,0,0.3)' }}>
              Transporte privado y seguro entre el aeropuerto, tu hotel y cualquier destino de la República Dominicana. Conductores profesionales, vehículos con aire acondicionado.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="mx-auto max-w-5xl px-5 md:px-8 py-12 md:py-16">
        {/* Step 1: Vehicle selection */}
        {step === 1 && (
          <>
            <Reveal><h2 className="font-poppins font-bold mb-1" style={{ fontSize: '24px', color: '#141413' }}>Elige tu vehículo</h2></Reveal>
            <Reveal><p className="font-inter mb-4" style={{ fontSize: '14px', color: '#72706A' }}>Selecciona el vehículo que mejor se adapte a tu grupo para calcular la distancia y el precio.</p></Reveal>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-10">
              {VEHICLES.map((v, i) => {
                const active = vehicle === v.id;
                return (
                  <motion.button
                    key={v.id}
                    onClick={() => { setVehicle(v.id); setStep(2); setTimeout(() => document.getElementById('traslado-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100); }}
                    className="text-left rounded-2xl overflow-hidden transition-all press-shrink"
                    style={{
                      background: '#FFFFFF',
                      border: `2px solid ${active ? '#571AFF' : '#E8E6DC'}`,
                      boxShadow: active
                        ? '0 12px 32px rgba(31, 90, 130, 0.40), 0 4px 12px rgba(45, 106, 143, 0.25)'
                        : '0 6px 20px rgba(31, 90, 130, 0.14), 0 2px 8px rgba(14,14,14,0.04)',
                    }}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.5, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                    whileHover={{ y: -6 }}
                  >
                    <div className="relative h-36 w-full overflow-hidden">
                      <img src={v.image} alt={v.name} className="w-full h-full object-cover" />
                      {active && (
                        <div className="absolute top-3 right-3 w-7 h-7 rounded-full flex items-center justify-center" style={{ background: '#571AFF' }}>
                          <Check size={16} color="#FFFFFF" strokeWidth={3} />
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-poppins font-bold" style={{ fontSize: '17px', color: '#141413' }}>{v.name}</h3>
                        <Car size={20} color={active ? '#571AFF' : '#72706A'} />
                      </div>
                      <div className="flex items-center gap-3 font-inter" style={{ fontSize: '12px', color: '#72706A' }}>
                        <span className="flex items-center gap-1"><Users size={12} />{v.minPax}-{v.maxPax}</span>
                      </div>
                      <p className="font-inter mt-1.5" style={{ fontSize: '12px', color: '#72706A', lineHeight: 1.5 }}>{v.desc}</p>
                      <div className="mt-3 pt-3" style={{ borderTop: '1px solid #F0EFE9' }}>
                        <p className="font-poppins font-bold" style={{ fontSize: '18px', color: '#141413' }}>${v.baseRate}<span className="font-inter text-xs font-normal" style={{ color: '#72706A' }}> /KM (0-15)</span></p>
                        <p className="font-inter mt-0.5" style={{ fontSize: '11px', color: '#72706A' }}>Después: ${v.rateAfter15}/KM</p>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </>
        )}

        {/* Step 2: Booking form with distance calculation */}
        {step === 2 && (
        <Reveal>
        <div id="traslado-form" className="rounded-[28px] bg-white p-6 md:p-8 scroll-mt-20" style={{ boxShadow: '0 18px 44px rgba(14,14,14,0.08)' }}>
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <button onClick={() => setStep(1)} className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: '#F0EFE9' }}>
                <ArrowLeft size={16} color="#141413" />
              </button>
              <div>
                <h2 className="font-poppins font-bold" style={{ fontSize: '22px', color: '#141413' }}>Detalles del traslado</h2>
                <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Vehículo: <span className="font-semibold" style={{ color: '#571AFF' }}>{selectedVehicle.name}</span></p>
              </div>
            </div>
            <img src={selectedVehicle.image} alt={selectedVehicle.name} className="w-16 h-16 rounded-xl object-cover" style={{ border: '1.5px solid #E8E6DC' }} />
          </div>

          {/* Map-based location picker */}
          <div className="mb-5">
            <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>¿Desde dónde y a dónde?</label>
            <TransferMapPicker
              onPickupChange={setPickup}
              onDestinationChange={setDestination}
              onDistanceChange={setDistance}
            />
            <p className="font-inter mt-2" style={{ fontSize: '11px', color: '#72706A' }}>Tarifa: ${selectedVehicle.baseRate}/KM (0-15) · ${selectedVehicle.rateAfter15}/KM extra</p>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Fecha</label>
              <button
                onClick={() => setShowCal((s) => !s)}
                className="w-full rounded-2xl px-4 py-3 flex items-center gap-2 text-left"
                style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', minHeight: '52px' }}
              >
                <Clock size={16} color="#571AFF" />
                <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: '#141413' }}>{date ? format(date, 'EEE, MMM d') : 'Selecciona fecha'}</span>
              </button>
              {showCal && (
                <div className="mt-2 rounded-2xl" style={{ background: '#FFF', border: '1.5px solid #E8E6DC' }}>
                  <div className="flex justify-center">
                    <Calendar mode="single" selected={date || undefined} onSelect={(d) => { if (d) { setDate(d); setShowCal(false); } }} disabled={{ before: today }} numberOfMonths={1} />
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Hora de recogida</label>
              <TimePicker value={time} onChange={setTime} />
            </div>

            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Pasajeros</label>
              <div className="flex items-center gap-3 rounded-2xl px-4 py-2" style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', minHeight: '52px' }}>
                <button onClick={() => setPassengers((p) => Math.max(1, p - 1))} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#FFFFFF' }}><Users size={14} color="#141413" /></button>
                <span className="font-poppins font-bold flex-1 text-center" style={{ fontSize: '16px', color: '#141413' }}>{passengers}</span>
                <button onClick={() => setPassengers((p) => Math.min(selectedVehicle.maxPax, p + 1))} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#FFFFFF' }}><Users size={14} color="#141413" /></button>
              </div>
              <p className="font-inter mt-1" style={{ fontSize: '11px', color: '#72706A' }}>Capacidad {selectedVehicle.minPax}-{selectedVehicle.maxPax} personas</p>
            </div>

            <div>
              <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Tipo de viaje</label>
              <div className="flex gap-2">
                <button onClick={() => setRoundTrip(false)} className="flex-1 rounded-2xl py-3 font-poppins font-semibold" style={{ background: !roundTrip ? '#141413' : '#F0EFE9', color: !roundTrip ? '#FFF' : '#141413', border: '1.5px solid ' + (!roundTrip ? '#141413' : '#E8E6DC'), fontSize: '13px' }}>Solo ida</button>
                <button onClick={() => setRoundTrip(true)} className="flex-1 rounded-2xl py-3 font-poppins font-semibold" style={{ background: roundTrip ? '#141413' : '#F0EFE9', color: roundTrip ? '#FFF' : '#141413', border: '1.5px solid ' + (roundTrip ? '#141413' : '#E8E6DC'), fontSize: '13px' }}>Ida y vuelta</button>
              </div>
            </div>
          </div>

          <div className="mt-5">
            <label className="font-inter block mb-2" style={{ fontSize: '13px', color: '#72706A' }}>Notas (opcional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Número de vuelo, equipaje extra, silla infantil, etc."
              className="w-full rounded-2xl px-4 py-3 font-inter"
              style={{ background: '#F0EFE9', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413', minHeight: '70px' }}
            />
          </div>

          {/* Summary */}
          <div className="mt-6 rounded-2xl p-5 flex items-center justify-between" style={{ background: '#F0EFE9' }}>
            <div>
              <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{selectedVehicle.name} · {roundTrip ? 'Ida y vuelta' : 'Solo ida'}</p>
              <p className="font-poppins font-bold" style={{ fontSize: '24px', color: '#141413' }}>${total} USD</p>
            </div>
            <button onClick={submit} disabled={!canSubmit || submitting} className="btn-primary" style={{ width: 'auto', padding: '0 32px' }}>
              {submitting ? 'Reservando...' : <>Confirmar traslado <ArrowLeft size={16} className="rotate-180 ml-1 inline" /></>}
            </button>
          </div>
          {!canSubmit && <p className="font-inter text-center mt-2" style={{ fontSize: '12px', color: '#72706A' }}>Selecciona recogida y fecha para continuar</p>}
        </div>
        </Reveal>
        )}

        {/* Features */}
        <div className="grid gap-4 sm:grid-cols-3 mt-12">
          {[
            { Icon: Check, title: 'Conductores profesionales', desc: 'Licenciados y bilingües' },
            { Icon: Clock, title: 'Puntualidad garantizada', desc: 'Monitoreo de vuelos en tiempo real' },
            { Icon: MapPin, title: 'Cobertura nacional', desc: 'Todo Punta Cana y República Dominicana' },
          ].map(({ Icon, title, desc }, i) => (
            <Reveal key={title} delay={i * 0.1}>
            <motion.div
              className="rounded-2xl bg-white p-5"
              style={{ boxShadow: '0 4px 14px rgba(14,14,14,0.05)' }}
              whileHover={{ y: -6, boxShadow: '0 14px 28px rgba(87,26,255,0.14)' }}
              transition={{ duration: 0.25 }}>
              <Icon size={22} color="#571AFF" />
              <h3 className="font-poppins font-bold mt-2" style={{ fontSize: '15px', color: '#141413' }}>{title}</h3>
              <p className="font-inter mt-1" style={{ fontSize: '13px', color: '#72706A', lineHeight: 1.5 }}>{desc}</p>
            </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{label}</span>
      <span className="font-poppins font-semibold text-right" style={{ fontSize: '14px', color: '#141413' }}>{value}</span>
    </div>
  );
}