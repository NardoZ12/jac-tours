import { Link } from 'react-router-dom';

export default function AccessibilityStatement() {
  return (
    <main className="min-h-screen px-6 py-20" style={{ background: '#F8F7F4' }}>
      <div className="mx-auto max-w-3xl">
        <Link to="/" className="font-inter text-sm text-[#8A8780] hover:text-[#141413]">← Back home</Link>
        <h1 className="mt-8 [font-family:'Libre_Baskerville',_serif] text-5xl font-normal tracking-[-0.05em] text-[#141413]">Accessibility Statement</h1>
        <div className="mt-8 space-y-6 font-inter text-sm leading-7 text-[#5F5C56]">
          <p>Roam aims to provide a clear, readable, and navigable experience across devices, including responsive layouts, readable contrast, and keyboard-friendly links.</p>
          <p>We continue improving accessibility as the product evolves and welcome feedback about barriers that make planning, browsing, or booking harder to use.</p>
          <p>If you experience an accessibility issue, please contact us through the app with the page, device, and description of the problem.</p>
        </div>
      </div>
    </main>
  );
}