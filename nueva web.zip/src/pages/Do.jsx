import { useState, useEffect } from 'react';
import { Search, X, SlidersHorizontal, List, Map } from 'lucide-react';
import { listContentByType } from '@/lib/contentTables';
import SkeletonCard from '@/components/ui/SkeletonCard';
import EatFilterSheet from '@/components/eat/EatFilterSheet';
import ExperienceShowcaseCard from '@/components/do/ExperienceShowcaseCard';
import PlannerInternalFilters from '@/components/trip/PlannerInternalFilters';
import RestaurantMapView from '@/components/eat/RestaurantMapView';

const FILTERS = ['All', 'Adventure', 'Beach', 'Tours', 'Nightlife', 'Water', 'Culture', 'Outdoor'];
const DEFAULT_FILTERS = { cuisines: [], vibes: [], prices: [], openNow: false, withDeals: false, sort: 'rating' };

const DEMO_EXPERIENCES = [
{ id: 'demo-fuggerei', is_demo: true, name: 'Fuggerei Twilight Walk', sub_category: 'Historic Sight', type: 'Sights', neighborhood: 'Fuggerei', price_label: '€', avg_rating: 4.9, duration: '90 min', tags: ['Historic', 'Culture', 'Old Town'], short_description: 'A golden-hour walk through the world’s oldest social housing complex and its quiet lanes.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/8dcfe9451_generated_image.png' },
{ id: 'demo-rathaus', is_demo: true, name: 'Golden Hall Stories', sub_category: 'Museum Tour', type: 'Museums', neighborhood: 'Rathausplatz', price_label: '€€', avg_rating: 4.8, duration: '75 min', tags: ['Architecture', 'Museum', 'Guided'], short_description: 'An editorial-style tour through frescoes, civic legends, and Augsburg’s grand ceremonial rooms.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/304fef343_generated_image.png' },
{ id: 'demo-canal', is_demo: true, name: 'Lech Canal Ride', sub_category: 'Outdoor Route', type: 'Outdoor', neighborhood: 'Lech Quarter', price_label: '€€', avg_rating: 4.7, duration: '2 hrs', tags: ['Outdoor', 'Cycling', 'Water'], short_description: 'A relaxed bike route following narrow canals, bridges, and hidden courtyards near the old town.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/9349fa2d2_generated_image.png' },
{ id: 'demo-puppet', is_demo: true, name: 'Puppet Theatre Backstage', sub_category: 'Cultural Classic', type: 'Culture', neighborhood: 'Altstadt', price_label: '€€', avg_rating: 4.8, duration: '60 min', tags: ['Culture', 'Family', 'Theatre'], short_description: 'A playful look behind Augsburg’s beloved marionette stage with character rooms and craft stories.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ee792e46d_generated_image.png' },
{ id: 'demo-market', is_demo: true, name: 'Stadtmarkt Taste Trail', sub_category: 'Food Workshop', type: 'Workshops', neighborhood: 'Stadtmarkt', price_label: '€€', avg_rating: 4.6, duration: '2 hrs', tags: ['Food', 'Workshop', 'Local'], short_description: 'A market-led tasting route with seasonal bites, quick demos, and local makers along the stalls.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/7047a4b9b_generated_image.png' },
{ id: 'demo-night', is_demo: true, name: 'Neon Bar Crawl', sub_category: 'Nightlife Walk', type: 'Nightlife', neighborhood: 'Maximilianstraße', price_label: '€€€', avg_rating: 4.7, duration: '3 hrs', tags: ['Nightlife', 'Cocktails', 'Social'], short_description: 'A polished evening path through design bars, tucked-away lounges, and late-night city energy.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/57dbd100a_generated_image.png' },
{ id: 'demo-botanic', is_demo: true, name: 'Botanical Morning', sub_category: 'Garden Escape', type: 'Outdoor', neighborhood: 'Botanical Garden', price_label: '€', avg_rating: 4.6, duration: '80 min', tags: ['Outdoor', 'Calm', 'Family'], short_description: 'A slow morning among glasshouses, quiet paths, tropical plants, and soft city-reset moments.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/e1ceffd92_generated_image.png' },
{ id: 'demo-textile', is_demo: true, name: 'Textile District Studio', sub_category: 'Creative Workshop', type: 'Workshops', neighborhood: 'Textilviertel', price_label: '€€', avg_rating: 4.8, duration: '2.5 hrs', tags: ['Workshop', 'Design', 'Hands-on'], short_description: 'A hands-on design session inspired by Augsburg’s textile heritage, patterns, and old factory halls.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/2dc3d1fa7_generated_image.png' },
{ id: 'demo-zoo', is_demo: true, name: 'Family Zoo Loop', sub_category: 'Family Day', type: 'Family', neighborhood: 'Siebentischwald', price_label: '€€', avg_rating: 4.5, duration: 'Half day', tags: ['Family', 'Outdoor', 'Animals'], short_description: 'A soft-paced family route with animal stops, green breaks, and easy lunch spots nearby.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/de63f906e_generated_image.png' },
{ id: 'demo-roman', is_demo: true, name: 'Roman Augsburg Walk', sub_category: 'History Tour', type: 'Tours', neighborhood: 'Innenstadt', price_label: '€€', avg_rating: 4.7, duration: '100 min', tags: ['Tours', 'History', 'Culture'], short_description: 'A guided route tracing Roman foundations, old walls, and the city’s layered past under modern streets.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/60aed366e_generated_image.png' },
{ id: 'demo-forest', is_demo: true, name: 'Siebentisch Forest Reset', sub_category: 'Nature Walk', type: 'Outdoor', neighborhood: 'Siebentischwald', price_label: '€', avg_rating: 4.9, duration: '2 hrs', tags: ['Outdoor', 'Calm', 'Walk'], short_description: 'A peaceful forest loop with river views, quiet benches, and low-effort nature just outside the center.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/894fe3631_generated_image.png' },
{ id: 'demo-gallery', is_demo: true, name: 'Gallery After Hours', sub_category: 'Art Night', type: 'Culture', neighborhood: 'Dom Viertel', price_label: '€€', avg_rating: 4.8, duration: '90 min', tags: ['Culture', 'Art', 'Nightlife'], short_description: 'A private-feeling evening through contemporary rooms, local artists, and a final glass of wine.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/7a58656c3_generated_image.png' }];


export default function Do() {
  const urlParams = new URLSearchParams(window.location.search);
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [parallaxY, setParallaxY] = useState(0);
  const [compactProgress, setCompactProgress] = useState(0);
  const [startDate, setStartDate] = useState(urlParams.get('start_date') || '');
  const [endDate, setEndDate] = useState(urlParams.get('end_date') || '');
  const [people, setPeople] = useState(Number(urlParams.get('people')) || 2);
  const [showFilterSheet, setShowFilterSheet] = useState(false);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [view, setView] = useState('list');

  useEffect(() => {
    listContentByType('do', '-avg_rating', 20).
    then((v) => {setVenues(v || []);setLoading(false);}).
    catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    let frame = null;
    const update = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        setParallaxY(window.innerWidth >= 768 ? scrollY : 0);
        setCompactProgress(window.innerWidth >= 768 ? Math.min(1, Math.max(0, scrollY / 260)) : 0);
        frame = null;
      });
    };
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    return () => {
      window.removeEventListener('scroll', update);
      window.removeEventListener('resize', update);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const advancedCount = filters.cuisines.length + filters.vibes.length + filters.prices.length + (filters.openNow ? 1 : 0) + (filters.withDeals ? 1 : 0);
  const priceLevel = (venue) => venue.price_range || String(venue.price_label || '').length || 1;
  const experiences = venues;
  const filtered = experiences.filter((venue) => {
    const query = search.toLowerCase();
    const tags = [...(venue.tags || []), ...(venue.highlights || []), venue.type, venue.sub_category].filter(Boolean);
    if (search && !venue.name.toLowerCase().includes(query) && !venue.sub_category?.toLowerCase().includes(query) && !venue.neighborhood?.toLowerCase().includes(query)) return false;
    if (activeFilter !== 'All' && !tags.includes(activeFilter)) return false;
    if (filters.cuisines.length && !filters.cuisines.some((item) => tags.includes(item))) return false;
    if (filters.vibes.length && !filters.vibes.some((item) => tags.includes(item))) return false;
    if (filters.prices.length && !filters.prices.includes(priceLevel(venue))) return false;
    if (filters.openNow && !venue.duration) return false;
    if (filters.withDeals && priceLevel(venue) > 1) return false;
    return true;
  }).sort((a, b) => {
    if (filters.sort === 'price_low') return priceLevel(a) - priceLevel(b);
    if (filters.sort === 'price_high') return priceLevel(b) - priceLevel(a);
    if (filters.sort === 'trending') return String(b.duration || '').length - String(a.duration || '').length;
    return Number(b.avg_rating || b.rating || 0) - Number(a.avg_rating || a.rating || 0);
  });

  return (
    <div className="relative min-h-screen pb-24">
      <img src="https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/e8d333244_fondoexcursiones.jpg" alt="" aria-hidden="true" className="fixed inset-0 h-full w-full object-cover" style={{ zIndex: 0 }} />
      <div className="fixed inset-0" style={{ background: 'linear-gradient(180deg, rgba(248,247,244,0.55) 0%, rgba(248,247,244,0.45) 40%, rgba(248,247,244,0.78) 100%)', zIndex: 0 }} />
      <div className="relative" style={{ zIndex: 1 }}>
      <section className="relative px-5 pt-16 pb-8 md:px-8 md:pt-24">
        <div className="relative mx-auto max-w-7xl">
          <div className="mx-auto mb-8 max-w-7xl text-center">
            <h1 className="[font-family:'Libre_Baskerville',_serif] text-[55px] font-normal leading-[0.92] tracking-[-0.06em] text-roam-text">Nuestros Tours</h1>
            <p className="mx-auto mt-6 max-w-xl font-inter text-sm leading-7 text-roam-secondary md:text-sm">Descubre nuestras excursiones y experiencias en Punta Cana y toda la República Dominicana. Reserva tu tour en modalidad Privada o VIP.</p>
          </div>

          <div className="planner-filter-shell sticky top-24 z-[10000] mx-auto w-full transition-all duration-300 ease-out md:static lg:sticky lg:w-auto" style={{ width: window.innerWidth >= 768 && window.innerWidth < 1024 ? undefined : `${100 - compactProgress * 28}%` }}>
            <div className="rounded-full border border-white/70 bg-white p-1.5 shadow-[0_8px_22px_rgba(0,0,0,0.10),inset_0_1px_0_rgba(255,255,255,0.65)] backdrop-blur-[20px] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(0,0,0,0.14),inset_0_1px_0_rgba(255,255,255,0.75)]">
              <div className="flex min-w-0 flex-col gap-3 md:flex-row md:flex-nowrap md:items-center md:justify-between">
                <div className="flex min-h-[54px] min-w-0 flex-1 items-center gap-3 rounded-full border border-black/5 bg-[#F8F7F4]/55 px-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:border-[#571AFF]/30 hover:bg-[#F8F7F4] hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.85)]">
                  <Search size={18} color="#888580" />
                  <input type="text" placeholder="Search sights, tours, activities..." value={search} onChange={(e) => setSearch(e.target.value)} className="min-w-0 flex-1 bg-transparent font-inter text-sm outline-none" style={{ color: '#141413' }} />
                  {search && <button type="button" onClick={() => setSearch('')} aria-label="Clear search" className="flex h-7 w-7 items-center justify-center rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-[0_8px_18px_rgba(14,14,14,0.12)]" style={{ background: '#FFFFFF' }}><X size={13} color="#72706A" /></button>}
                </div>
                <PlannerInternalFilters startDate={startDate} endDate={endDate} people={people} onStartDateChange={setStartDate} onEndDateChange={setEndDate} onPeopleChange={setPeople} />
                <div className="flex shrink-0 items-center gap-2">
                  <button type="button" onClick={() => setShowFilterSheet(true)} aria-label="Open experience filters" className={`relative flex h-12 w-12 items-center justify-center rounded-full border border-black/5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:scale-105 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.24)] ${advancedCount > 0 ? 'bg-[#571AFF] text-white' : 'bg-[#F8F7F4]/55 text-[#141413]'}`}>
                    <SlidersHorizontal size={18} color="currentColor" />
                    {advancedCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full px-1 font-inter text-[12px] font-bold text-white" style={{ background: '#0E0E0E', border: '2px solid #FFFFFF' }}>{advancedCount}</span>}
                  </button>
                  <button type="button" aria-label={view === 'map' ? 'Show experience list' : 'Show experience map'} onClick={() => setView(view === 'map' ? 'list' : 'map')} className={`flex h-12 w-12 items-center justify-center rounded-full border border-black/5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:scale-105 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.24)] ${view === 'map' ? 'bg-[#571AFF] text-white' : 'bg-[#F8F7F4]/55 text-[#141413]'}`}>{view === 'map' ? <List size={18} color="currentColor" /> : <Map size={18} color="currentColor" />}</button>
                </div>
              </div>
            </div>
          </div>

          <div className="-mx-5 mt-5 flex gap-2 overflow-x-auto px-5 pb-1 scrollbar-hide md:ml-0 md:mr-[-0.5rem] md:max-w-7xl md:justify-start md:pl-0 md:pr-8 lg:mx-auto lg:mr-auto lg:justify-center lg:pr-0">
            {FILTERS.map((filter) =>
            <button key={filter} onClick={() => setActiveFilter(filter)} className={`flex-shrink-0 rounded-full px-4 py-2.5 font-inter text-xs font-semibold transition-colors hover:bg-[#571AFF] hover:text-white md:px-3 lg:px-4 ${activeFilter === filter ? 'bg-[#571AFF] text-white' : 'bg-white text-[#555550]'}`} style={{ border: '1px solid rgba(14,14,14,0.08)' }}>{filter}</button>
            )}
          </div>
        </div>
      </section>

      {view === 'map' ? <RestaurantMapView restaurants={filtered} loading={loading} category="do" label="experiences" pathPrefix="/place" /> :
      <section className="px-5 md:px-8">
        <div className="mx-auto grid max-w-7xl gap-5 md:grid-cols-2 lg:grid-cols-3">
          {loading ? [0, 1, 2].map((i) => <SkeletonCard key={i} />) : filtered.length === 0 ?
          <div className="rounded-[28px] bg-white py-16 text-center md:col-span-2 lg:col-span-3" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
              
              <p className="mt-3 text-xl text-roam-text [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]">No experiences found</p>
              <p className="mt-1 font-inter text-sm text-roam-muted">Try widening your search</p>
            </div> :
          filtered.map((venue, index) => {
            const isCenterColumn = index % 3 === 1;
            const isTablet = window.innerWidth >= 768 && window.innerWidth < 1024;
            const offset = isTablet ? 0 : -parallaxY * (isCenterColumn ? 0.006 : 0.07);
            return (
              <div key={venue.id} className="will-change-transform" style={{ transform: `translateY(${offset}px)` }}>
                  <ExperienceShowcaseCard venue={venue} />
                </div>);

          })}
        </div>
      </section>
      }

      {showFilterSheet && <EatFilterSheet category="do" initial={filters} onApply={setFilters} onClose={() => setShowFilterSheet(false)} />}
      </div>
    </div>);

}