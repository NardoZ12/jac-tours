import { useState, useEffect } from 'react';
import { Search, X, SlidersHorizontal, List, Map } from 'lucide-react';
import { listContentByType } from '@/lib/contentTables';
import SkeletonCard from '@/components/ui/SkeletonCard';
import EatFilterSheet from '@/components/eat/EatFilterSheet';
import HotelShowcaseCard from '@/components/stay/HotelShowcaseCard';
import PlannerInternalFilters from '@/components/trip/PlannerInternalFilters';
import RestaurantMapView from '@/components/eat/RestaurantMapView';

const FILTERS = ['Under €250', 'Boutique', '5-star', 'With pool', 'Breakfast', 'Old Town', 'Rooftop', 'Romantic'];
const DEFAULT_FILTERS = { cuisines: [], vibes: [], prices: [], openNow: false, withDeals: false, sort: 'rating' };

const DEMO_HOTELS = [
{ id: 'demo-maison', is_demo: true, name: 'Maison Altstadt', address: 'Karolinenstraße 12', price: '€€€', rating: 4.8, sub_category: 'Design Hotel', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/bd01b14b3_generated_image.png', tags: ['Boutique', 'Old Town'] },
{ id: 'demo-garden', is_demo: true, name: 'Garden Suite', address: 'Maximilianstraße 44', price: '€€€€', rating: 4.9, sub_category: '5-star Stay', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/186e462e7_generated_image.png', tags: ['5-star', 'Romantic'] },
{ id: 'demo-river', is_demo: true, name: 'River House', address: 'Lechviertel 7', price: '€€', rating: 4.7, sub_category: 'Boutique Rooms', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/c8089fceb_generated_image.png', tags: ['Boutique', 'Under €250'] },
{ id: 'demo-rooftop', is_demo: true, name: 'Rooftop Atelier', address: 'Rathausplatz 3', price: '€€€', rating: 4.6, sub_category: 'Skyline Hotel', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ed140582b_generated_image.png', tags: ['Rooftop', 'Breakfast'] },
{ id: 'demo-velvet', is_demo: true, name: 'Velvet Residence', address: 'Fuggerstraße 18', price: '€€€', rating: 4.8, sub_category: 'Soft Luxury', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/58a0377f5_generated_image.png', tags: ['Romantic', 'Boutique'] },
{ id: 'demo-cloud', is_demo: true, name: 'Cloud Nine Hotel', address: 'Annstraße 9', price: '€€€€', rating: 4.9, sub_category: 'Spa Hotel', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/9c99ca161_generated_image.png', tags: ['5-star', 'With pool'] },
{ id: 'demo-linen', is_demo: true, name: 'The Linen House', address: 'Stadtmarkt 21', price: '€€', rating: 4.6, sub_category: 'Quiet Stay', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/c298a0168_generated_image.png', tags: ['Under €250', 'Breakfast'] },
{ id: 'demo-arcade', is_demo: true, name: 'Arcade Rooms', address: 'Jakoberstraße 5', price: '€€€', rating: 4.7, sub_category: 'Historic Rooms', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/d69954d1a_generated_image.png', tags: ['Old Town', 'Boutique'] },
{ id: 'demo-courtyard', is_demo: true, name: 'Courtyard Stay', address: 'Dom Viertel 14', price: '€€€', rating: 4.8, sub_category: 'Courtyard Hotel', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/2386f7804_generated_image.png', tags: ['Breakfast', 'Romantic'] },
{ id: 'demo-terra', is_demo: true, name: 'Terra Boutique', address: 'Pfersee 28', price: '€€', rating: 4.5, sub_category: 'Nature Stay', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/663f72d87_generated_image.png', tags: ['Boutique', 'Under €250'] },
{ id: 'demo-brass', is_demo: true, name: 'Brass & Marble', address: 'Innenstadt 32', price: '€€€€', rating: 4.9, sub_category: 'Grand Hotel', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/4d8be7329_generated_image.png', tags: ['5-star', 'With pool'] },
{ id: 'demo-canal', is_demo: true, name: 'Canal Hideaway', address: 'Lechkanal 2', price: '€€€', rating: 4.7, sub_category: 'Waterside Stay', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ea01b4cc1_generated_image.png', tags: ['Romantic', 'Old Town'] }];


export default function Stay() {
  const urlParams = new URLSearchParams(window.location.search);
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('');
  const [startDate, setStartDate] = useState(urlParams.get('start_date') || '');
  const [endDate, setEndDate] = useState(urlParams.get('end_date') || '');
  const [people, setPeople] = useState(Number(urlParams.get('people')) || 2);
  const [parallaxY, setParallaxY] = useState(0);
  const [compactProgress, setCompactProgress] = useState(0);
  const [showFilterSheet, setShowFilterSheet] = useState(false);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [view, setView] = useState('list');

  useEffect(() => {
    listContentByType('stay', '-avg_rating', 20).
    then((v) => {setVenues(v || []);setLoading(false);}).
    catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    let frame = null;
    const update = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        setParallaxY(window.innerWidth >= 768 ? scrollY : 0);
        setCompactProgress(window.innerWidth >= 768 ? Math.min(1, Math.max(0, scrollY / 260)) : 0);
        frame = null;
      });
    };
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    return () => {
      window.removeEventListener('scroll', update);
      window.removeEventListener('resize', update);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const advancedCount = filters.cuisines.length + filters.vibes.length + filters.prices.length + (filters.openNow ? 1 : 0) + (filters.withDeals ? 1 : 0);
  const priceLevel = (hotel) => hotel.price_range || String(hotel.price || '').length || 3;
  const hotels = venues;
  const filtered = hotels.filter((hotel) => {
    const query = search.toLowerCase();
    const tags = [...(hotel.tags || []), ...(hotel.amenities || []), hotel.sub_category, hotel.neighborhood].filter(Boolean);
    if (search && !hotel.name.toLowerCase().includes(query) && !(hotel.address || hotel.neighborhood || '').toLowerCase().includes(query)) return false;
    if (activeFilter && !tags.includes(activeFilter)) return false;
    if (filters.cuisines.length && !filters.cuisines.some((item) => tags.includes(item))) return false;
    if (filters.vibes.length && !filters.vibes.some((item) => tags.includes(item))) return false;
    if (filters.prices.length && !filters.prices.includes(priceLevel(hotel))) return false;
    if (filters.openNow && Number(hotel.avg_rating || hotel.rating || 0) < 4.6) return false;
    if (filters.withDeals && priceLevel(hotel) > 2) return false;
    return true;
  }).sort((a, b) => {
    if (filters.sort === 'price_low') return priceLevel(a) - priceLevel(b);
    if (filters.sort === 'price_high') return priceLevel(b) - priceLevel(a);
    if (filters.sort === 'trending') return Number(b.avg_rating || b.rating || 0) + priceLevel(a) / 10 - (Number(a.avg_rating || a.rating || 0) + priceLevel(b) / 10);
    return Number(b.avg_rating || b.rating || 0) - Number(a.avg_rating || a.rating || 0);
  });

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      <section className="relative overflow-visible px-5 pt-16 pb-8 md:px-8 md:pt-24">
        <div className="absolute inset-0 pointer-events-none opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)', maskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)' }} />
        <div className="relative mx-auto max-w-7xl">
          <div className="mx-auto mb-8 max-w-7xl text-center">
            <h1 className="[font-family:'Libre_Baskerville',_serif] text-[55px] font-normal leading-[0.92] tracking-[-0.06em] text-roam-text">Stay In Style</h1>
            <p className="mx-auto mt-6 max-w-xl font-inter text-sm leading-7 text-roam-secondary md:text-sm">Browse polished hotel stays, boutique rooms, and rooftop escapes styled like the dining guide.</p>
          </div>

          <div className="planner-filter-shell sticky top-24 z-[10000] mx-auto w-full transition-all duration-300 ease-out md:static lg:sticky lg:w-auto" style={{ width: window.innerWidth >= 768 && window.innerWidth < 1024 ? undefined : `${100 - compactProgress * 28}%` }}>
            <div className="rounded-full border border-white/70 bg-white p-1.5 shadow-[0_8px_22px_rgba(0,0,0,0.10),inset_0_1px_0_rgba(255,255,255,0.65)] backdrop-blur-[20px] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(0,0,0,0.14),inset_0_1px_0_rgba(255,255,255,0.75)]">
              <div className="flex min-w-0 flex-col gap-3 md:flex-row md:flex-nowrap md:items-center md:justify-between">
                <div className="flex min-h-[54px] min-w-0 flex-1 items-center gap-3 rounded-full border border-black/5 bg-[#F8F7F4]/55 px-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:border-[#571AFF]/30 hover:bg-[#F8F7F4] hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.85)]">
                  <Search size={18} color="#888580" />
                  <input type="text" placeholder="Search hotels, neighborhoods, vibes..." value={search} onChange={(e) => setSearch(e.target.value)} className="min-w-0 flex-1 bg-transparent font-inter text-sm outline-none" style={{ color: '#141413' }} />
                  {search && <button type="button" onClick={() => setSearch('')} aria-label="Clear search" className="flex h-7 w-7 items-center justify-center rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-[0_8px_18px_rgba(14,14,14,0.12)]" style={{ background: '#FFFFFF' }}><X size={13} color="#72706A" /></button>}
                </div>
                <PlannerInternalFilters startDate={startDate} endDate={endDate} people={people} onStartDateChange={setStartDate} onEndDateChange={setEndDate} onPeopleChange={setPeople} />
                <div className="flex shrink-0 items-center gap-2">
                  <button type="button" onClick={() => setShowFilterSheet(true)} aria-label="Open hotel filters" className={`relative flex h-12 w-12 items-center justify-center rounded-full border border-black/5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:scale-105 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.24)] ${advancedCount > 0 ? 'bg-[#571AFF] text-white' : 'bg-[#F8F7F4]/55 text-[#141413]'}`}>
                    <SlidersHorizontal size={18} color="currentColor" />
                    {advancedCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full px-1 font-inter text-[12px] font-bold text-white" style={{ background: '#0E0E0E', border: '2px solid #FFFFFF' }}>{advancedCount}</span>}
                  </button>
                  <button type="button" aria-label={view === 'map' ? 'Show hotel list' : 'Show hotel map'} onClick={() => setView(view === 'map' ? 'list' : 'map')} className={`flex h-12 w-12 items-center justify-center rounded-full border border-black/5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:scale-105 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.24)] ${view === 'map' ? 'bg-[#571AFF] text-white' : 'bg-[#F8F7F4]/55 text-[#141413]'}`}>{view === 'map' ? <List size={18} color="currentColor" /> : <Map size={18} color="currentColor" />}</button>
                </div>
              </div>
            </div>
          </div>

          <div className="-mx-5 mt-5 flex gap-2 overflow-x-auto px-5 pb-1 scrollbar-hide md:ml-0 md:mr-[-0.5rem] md:max-w-7xl md:justify-start md:pl-0 md:pr-8 lg:mx-auto lg:mr-auto lg:justify-center lg:pr-0">
            {FILTERS.map((filter) =>
            <button key={filter} onClick={() => setActiveFilter(activeFilter === filter ? '' : filter)} className={`flex-shrink-0 rounded-full px-4 py-2.5 font-inter text-xs font-semibold transition-colors hover:bg-[#571AFF] hover:text-white md:px-3 lg:px-4 ${activeFilter === filter ? 'bg-[#571AFF] text-white' : 'bg-white text-[#555550]'}`} style={{ border: '1px solid rgba(14,14,14,0.08)' }}>{filter}</button>
            )}
          </div>
        </div>
      </section>

      {view === 'map' ? <RestaurantMapView restaurants={filtered} loading={loading} category="stay" label="hotels" pathPrefix="/place" /> :
      <section className="px-5 md:px-8">
        <div className="mx-auto grid max-w-7xl gap-5 md:grid-cols-2 lg:grid-cols-3">
          {loading ? [0, 1, 2].map((i) => <SkeletonCard key={i} />) : filtered.length === 0 ?
          <div className="rounded-[28px] bg-white py-16 text-center md:col-span-2 lg:col-span-3" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
              
              <p className="mt-3 text-xl text-roam-text [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]">No hotels found</p>
              <p className="mt-1 font-inter text-sm text-roam-muted">Try widening your search</p>
            </div> :
          filtered.map((hotel, index) => {
            const isCenterColumn = index % 3 === 1;
            const isTablet = window.innerWidth >= 768 && window.innerWidth < 1024;
            const offset = isTablet ? 0 : -parallaxY * (isCenterColumn ? 0.006 : 0.07);
            return (
              <div key={hotel.id} className="will-change-transform" style={{ transform: `translateY(${offset}px)` }}>
                  <HotelShowcaseCard hotel={hotel} />
                </div>);

          })}
        </div>
      </section>
      }

      {showFilterSheet && <EatFilterSheet category="stay" initial={filters} onApply={setFilters} onClose={() => setShowFilterSheet(false)} />}
    </div>);

}