import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle2, Loader2, XCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useCart } from '@/lib/CartContext';

/**
 * PayPal return page. After the buyer approves payment on PayPal,
 * they're redirected here with ?token=ORDER_ID. We capture the order
 * server-side and show a success/failure state.
 */
export default function PaypalReturn() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { clear } = useCart();
  const [status, setStatus] = useState('loading'); // loading | success | error
  const [message, setMessage] = useState('');

  useEffect(() => {
    const orderId = params.get('token');
    const bookingRaw = sessionStorage.getItem('pendingBooking');
    if (!orderId) {
      setStatus('error');
      setMessage('No se recibió el ID de la orden de PayPal.');
      return;
    }
    const booking = bookingRaw ? JSON.parse(bookingRaw) : null;

    base44.functions.invoke('paypalCaptureOrder', { orderId, booking })
      .then((res) => {
        const data = res.data;
        if (data?.status === 'COMPLETED') {
          setStatus('success');
          sessionStorage.removeItem('pendingBooking');
          clear();
        } else {
          setStatus('error');
          setMessage(`Estado del pago: ${data?.status || 'desconocido'}`);
        }
      })
      .catch((e) => {
        setStatus('error');
        setMessage(e?.response?.data?.error || e?.message || 'No se pudo confirmar el pago.');
      });
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ background: '#F8F7F4' }}>
      <div className="text-center max-w-sm w-full">
        {status === 'loading' && (
          <>
            <Loader2 size={48} className="mx-auto mb-4 animate-spin" color="#141413" />
            <h1 className="font-poppins font-bold mb-2" style={{ fontSize: '22px', color: '#141413' }}>Confirmando tu pago…</h1>
            <p className="font-inter" style={{ fontSize: '14px', color: '#72706A' }}>Estamos procesando tu pago con PayPal.</p>
          </>
        )}
        {status === 'success' && (
          <>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#E8FBE9' }}>
              <CheckCircle2 size={36} color="#2A6B3A" />
            </div>
            <h1 className="font-poppins font-bold mb-2" style={{ fontSize: '22px', color: '#141413' }}>¡Pago confirmado!</h1>
            <p className="font-inter mb-6" style={{ fontSize: '14px', color: '#72706A' }}>Tu reserva quedó confirmada. Te enviamos el comprobante por correo.</p>
            <button onClick={() => navigate('/')} className="btn-primary">Volver al inicio</button>
          </>
        )}
        {status === 'error' && (
          <>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#FBE9E8' }}>
              <XCircle size={36} color="#8A2820" />
            </div>
            <h1 className="font-poppins font-bold mb-2" style={{ fontSize: '22px', color: '#141413' }}>No se pudo confirmar</h1>
            <p className="font-inter mb-6" style={{ fontSize: '14px', color: '#72706A' }}>{message || 'Ocurrió un error al procesar el pago.'}</p>
            <button onClick={() => navigate('/')} className="btn-primary">Volver al inicio</button>
          </>
        )}
      </div>
    </div>
  );
}