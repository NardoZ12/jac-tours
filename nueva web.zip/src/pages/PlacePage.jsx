import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { ArrowLeft, CalendarDays, MapPin, Star } from 'lucide-react';
import { findContentById } from '@/lib/contentTables';
import HeartButton from '@/components/ui/HeartButton';
import PlaceBookingForm from '@/components/booking/PlaceBookingForm';
import VenueGallery from '@/components/ui/VenueGallery';

const metaByCategory = {
  eat: { label: 'Eat', backPath: '/eat', cta: 'Browse restaurants' },
  stay: { label: 'Stay', backPath: '/stay', cta: 'Browse stays' },
  do: { label: 'Do', backPath: '/do', cta: 'Browse things to do' },
  restaurant: { label: 'Eat', backPath: '/eat', cta: 'Browse restaurants' },
  hotel: { label: 'Stay', backPath: '/stay', cta: 'Browse stays' },
  experience: { label: 'Do', backPath: '/do', cta: 'Browse things to do' },
  place: { label: 'Do', backPath: '/do', cta: 'Browse things to do' },
};

function normalizePlace(raw) {
  const category = raw?.category || raw?.venue_category || 'do';
  return {
    ...raw,
    id: raw?.id || raw?.venue_id,
    name: raw?.name || raw?.venue_name || 'Untitled place',
    category,
    cover_image_url: raw?.cover_image_url || raw?.image,
    avg_rating: Number(raw?.avg_rating || raw?.rating || 0),
    short_description: raw?.short_description || raw?.description || raw?.notes,
    location: raw?.neighborhood || raw?.address || raw?.city || 'Augsburg',
    priceLabel: raw?.price || raw?.price_label || (raw?.price_range ? '€'.repeat(raw.price_range) : ''),
    tags: raw?.cuisine_tags || raw?.highlights || raw?.amenities || raw?.vibe_tags || raw?.tags || [],
  };
}

export default function PlacePage() {
  const { id } = useParams();
  const location = useLocation();
  const [place, setPlace] = useState(() => location.state?.venue ? normalizePlace(location.state.venue) : null);
  const [loading, setLoading] = useState(!location.state?.venue);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      if (location.state?.venue) {
        setPlace(normalizePlace(location.state.venue));
        setLoading(false);
        return;
      }
      setLoading(true);
      const venue = await findContentById(id).catch(() => null);
      if (!alive) return;
      setPlace(venue ? normalizePlace(venue) : null);
      setLoading(false);
    };
    load();
    return () => { alive = false; };
  }, [id, location.state]);

  useEffect(() => {
    if (!loading && location.hash === '#book-now') {
      document.getElementById('book-now')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [loading, location.hash]);

  const meta = useMemo(() => metaByCategory[place?.category] || metaByCategory.do, [place?.category]);
  const heroImage = place?.cover_image_url || 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=80';

  if (loading) {
    return <div className="min-h-screen bg-[#F8F7F4] px-5 py-24"><div className="mx-auto h-[520px] max-w-5xl rounded-[32px] skeleton" /></div>;
  }

  if (!place) {
    return (
      <div className="min-h-screen bg-[#F8F7F4] px-5 py-24 text-center">
        <h1 className="[font-family:'Libre_Baskerville',_serif] text-[46px] font-normal tracking-[-0.05em] text-roam-text">Place not found</h1>
        <Link to="/do" className="mt-6 inline-flex h-11 items-center justify-center rounded-full bg-[#0E0E0E] px-6 font-inter text-sm font-semibold text-white">Back to Do</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      <section className="relative overflow-visible px-5 pt-4 md:px-8 md:pt-6">
        <div className="absolute inset-0 pointer-events-none opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)', maskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)' }} />
        <div className="relative mx-auto max-w-6xl">
          <Link to={meta.backPath} className="mb-6 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 font-inter text-sm font-semibold text-roam-text shadow-[0_8px_22px_rgba(14,14,14,0.08)]">
            <ArrowLeft size={16} /> Back
          </Link>

          <div className="overflow-hidden rounded-[36px] bg-white shadow-[0_24px_70px_rgba(14,14,14,0.12)]" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
            <div className="p-6 text-roam-text md:p-10">
              <p className="mb-3 font-inter text-xs font-semibold uppercase tracking-[0.18em] text-roam-muted">{meta.label}</p>
              <h1 className="max-w-3xl [font-family:'Libre_Baskerville',_serif] text-[50px] font-normal leading-[0.95] tracking-[-0.06em] text-roam-text md:text-[82px]">{place.name}</h1>
              <div className="mt-5 flex flex-wrap items-center gap-3 font-inter text-sm text-roam-secondary">
                <span className="inline-flex items-center gap-2"><MapPin size={16} />{place.location}</span>
                {place.priceLabel && <span>{place.priceLabel}</span>}
                {place.duration && <span className="inline-flex items-center gap-2"><CalendarDays size={16} />{place.duration}</span>}
              </div>
            </div>
            <div className="relative h-[260px] md:h-[420px] lg:h-[460px]">
              <img src={heroImage} alt={place.name} className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute left-5 top-5 z-10"><HeartButton venue={place} /></div>
              <div className="absolute right-5 top-5 flex items-center gap-1 rounded-full bg-white px-3 py-2 text-roam-text">
                <Star size={14} fill="#0E0E0E" />
                <span className="font-inter text-xs font-bold">{place.avg_rating ? place.avg_rating.toFixed(1) : 'New'}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="px-5 pt-8 md:px-8">
        <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <article className="rounded-[28px] bg-white p-6 md:p-8" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
            <h2 className="[font-family:'Libre_Baskerville',_serif] text-[34px] font-normal tracking-[-0.05em] text-roam-text">About this place</h2>
            <p className="mt-4 font-inter text-sm leading-7 text-roam-secondary">{place.short_description || `${place.name} is a curated ${meta.label.toLowerCase()} selected for calm planning, quick comparison, and easy discovery in Augsburg.`}</p>
            {place.tags.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2">
                {place.tags.slice(0, 8).map((tag) => <span key={tag} className="rounded-full bg-[#F2F1EE] px-3 py-1.5 font-inter text-xs font-semibold text-[#3A3A3A]">{tag}</span>)}
              </div>
            )}
            <VenueGallery venue={place} />
          </article>

          <aside id="book-now" className="scroll-mt-24 rounded-[28px] bg-white p-6 md:p-8" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
            <h3 className="font-inter text-lg font-semibold text-roam-text">Book Now</h3>
            <p className="mt-3 font-inter text-sm leading-6 text-roam-muted">Send your booking request for {place.name}.</p>
            <PlaceBookingForm placeName={place.name} category={place.category} />
          </aside>
        </div>
      </section>
    </div>
  );
}