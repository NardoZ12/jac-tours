import { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import FavouriteEatDoCard from '@/components/favourites/FavouriteEatDoCard';
import FavouriteHotelCard from '@/components/favourites/FavouriteHotelCard';

const pathFor = (place) => place.venue_id ? `/place/${place.venue_id}` : null;

export default function Favourites() {
  const [savedPlaces, setSavedPlaces] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSavedPlaces = async () => {
      const user = await base44.auth.me().catch(() => null);
      if (!user) {
        setSavedPlaces([]);
        setLoading(false);
        return;
      }
      const [byUserId, byCreator] = await Promise.all([
        base44.entities.SavedPlace.filter({ user_id: user.id }, '-created_date', 60),
        base44.entities.SavedPlace.filter({ created_by_id: user.id }, '-created_date', 60)
      ]);
      const uniqueItems = [...byUserId, ...byCreator].filter((item, index, items) => items.findIndex((saved) => saved.id === item.id) === index);
      setSavedPlaces(uniqueItems);
      setLoading(false);
    };
    loadSavedPlaces();
  }, []);

  const removeFromList = (placeId) => setSavedPlaces((items) => items.filter((item) => item.id !== placeId));
  const isEmpty = !loading && savedPlaces.length === 0;
  const favouriteSections = [
    { title: 'Restaurants', items: savedPlaces.filter((place) => ['eat', 'restaurant'].includes(place.venue_category)) },
    { title: 'Hotels', items: savedPlaces.filter((place) => ['stay', 'hotel'].includes(place.venue_category)) },
    { title: 'Sights', items: savedPlaces.filter((place) => ['do', 'experience'].includes(place.venue_category)) }
  ].filter((section) => section.items.length > 0);

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      <section className="relative overflow-hidden px-5 pt-16 pb-8 md:px-8 md:pt-24">
        <div className="absolute inset-0 pointer-events-none opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)', maskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)' }} />
        <div className="relative mx-auto max-w-7xl text-center">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-[0_12px_28px_rgba(14,14,14,0.08)]"><Heart size={24} fill="#0E0E0E" /></div>
          <h1 className="[font-family:'Libre_Baskerville',_serif] text-[55px] font-normal leading-[0.92] tracking-[-0.06em] text-roam-text">Favourites</h1>
          <p className="mx-auto mt-6 max-w-xl font-inter text-sm leading-7 text-roam-secondary md:text-sm">All saved restaurants, hotels, and places in one calm collection.</p>
        </div>
      </section>

      <section className="px-5 md:px-8">
        <div className="mx-auto flex max-w-[1120px] flex-wrap justify-center gap-5">
          {loading ? [0, 1, 2].map((item) => <div key={item} className="h-[460px] w-full max-w-[360px] flex-[1_1_300px] rounded-[28px] skeleton" />) : isEmpty ? (
            <div className="w-full max-w-xl rounded-[28px] bg-white py-16 text-center font-inter" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#F8F7F4] text-roam-text">
                <Heart size={28} strokeWidth={1.8} />
              </div>
              <p className="mt-3 font-inter text-xl font-semibold text-roam-text">No favourites yet</p>
              <p className="mt-1 font-inter text-sm text-roam-muted">Tap a heart on any restaurant, hotel, or place card to save it here.</p>
            </div>
          ) : favouriteSections.map((section) => (
            <div key={section.title} className="w-full">
              <h2 className="mb-4 text-center font-inter text-2xl font-semibold tracking-[-0.04em] text-roam-text">{section.title}</h2>
              <div className="mx-auto flex max-w-[1120px] flex-wrap justify-center gap-5">
                {section.items.map((place) => {
                  const venue = { id: place.venue_id, name: place.venue_name, category: place.venue_category, cover_image_url: place.cover_image_url, neighborhood: place.neighborhood, address: place.address, price_range: place.price_range, avg_rating: place.avg_rating, short_description: place.short_description };
                  const path = pathFor(place);
                  const Card = ['stay', 'hotel'].includes(place.venue_category) ? FavouriteHotelCard : FavouriteEatDoCard;
                  return <Card key={place.id} place={place} venue={venue} path={path} onRemove={removeFromList} />;
                })}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}