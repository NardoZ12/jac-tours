import { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, List, Map, X } from 'lucide-react';
import { listContentByType } from '@/lib/contentTables';
import SkeletonCard from '@/components/ui/SkeletonCard';
import EatFilterSheet from '@/components/eat/EatFilterSheet';
import RestaurantShowcaseCard from '@/components/eat/RestaurantShowcaseCard';
import RestaurantMapView from '@/components/eat/RestaurantMapView';
import PlannerInternalFilters from '@/components/trip/PlannerInternalFilters';
import CategorySelector from '@/components/eat/CategorySelector';

const FILTERS = ['Open now', 'Near me', 'Under €100', 'Trending', 'Outdoor', 'Romantic', 'French', 'Japanese', 'Bavarian', 'Mediterranean', 'Vegan'];
const DEFAULT_FILTERS = { cuisines: [], vibes: [], prices: [], openNow: false, withDeals: false, sort: 'rating' };
const WEEK_DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

const restaurantSeed = (restaurant) => String(restaurant.id || restaurant.name || '').split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);

const isRestaurantAvailableOnDate = (restaurant, isoDate) => {
  if (!isoDate) return true;
  if (restaurant.is_bookable === false) return false;

  const dayIndex = new Date(`${isoDate}T12:00:00`).getDay();
  const dayKey = WEEK_DAYS[dayIndex];
  const hours = restaurant.opening_hours;

  if (hours && typeof hours === 'object') {
    const dayHours = hours[dayKey] || hours[dayKey.slice(0, 3)] || hours[dayIndex];
    if (dayHours === false || String(dayHours).toLowerCase().includes('closed')) return false;
    if (dayHours) return true;
  }

  return (restaurantSeed(restaurant) + dayIndex) % 5 !== 0;
};

const isRestaurantAvailableForPeople = (restaurant, people) => {
  if (!people) return true;
  const minParty = restaurant.min_party || 1;
  const fallbackMaxParty = 4 + restaurantSeed(restaurant) % 5 + (restaurant.price_range || 1);
  const maxParty = restaurant.max_party || fallbackMaxParty;
  return people >= minParty && people <= maxParty;
};

const DEMO_RESTAURANTS = [
{ id: 'demo-lumen', is_demo: true, name: 'Lumen Dumpling Bar', category: 'eat', sub_category: 'Neo Asian Kitchen', neighborhood: 'Lech Quarter', price_range: 2, avg_rating: 4.8, review_count: 248, cuisine_tags: ['Japanese', 'Dumplings', 'Late Night'], vibe_tags: ['Trendy', 'Lively'], short_description: 'A moody lantern-lit counter serving silk dumplings, smoked broth, and crisp sake cocktails.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/2e3a7eec1_generated_image.png' },
{ id: 'demo-moss', is_demo: true, name: 'Moss & Marble', category: 'eat', sub_category: 'Modern Bavarian', neighborhood: 'Dom Viertel', price_range: 3, avg_rating: 4.9, review_count: 312, cuisine_tags: ['Bavarian', 'Seasonal', 'Wine'], vibe_tags: ['Romantic', 'Quiet'], short_description: 'An imaginary stone-walled dining room for alpine herbs, roasted roots, and candlelit Riesling flights.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/dc1a96e98_generated_image.png' },
{ id: 'demo-orbit', is_demo: true, name: 'Orbit Osteria', category: 'eat', sub_category: 'Future Italian', neighborhood: 'Maximilianstraße', price_range: 3, avg_rating: 4.7, review_count: 189, cuisine_tags: ['Italian', 'Pasta', 'Design'], vibe_tags: ['Trendy', 'Date night'], short_description: 'Handmade pasta, chrome details, and tableside tiramisu in a fictional space-age osteria.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/ae20de9c2_generated_image.png' },
{ id: 'demo-saffron', is_demo: true, name: 'Saffron Radio', category: 'eat', sub_category: 'Mediterranean Grill', neighborhood: 'Rathausplatz', price_range: 2, avg_rating: 4.6, review_count: 164, cuisine_tags: ['Mediterranean', 'Grill', 'Outdoor'], vibe_tags: ['Outdoor', 'Casual'], short_description: 'A sunny made-up terrace with charred flatbreads, citrus salads, and low-fi dinner playlists.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/2962474dc_generated_image.png' },
{ id: 'demo-velvet', is_demo: true, name: 'Velvet Turnip', category: 'eat', sub_category: 'Plant Bistro', neighborhood: 'Stadtmarkt', price_range: 2, avg_rating: 4.8, review_count: 221, cuisine_tags: ['Vegan', 'Botanical', 'Brunch'], vibe_tags: ['Family-friendly', 'Quiet'], short_description: 'A fictional plant-forward bistro with botanical plates, oat cream desserts, and soft morning light.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/407b8c466_generated_image.png' },
{ id: 'demo-ember', is_demo: true, name: 'Ember Atlas', category: 'eat', sub_category: 'Fire Kitchen', neighborhood: 'Fuggerei', price_range: 4, avg_rating: 4.9, review_count: 277, cuisine_tags: ['French', 'Grill', 'Chef Menu'], vibe_tags: ['Romantic', 'Lively'], short_description: 'A non-existent chef counter built around open flame, copper pans, and dramatic shared plates.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/5b8471798_generated_image.png' },
{ id: 'demo-celeste', is_demo: true, name: 'Celeste Noodle Club', category: 'eat', sub_category: 'Midnight Ramen', neighborhood: 'Jakobervorstadt', price_range: 2, avg_rating: 4.7, review_count: 198, cuisine_tags: ['Japanese', 'Ramen', 'Cocktails'], vibe_tags: ['Lively', 'Trendy'], short_description: 'A neon-blue imaginary noodle club with deep broth, vinyl records, and tiny late-night booths.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/661d64c65_generated_image.png' },
{ id: 'demo-botanica', is_demo: true, name: 'Botanica 17', category: 'eat', sub_category: 'Garden Supper Room', neighborhood: 'Pfersee', price_range: 3, avg_rating: 4.8, review_count: 254, cuisine_tags: ['Vegan', 'Seasonal', 'Natural Wine'], vibe_tags: ['Outdoor', 'Romantic'], short_description: 'A fictional greenhouse restaurant for herb ravioli, mineral wines, and long leafy dinners.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/539f8d6e9_generated_image.png' },
{ id: 'demo-noir', is_demo: true, name: 'Noir Canteen', category: 'eat', sub_category: 'French Night Café', neighborhood: 'Innenstadt', price_range: 2, avg_rating: 4.5, review_count: 143, cuisine_tags: ['French', 'Bistro', 'Brunch'], vibe_tags: ['Casual', 'Quiet'], short_description: 'A made-up black-and-cream café with onion tart, strong coffee, and soft jazz mornings.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/6aedcc060_generated_image.png' },
{ id: 'demo-porto', is_demo: true, name: 'Porto Fig', category: 'eat', sub_category: 'Coastal Plates', neighborhood: 'Oberhausen', price_range: 3, avg_rating: 4.6, review_count: 176, cuisine_tags: ['Mediterranean', 'Seafood', 'Tapas'], vibe_tags: ['Casual', 'Outdoor'], short_description: 'A fictional seaside-inspired spot for grilled fish, fig salads, and chilled vermouth.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/8cc78f26d_generated_image.png' },
{ id: 'demo-copper', is_demo: true, name: 'Copper Rye', category: 'eat', sub_category: 'Bavarian Bakery Grill', neighborhood: 'Kriegshaber', price_range: 2, avg_rating: 4.7, review_count: 209, cuisine_tags: ['Bavarian', 'Bakery', 'Grill'], vibe_tags: ['Family-friendly', 'Casual'], short_description: 'An imaginary bakery-meets-grill serving rye flatbreads, smoked butter, and roasted mushrooms.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/45bf35cba_generated_image.png' },
{ id: 'demo-rose', is_demo: true, name: 'Rose Circuit', category: 'eat', sub_category: 'Design Wine Bar', neighborhood: 'Haunstetten', price_range: 4, avg_rating: 4.9, review_count: 301, cuisine_tags: ['Italian', 'Wine', 'Small Plates'], vibe_tags: ['Date night', 'Trendy'], short_description: 'A non-existent glossy wine bar with rose marble counters, handmade gnocchi, and candle glow.', cover_image_url: 'https://media.base44.com/images/public/6a4501a5abb2150575abcf6b/57f986fff_generated_image.png' }];


export default function Eat() {
  const urlParams = new URLSearchParams(window.location.search);
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('');
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('list');
  const [showFilterSheet, setShowFilterSheet] = useState(false);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [parallaxY, setParallaxY] = useState(0);
  const [compactProgress, setCompactProgress] = useState(0);
  const [startDate, setStartDate] = useState(urlParams.get('start_date') || '');
  const [endDate, setEndDate] = useState(urlParams.get('end_date') || '');
  const [people, setPeople] = useState(Number(urlParams.get('people')) || 2);

  useEffect(() => {
    listContentByType('eat', '-avg_rating', 20).
    then((v) => {setVenues(v || []);setLoading(false);}).
    catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    let frame = null;
    const updateParallax = () => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        setParallaxY(window.innerWidth >= 768 ? scrollY : 0);
        setCompactProgress(window.innerWidth >= 768 ? Math.min(1, Math.max(0, scrollY / 260)) : 0);
        frame = null;
      });
    };
    updateParallax();
    window.addEventListener('scroll', updateParallax, { passive: true });
    window.addEventListener('resize', updateParallax);
    return () => {
      window.removeEventListener('scroll', updateParallax);
      window.removeEventListener('resize', updateParallax);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const advancedCount = filters.cuisines.length + filters.vibes.length + filters.prices.length + (filters.openNow ? 1 : 0) + (filters.withDeals ? 1 : 0);
  const restaurants = venues;
  const filtered = restaurants.filter((v) => {
    const query = search.toLowerCase();
    if (search && !v.name.toLowerCase().includes(query) && !v.sub_category?.toLowerCase().includes(query)) return false;
    if (['French', 'Japanese', 'Bavarian', 'Mediterranean', 'Vegan'].includes(activeFilter) && !v.cuisine_tags?.includes(activeFilter)) return false;
    if (['Outdoor', 'Romantic'].includes(activeFilter) && !v.vibe_tags?.includes(activeFilter)) return false;
    if (activeFilter === 'Under €100' && (v.price_range || 0) > 2) return false;
    if (filters.cuisines.length && !filters.cuisines.some((c) => v.cuisine_tags?.includes(c))) return false;
    if (filters.vibes.length && !filters.vibes.some((vibe) => v.vibe_tags?.includes(vibe))) return false;
    if (filters.prices.length && !filters.prices.includes(v.price_range)) return false;
    if (!isRestaurantAvailableOnDate(v, startDate)) return false;
    if (!isRestaurantAvailableForPeople(v, people)) return false;
    return true;
  }).sort((a, b) => {
    if (activeFilter === 'Open now') return a.name.localeCompare(b.name);
    if (activeFilter === 'Near me') return (a.neighborhood || '').localeCompare(b.neighborhood || '');
    if (activeFilter === 'Trending' || filters.sort === 'trending') return (b.review_count || 0) - (a.review_count || 0);
    if (filters.sort === 'price_low') return (a.price_range || 0) - (b.price_range || 0);
    if (filters.sort === 'price_high') return (b.price_range || 0) - (a.price_range || 0);
    return (b.avg_rating || 0) - (a.avg_rating || 0);
  });

  return (
    <div className="min-h-screen pb-24" style={{ background: '#F8F7F4' }}>
      <section className="relative overflow-visible px-5 pt-16 pb-8 md:px-8 md:pt-24">
        <div className="absolute inset-0 pointer-events-none opacity-40" style={{ backgroundImage: 'linear-gradient(rgba(20,20,19,0.055) 1px, transparent 1px), linear-gradient(90deg, rgba(20,20,19,0.055) 1px, transparent 1px)', backgroundSize: '18px 18px', WebkitMaskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)', maskImage: 'radial-gradient(ellipse at top, #000 0%, transparent 72%)' }} />
        <div className="relative mx-auto max-w-7xl">
          <div className="mx-auto mb-8 max-w-7xl text-center">
            <p className="mb-3 font-inter text-xs font-semibold uppercase tracking-[0.18em] hidden" style={{ color: '#571AFF' }}>Augsburg dining guide</p>
            <h1 className="[font-family:'Libre_Baskerville',_serif] text-[55px] font-normal leading-[0.92] tracking-[-0.06em] text-roam-text">Eat Well Tonight</h1>
            <p className="mx-auto mt-6 max-w-xl font-inter leading-7 text-roam-secondary text-sm md:text-sm">Browse real favorites and fictional restaurant concepts styled like the main page.</p>
          </div>

          <div className="mb-6 mt-2">
            <CategorySelector active="eat" />
          </div>

          <div className="planner-filter-shell sticky top-24 z-[10000] mx-auto w-full transition-all duration-300 ease-out md:static lg:sticky lg:w-auto" style={{ width: window.innerWidth >= 768 && window.innerWidth < 1024 ? undefined : `${100 - compactProgress * 28}%` }}>
            <div className="rounded-full border border-white/70 bg-white p-1.5 shadow-[0_8px_22px_rgba(0,0,0,0.10),inset_0_1px_0_rgba(255,255,255,0.65)] backdrop-blur-[20px] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(0,0,0,0.14),inset_0_1px_0_rgba(255,255,255,0.75)]">
              <div className="flex min-w-0 flex-col gap-3 md:flex-row md:flex-nowrap md:items-center md:justify-between">
                <div className="flex min-h-[54px] min-w-0 flex-1 items-center gap-3 rounded-full border border-black/5 bg-[#F8F7F4]/55 px-5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:border-[#571AFF]/30 hover:bg-[#F8F7F4] hover:shadow-[0_8px_20px_rgba(14,14,14,0.08),inset_0_1px_0_rgba(255,255,255,0.85)]">
                  <Search size={18} color="#888580" />
                  <input type="text" placeholder="Search restaurants, cuisines, vibes..." value={search} onChange={(e) => setSearch(e.target.value)} className="min-w-0 flex-1 bg-transparent font-inter text-sm outline-none" style={{ color: '#141413' }} />
                  {search && <button type="button" onClick={() => setSearch('')} aria-label="Clear search" className="flex h-7 w-7 items-center justify-center rounded-full transition-all duration-300 ease-out hover:scale-110 hover:shadow-[0_8px_18px_rgba(14,14,14,0.12)]" style={{ background: '#FFFFFF' }}><X size={13} color="#72706A" /></button>}
                </div>
                <PlannerInternalFilters startDate={startDate} endDate={endDate} people={people} onStartDateChange={setStartDate} onEndDateChange={setEndDate} onPeopleChange={setPeople} />
                <div className="flex shrink-0 items-center gap-2">
                  <button onClick={() => setShowFilterSheet(true)} aria-label="Open filters" className={`relative flex h-12 w-12 items-center justify-center rounded-full border border-black/5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:scale-105 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.24)] ${advancedCount > 0 ? 'bg-[#571AFF] text-white' : 'bg-[#F8F7F4]/55 text-[#141413]'}`}>
                    <SlidersHorizontal size={18} color="currentColor" />
                    {advancedCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full px-1 font-inter text-[12px] font-bold text-white" style={{ background: '#0E0E0E', border: '2px solid #FFFFFF' }}>{advancedCount}</span>}
                  </button>
                  <button type="button" aria-label={view === 'map' ? 'Show restaurant list' : 'Show restaurant map'} onClick={() => setView(view === 'map' ? 'list' : 'map')} className={`flex h-12 w-12 items-center justify-center rounded-full border border-black/5 shadow-[inset_0_1px_0_rgba(255,255,255,0.70)] transition-all duration-300 ease-out hover:-translate-y-0.5 hover:scale-105 hover:bg-[#0E0E0E] hover:text-white hover:shadow-[0_12px_28px_rgba(14,14,14,0.24)] ${view === 'map' ? 'bg-[#571AFF] text-white' : 'bg-[#F8F7F4]/55 text-[#141413]'}`}>{view === 'map' ? <List size={18} color="currentColor" /> : <Map size={18} color="currentColor" />}</button>
                </div>
              </div>
            </div>
          </div>

          <div className="-mx-5 mt-5 flex gap-2 overflow-x-auto px-5 pb-1 scrollbar-hide md:ml-0 md:mr-[-0.5rem] md:max-w-7xl md:justify-start md:pl-0 md:pr-8 lg:mx-auto lg:mr-auto lg:justify-center lg:pr-0">
            {FILTERS.map((f) =>
            <button key={f} onClick={() => setActiveFilter(activeFilter === f ? '' : f)} className={`flex-shrink-0 rounded-full px-4 py-2.5 font-inter text-xs font-semibold transition-colors hover:bg-[#571AFF] hover:text-white md:px-3 lg:px-4 ${activeFilter === f ? 'bg-[#571AFF] text-white' : 'bg-white text-[#555550]'}`} style={{ border: '1px solid rgba(14,14,14,0.08)' }}>{f}</button>
            )}
          </div>
        </div>
      </section>

      {view === 'map' ? <RestaurantMapView restaurants={filtered} loading={loading} /> :
      <section className="px-5 md:px-8">
        <div className="mx-auto grid max-w-7xl gap-5 md:grid-cols-2 lg:grid-cols-3">
          {loading ? [0, 1, 2].map((i) => <SkeletonCard key={i} />) : filtered.length === 0 ?
          <div className="rounded-[28px] bg-white py-16 text-center md:col-span-2 lg:col-span-3" style={{ border: '1px solid rgba(14,14,14,0.08)' }}>
              
              <p className="mt-3 text-xl text-roam-text [font-family:'Inter',_Helvetica_Neue,_Arial,_sans-serif]">No restaurants found</p>
              <p className="mt-1 font-inter text-sm text-roam-muted">{startDate ? 'Try another date or clear your date selection' : 'Try widening your search'}</p>
            </div> :
          filtered.map((v, index) => {
            const isCenterColumn = index % 3 === 1;
            const isTablet = window.innerWidth >= 768 && window.innerWidth < 1024;
            const offset = isTablet ? 0 : -parallaxY * (isCenterColumn ? 0.006 : 0.07);
            return (
              <div key={v.id} className="will-change-transform" style={{ transform: `translateY(${offset}px)` }}>
                <RestaurantShowcaseCard venue={v} />
              </div>);

          })}
        </div>
      </section>
      }

      {showFilterSheet && <EatFilterSheet initial={filters} onApply={setFilters} onClose={() => setShowFilterSheet(false)} />}
    </div>);

}