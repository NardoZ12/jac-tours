import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Heart, Share2, Wifi, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { findContentById } from '@/lib/contentTables';
import RatingStars from '@/components/ui/RatingStars';
import VenuePhoto from '@/components/ui/VenuePhoto';
import HotelBookingSheet from '@/components/stay/HotelBookingSheet';

const ROOM_TYPES = [
  { name: 'Standard Room', size: '25m²', bed: 'Queen bed', guests: 2, price: 450 },
  { name: 'Deluxe Room', size: '35m²', bed: 'King bed', guests: 2, price: 620 },
  { name: 'Junior Suite', size: '55m²', bed: 'King bed + sofa', guests: 3, price: 950 },
];

export default function HotelPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [venue, setVenue] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);
  const [showBooking, setShowBooking] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [photoIdx, setPhotoIdx] = useState(0);

  useEffect(() => {
    findContentById(id, 'stay').then(v => { setVenue(v); setLoading(false); }).catch(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="min-h-screen flex items-center justify-center" style={{ background: '#FAF9F5' }}><div className="skeleton w-full h-64" /></div>;
  if (!venue) return null;

  const pricePerNight = (venue.price_range || 2) * 250;

  return (
    <div className="pb-24" style={{ background: '#FAF9F5' }}>
      {/* Photo gallery */}
      <VenuePhoto venue={venue} height={260} rounded="0">
        <button onClick={() => navigate(-1)} className="absolute top-12 left-5 z-10 w-10 h-10 flex items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}>
          <ArrowLeft size={20} color="white" />
        </button>
        <div className="absolute top-12 right-5 z-10 flex gap-2">
          <button className="w-10 h-10 flex items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}>
            <Share2 size={18} color="white" />
          </button>
          <button onClick={() => setSaved(s => !s)} className="w-10 h-10 flex items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}>
            <Heart size={18} color="white" fill={saved ? 'white' : 'none'} />
          </button>
        </div>
        {/* Dots */}
        <div className="absolute bottom-3 left-0 right-0 z-10 flex justify-center gap-1.5">
          {[0,1,2,3].map(i => (
            <div key={i} className="rounded-full" style={{ width: i === photoIdx ? '16px' : '6px', height: '6px', background: i === photoIdx ? '#FFF' : 'rgba(255,255,255,0.5)', transition: 'all 0.3s' }} />
          ))}
        </div>
      </VenuePhoto>

      <div className="px-5 pt-4">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="font-poppins font-bold" style={{ fontSize: '22px', color: '#141413', letterSpacing: '-0.5px' }}>{venue.name}</h1>
            <div className="flex items-center gap-1 mt-1">
              <MapPin size={14} color="#72706A" />
              <p className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{venue.neighborhood} · {venue.city}</p>
            </div>
            <div className="mt-1.5">
              <RatingStars rating={venue.avg_rating} reviewCount={venue.review_count} />
            </div>
          </div>
          <div className="text-right">
            <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>€{pricePerNight}</span>
            <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>per night</p>
          </div>
        </div>

        {/* Amenities */}
        <div className="flex gap-4 mt-4 flex-wrap">
          {(venue.amenities || ['WiFi','Pool','Breakfast','Parking']).slice(0, 4).map(a => (
            <div key={a} className="flex items-center gap-1.5">
              <Wifi size={16} color="#2A6DB5" />
              <span className="font-inter" style={{ fontSize: '13px', color: '#72706A' }}>{a}</span>
            </div>
          ))}
        </div>

        {/* Room types */}
        <div className="mt-5">
          <h2 className="font-poppins font-semibold mb-3" style={{ fontSize: '16px', color: '#141413' }}>Room types</h2>
          <div className="space-y-3">
            {ROOM_TYPES.map(r => (
              <div
                key={r.name}
                className="rounded-2xl p-4 cursor-pointer"
                style={{
                  background: selectedRoom?.name === r.name ? '#141413' : '#FFF',
                  border: `1.5px solid ${selectedRoom?.name === r.name ? '#141413' : '#E8E6DC'}`,
                }}
                onClick={() => setSelectedRoom(r)}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-poppins font-semibold" style={{ fontSize: '14px', color: selectedRoom?.name === r.name ? '#FFF' : '#141413' }}>{r.name}</p>
                    <p className="font-inter" style={{ fontSize: '12px', color: selectedRoom?.name === r.name ? 'rgba(255,255,255,0.65)' : '#72706A' }}>{r.size} · {r.bed} · up to {r.guests} guests</p>
                  </div>
                  <span className="font-neue" style={{ fontSize: '13px', color: selectedRoom?.name === r.name ? '#FFFFFF' : '#72706A' }}>€{r.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Description */}
        <div className="mt-5">
          <h2 className="font-poppins font-semibold mb-2" style={{ fontSize: '16px', color: '#141413' }}>About</h2>
          <p className="font-inter" style={{ fontSize: '14px', color: '#141413', lineHeight: 1.6 }}>
            {venue.description || `${venue.name} is one of ${venue.city}'s most distinguished properties, offering exceptional hospitality in ${venue.neighborhood}.`}
          </p>
        </div>

        {/* Cancellation policy */}
        <div className="mt-4 p-3 rounded-xl" style={{ background: '#F0EFE9' }}>
          <p className="font-poppins font-semibold" style={{ fontSize: '13px', color: '#141413' }}>Free cancellation</p>
          <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>Cancel up to 48 hours before check-in for a full refund.</p>
        </div>

        {/* Book button */}
        <div className="flex gap-3 mt-5">
          <button
            onClick={() => setShowBooking(true)}
            className="flex-1 font-poppins font-semibold text-white"
            style={{ height: '48px', borderRadius: '12px', background: '#2A6DB5', fontSize: '14px' }}
          >
            Book now
          </button>
          <button
            onClick={() => setSaved(s => !s)}
            className="font-poppins font-semibold"
            style={{ height: '48px', padding: '0 20px', borderRadius: '12px', border: '1.5px solid #E8E6DC', fontSize: '14px', color: '#141413' }}
          >
            {saved ? '♥ Saved' : '♡ Save'}
          </button>
        </div>
      </div>

      {showBooking && (
        <HotelBookingSheet
          venue={venue}
          room={selectedRoom || ROOM_TYPES[0]}
          onClose={() => setShowBooking(false)}
        />
      )}
    </div>
  );
}