import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Heart, Share2, Clock, Users, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { findContentById } from '@/lib/contentTables';
import RatingStars from '@/components/ui/RatingStars';
import TourPhotoCarousel from '@/components/do/TourPhotoCarousel';
import ExperienceBookingSheet from '@/components/do/ExperienceBookingSheet';
import BuggyMachineSelector from '@/components/do/BuggyMachineSelector';
import TourInfoSections from '@/components/do/TourInfoSections';

const HIGHLIGHTS = ['Small group', 'Expert local guide', 'Equipment included', 'All skill levels', 'Memorable experience'];
const TRANSPORT_NOTE = ' · Incluye transporte ida y vuelta desde tu hotel.';

export default function ExperiencePage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [venue, setVenue] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);
  const [showBooking, setShowBooking] = useState(false);
  const [groupSize, setGroupSize] = useState(2);
  const [expanded, setExpanded] = useState(false);
  const [tier, setTier] = useState('regular');
  const [ticketIndex, setTicketIndex] = useState(0);
  const [machineSelection, setMachineSelection] = useState(null);

  useEffect(() => {
    findContentById(id, 'do').then(v => { setVenue(v); setLoading(false); }).catch(() => setLoading(false));
  }, [id]);

  // Private tier is only available for groups of 5 or more
  useEffect(() => {
    if (tier === 'private' && groupSize < 5) setTier('regular');
  }, [groupSize, tier]);

  // Clamp group size to the selected ticket tier's minimum when it changes
  useEffect(() => {
    if (!venue?.ticket_tiers) return;
    const t = venue.ticket_tiers[ticketIndex];
    const min = t?.min_party || 1;
    if (groupSize < min) setGroupSize(min);
  }, [ticketIndex, venue]);

  if (loading) return <div className="min-h-screen" style={{ background: '#FAF9F5' }}><div className="skeleton w-full" style={{ height: '260px' }} /></div>;
  if (!venue) return null;

  const privatePrice = venue.price || (venue.price_range || 2) * 80;
  const regularPrice = Math.round(privatePrice * 0.6);
  const privateAvailable = groupSize >= 5;
  const hasTicketTiers = Array.isArray(venue.ticket_tiers) && venue.ticket_tiers.length > 0;
  const machineMode = hasTicketTiers && venue.ticket_tiers.some((t) => t.capacity);
  const selectedTicket = hasTicketTiers ? venue.ticket_tiers[ticketIndex] : null;
  const tierMinParty = hasTicketTiers ? (selectedTicket.min_party || 1) : 1;
  const pricePerPerson = hasTicketTiers ? selectedTicket.price : (tier === 'private' ? privatePrice : regularPrice);
  const tierLabel = hasTicketTiers ? selectedTicket.name : (tier === 'private' ? 'Private' : 'Regular');
  const total = pricePerPerson * groupSize;

  return (
    <div className="pb-24" style={{ background: '#FAF9F5' }}>
      {/* Photo carousel */}
      <TourPhotoCarousel venue={venue} height={360}>
        <button onClick={() => navigate(-1)} className="absolute top-12 left-5 z-10 w-10 h-10 flex items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}>
          <ArrowLeft size={20} color="white" />
        </button>
        <div className="absolute top-12 right-5 z-10 flex gap-2">
          <button className="w-10 h-10 flex items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}>
            <Share2 size={18} color="white" />
          </button>
          <button onClick={() => setSaved(s => !s)} className="w-10 h-10 flex items-center justify-center rounded-full" style={{ background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(6px)' }}>
            <Heart size={18} color="white" fill={saved ? 'white' : 'none'} />
          </button>
        </div>
        <div className="absolute bottom-4 left-5 right-5 z-10">
          <h1 className="font-poppins font-bold text-white" style={{ fontSize: '22px' }}>{venue.name}</h1>
          <div className="flex items-center gap-3 mt-1">
            {venue.duration && (
              <div className="flex items-center gap-1">
                <Clock size={14} color="rgba(255,255,255,0.85)" />
                <span className="font-inter text-white" style={{ fontSize: '13px', opacity: 0.85 }}>{venue.duration}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Users size={14} color="rgba(255,255,255,0.85)" />
              <span className="font-inter text-white" style={{ fontSize: '13px', opacity: 0.85 }}>Up to {venue.max_party || 8}</span>
            </div>
          </div>
        </div>
      </TourPhotoCarousel>

      <div className="px-5 pt-4">
        <div className="flex items-start justify-between mb-3">
          <RatingStars rating={venue.avg_rating} reviewCount={venue.review_count} size={16} />
          <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>${pricePerPerson} <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>/ person</span></span>
        </div>

        {/* Description */}
        <div>
          <p className="font-inter" style={{ fontSize: '14px', color: '#141413', lineHeight: 1.6 }}>
            {expanded
              ? ((venue.description || `Experience the best of ${venue.sub_category} with an expert local guide. This ${venue.duration || '3 hour'} immersive experience will take you through ${venue.city}'s hidden gems.`) + TRANSPORT_NOTE)
              : ((venue.short_description || `Experience the best of ${venue.sub_category}...`) + TRANSPORT_NOTE)}
          </p>
          <button onClick={() => setExpanded(!expanded)} className="font-inter mt-1" style={{ fontSize: '13px', color: '#D97757' }}>
            {expanded ? 'Show less' : 'Read more'}
          </button>
        </div>

        {/* Highlights */}
        <div className="mt-4">
          <h2 className="font-poppins font-semibold mb-2" style={{ fontSize: '16px', color: '#141413' }}>Highlights</h2>
          <div className="space-y-2">
            {(venue.highlights?.length ? venue.highlights : HIGHLIGHTS).map(h => (
              <div key={h} className="flex items-center gap-2">
                <span style={{ fontSize: '16px' }}>✓</span>
                <span className="font-inter" style={{ fontSize: '14px', color: '#141413' }}>{h}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tier & price calculator */}
        {machineMode ? (
          <BuggyMachineSelector
            venue={venue}
            onCheckout={(sel) => { setMachineSelection(sel); setGroupSize(sel.people); setShowBooking(true); }}
          />
        ) : (
        <div className="mt-5 rounded-2xl p-4 card-shadow bg-white">
          <h2 className="font-poppins font-semibold mb-3" style={{ fontSize: '16px', color: '#141413' }}>Elige tu modalidad</h2>

          {hasTicketTiers ? (
            <div className="space-y-2 mb-4">
              {venue.ticket_tiers.map((t, i) => {
                const active = ticketIndex === i;
                return (
                  <button
                    key={i}
                    onClick={() => setTicketIndex(i)}
                    className="w-full rounded-2xl p-4 text-left transition-all flex items-center justify-between"
                    style={{ background: active ? '#141413' : '#F0EFE9', border: '2px solid ' + (active ? '#141413' : 'transparent') }}
                  >
                    <div className="flex-1">
                      <span className="font-poppins font-bold" style={{ fontSize: '14px', color: active ? '#FFFFFF' : '#141413' }}>{t.name}</span>
                      <p className="font-inter" style={{ fontSize: '11px', color: active ? 'rgba(255,255,255,0.7)' : '#72706A' }}>{t.description}</p>
                      <p className="font-poppins font-bold mt-1" style={{ fontSize: '16px', color: active ? '#FFFFFF' : '#141413' }}>USD ${t.price.toFixed(2)}<span style={{ fontSize: '11px', fontWeight: 400 }}></span></p>
                    </div>
                    <div className="w-9 h-9 rounded-full flex items-center justify-center ml-3 shrink-0" style={{ background: '#B6F02D' }}>
                      <span style={{ fontSize: '20px', color: '#141413', fontWeight: 700, lineHeight: 1 }}>+</span>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
          <div className="grid grid-cols-2 gap-3 mb-4">
            <button
              onClick={() => setTier('regular')}
              className="rounded-2xl p-4 text-left transition-all"
              style={{ background: tier === 'regular' ? '#141413' : '#F0EFE9', border: '2px solid ' + (tier === 'regular' ? '#141413' : 'transparent') }}>
              <div className="flex items-center gap-1 mb-1">
                <span style={{ fontSize: '15px' }}>👥</span>
                <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: tier === 'regular' ? '#FFFFFF' : '#141413' }}>Regular</span>
              </div>
              <p className="font-inter" style={{ fontSize: '11px', color: tier === 'regular' ? 'rgba(255,255,255,0.7)' : '#72706A' }}>Grupo compartido</p>
              <p className="font-poppins font-bold mt-1" style={{ fontSize: '15px', color: tier === 'regular' ? '#FFFFFF' : '#141413' }}>${regularPrice}<span style={{ fontSize: '11px', fontWeight: 400 }}> /pers</span></p>
            </button>
            <button
              onClick={() => privateAvailable && setTier('private')}
              disabled={!privateAvailable}
              className="rounded-2xl p-4 text-left transition-all"
              style={{ background: tier === 'private' ? '#141413' : '#F0EFE9', border: '2px solid ' + (tier === 'private' ? '#141413' : 'transparent'), opacity: privateAvailable ? 1 : 0.45, cursor: privateAvailable ? 'pointer' : 'not-allowed' }}>
              <div className="flex items-center gap-2 mb-1">
                <span style={{ fontSize: '16px' }}>🚐</span>
                <span className="font-poppins font-semibold" style={{ fontSize: '14px', color: tier === 'private' ? '#FFFFFF' : '#141413' }}>Private</span>
              </div>
              <p className="font-inter" style={{ fontSize: '11px', color: tier === 'private' ? 'rgba(255,255,255,0.7)' : '#72706A' }}>{privateAvailable ? 'Exclusivo para tu grupo' : 'Desde 5 personas'}</p>
              <p className="font-poppins font-bold mt-1" style={{ fontSize: '15px', color: tier === 'private' ? '#FFFFFF' : '#141413' }}>${privatePrice}<span style={{ fontSize: '11px', fontWeight: 400 }}> /persona</span></p>
            </button>
          </div>
          )}

          <div className="flex items-center justify-between mb-4">
            <span className="font-inter" style={{ fontSize: '14px', color: '#72706A' }}>Group size</span>
            <div className="flex items-center gap-4">
              <button onClick={() => setGroupSize(g => Math.max(tierMinParty, g - 1))} className="w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>-</button>
              <span className="font-poppins font-bold" style={{ fontSize: '16px' }}>{groupSize}</span>
              <button onClick={() => setGroupSize(g => Math.min(venue.max_party || 12, g + 1))} className="w-8 h-8 flex items-center justify-center rounded-full" style={{ background: '#F0EFE9' }}>+</button>
            </div>
          </div>
          <div className="flex items-center justify-between py-3" style={{ borderTop: '1px solid #E8E6DC' }}>
            <span className="font-poppins font-semibold" style={{ fontSize: '15px', color: '#141413' }}>Total</span>
            <span className="font-neue" style={{ fontSize: '13px', color: '#72706A' }}>${total}</span>
          </div>
          <button
            onClick={() => setShowBooking(true)}
            className="btn-primary mt-2"
          >
            Reservar {tierLabel}
          </button>
        </div>
        )}

        {/* Meeting point */}
        <div className="mt-4 p-3 rounded-xl" style={{ background: '#F0EFE9' }}>
          <div className="flex items-center gap-2">
            <MapPin size={16} color="#4A7A35" />
            <div>
              <p className="font-poppins font-semibold" style={{ fontSize: '13px', color: '#141413' }}>Meeting point</p>
              <p className="font-inter" style={{ fontSize: '12px', color: '#72706A' }}>{venue.address || `${venue.neighborhood}, ${venue.city}`}</p>
            </div>
          </div>
        </div>

        {/* Inclusions / Exclusions / What to bring / Important info */}
        <TourInfoSections venue={venue} />
      </div>

      {showBooking && (
        <ExperienceBookingSheet
          venue={venue}
          groupSize={groupSize}
          pricePerPerson={machineMode && machineSelection ? machineSelection.totalPrice / groupSize : pricePerPerson}
          totalPrice={machineMode && machineSelection ? machineSelection.totalPrice : undefined}
          priceNote={machineMode && machineSelection ? machineSelection.label : undefined}
          tier={machineMode && machineSelection ? machineSelection.label : tierLabel}
          onClose={() => setShowBooking(false)}
        />
      )}
    </div>
  );
}