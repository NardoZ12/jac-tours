import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import RoleSwitcher from '@/components/profile/RoleSwitcher';
import TripPlannerCard from '@/components/today/TripPlannerCard';
import ScrollRouteMap from '@/components/today/ScrollRouteMap';
import HighlightedTours from '@/components/today/HighlightedTours';
import PartnerLogos from '@/components/today/PartnerLogos';
import FloatingShape from '@/components/ui/FloatingShape';
import { listContentByType } from '@/lib/contentTables';

export default function Today() {
  const [user, setUser] = useState(null);
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [brief, setBrief] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [u, doItems] = await Promise.all([
          base44.auth.me().catch(() => null),
          listContentByType('do', '-avg_rating', 20),
        ]);
        setUser(u);
        setVenues(doItems || []);
      } catch {}
      setLoading(false);
    };
    load();
  }, []);

  useEffect(() => {
    if (loading) return;
    const city = user?.city || 'Punta Cana';
    const tourCount = venues.length || 12;
    const CACHE_KEY = 'jac_brief_cache_v1';
    const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || '{}');
    if (cached.date === new Date().toDateString() && cached.userId === user?.id && cached.text) {
      setBrief(cached.text);
      return;
    }
    base44.integrations.Core.InvokeLLM({
      prompt: `Eres Jac Tour and Transfers. Escribe UNA frase corta y atractiva (máx 15 palabras) en español para la pantalla de inicio. Ubicación: ${city}. ${tourCount} tours disponibles. Menciona la mejor oportunidad. Sin comillas, sin hashtags.`
    }).then((res) => {
      const text = typeof res === 'string' ? res : res?.text || `${city}: ${tourCount} tours disponibles hoy.`;
      setBrief(text);
      localStorage.setItem(CACHE_KEY, JSON.stringify({ date: new Date().toDateString(), userId: user?.id, text }));
    }).catch(() => {
      setBrief(`${city}: ${tourCount} tours disponibles hoy.`);
    });
  }, [loading, user, venues.length]);

  return (
    <div className="min-h-screen" style={{ background: '#F8F7F4' }}>
      {/* ── Hero ── */}
      <div className="today-hero-section relative w-full" style={{ minHeight: '100vh', overflow: 'hidden', marginTop: '-80px' }}>
        <div className="today-hero-bg absolute overflow-hidden" style={{ top: 'calc(-80px + 0.25vh)', left: '0', right: '0', height: 'calc(100vh + 72px)', borderRadius: '32px 32px 60% 60% / 32px 32px 80px 80px', background: 'linear-gradient(135deg, #0a1428 0%, #1a3a5c 50%, #2d6a8f 100%)' }}>
          <video
            className="today-hero-image"
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            src="https://media.base44.com/videos/public/6ac017d1ab58cd4458f90038/817962b73_vd-corto-2.mp4#t=0.1"
            style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center', display: 'block' }} />
          {/* Ambient floating blobs */}
          <FloatingShape style={{ position: 'absolute', top: '14%', left: '7%', width: '200px', height: '200px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(87,26,255,0.40), transparent 70%)', filter: 'blur(22px)', pointerEvents: 'none' }} duration={11} float={28} />
          <FloatingShape style={{ position: 'absolute', bottom: '18%', right: '9%', width: '240px', height: '240px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(45,212,191,0.32), transparent 70%)', filter: 'blur(26px)', pointerEvents: 'none' }} duration={13} delay={1.5} float={32} />
          <FloatingShape style={{ position: 'absolute', top: '42%', right: '28%', width: '130px', height: '130px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,0.20), transparent 70%)', filter: 'blur(16px)', pointerEvents: 'none' }} duration={9} delay={0.8} float={18} />
          {/* Shimmer sweep */}
          <motion.div
            style={{ position: 'absolute', inset: 0, background: 'linear-gradient(110deg, transparent 35%, rgba(255,255,255,0.10) 50%, transparent 65%)', backgroundSize: '200% 100%', pointerEvents: 'none' }}
            animate={{ backgroundPosition: ['100% 0%', '0% 0%'] }}
            transition={{ duration: 9, repeat: Infinity, ease: 'linear' }}
          />
        </div>

        {/* Top bar (mobile header buttons) */}
        <div className="relative z-10 flex items-center justify-between px-5 pt-12 pb-2 md:hidden" style={{ paddingTop: '80px' }}>
          <div />
          <div className="flex items-center gap-3">
            <div className="mobile-role-switcher-top">
              <RoleSwitcher user={user} onChange={setUser} />
            </div>
          </div>
        </div>

        {/* Hero title */}
        <div className="today-hero-content relative z-30 text-center px-6" style={{ marginTop: 'calc(5rem + 28vh)' }}>
          <motion.h1
            className="today-hero-title -translate-y-1.5 text-white font-normal [font-family:'Libre_Baskerville',_serif]"
            style={{
              fontSize: 'clamp(34px, 9vw, 96px)',
              lineHeight: 1.0,
              letterSpacing: '-0.05em',
              textShadow: '0 2px 24px rgba(0,0,0,0.35)'
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}>
            Jac Tour and Transfers
          </motion.h1>
          {brief && (
            <motion.p
              className="font-inter text-white/85"
              style={{ fontSize: '15px', maxWidth: '520px', margin: '16px auto 0' }}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7, ease: 'easeOut' }}>
              {brief}
            </motion.p>
          )}
          <motion.div
            className="mt-3"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.95, ease: [0.22, 1, 0.36, 1] }}>
            <TripPlannerCard />
          </motion.div>
        </div>
      </div>

      {/* ── Saona Route Map ── */}
      <div className="relative z-10">
        <ScrollRouteMap />
      </div>

      {/* ── Highlighted Tours ── */}
      <HighlightedTours />

      {/* ── Partner OTA logos ── */}
      <PartnerLogos />
    </div>
  );
}