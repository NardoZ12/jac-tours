import { Link } from 'react-router-dom';

export default function PrivacyPolicy() {
  return (
    <main className="min-h-screen px-6 py-20" style={{ background: '#F8F7F4' }}>
      <div className="mx-auto max-w-3xl">
        <Link to="/" className="font-inter text-sm text-[#8A8780] hover:text-[#141413]">← Back home</Link>
        <h1 className="mt-8 [font-family:'Libre_Baskerville',_serif] text-5xl font-normal tracking-[-0.05em] text-[#141413]">Privacy policy</h1>
        <div className="mt-8 space-y-6 font-inter text-sm leading-7 text-[#5F5C56]">
          <p>Roam uses account, booking, preference, and trip details to provide recommendations, reservations, itinerary planning, and local discovery features.</p>
          <p>We only use personal information to operate the service, improve the experience, communicate important updates, and keep bookings and trip activity organized.</p>
          <p>You can contact Roam through the app experience to request access, correction, or deletion of information connected to your account, where applicable.</p>
        </div>
      </div>
    </main>
  );
}