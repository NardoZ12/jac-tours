/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        goudy:    ['Libre Baskerville', 'serif'],
        neue:     ['Inter', 'sans-serif'],
        poppins:  ['Libre Baskerville', 'serif'],
        playfair: ['Libre Baskerville', 'serif'],
        serif:    ['Libre Baskerville', 'serif'],
        inter:    ['Inter', 'sans-serif'],
        sans:     ['Inter', 'sans-serif'],
      },
      colors: {
        /* Wander design tokens — black/white/gray UI, color only in Mood Sky */
        'roam-bg':        '#F8F7F4',
        'roam-surface':   '#FFFFFF',
        'roam-surface2':  '#F2F1EE',
        'roam-surface3':  '#ECEAE5',
        'roam-peach':     '#F2F1EE',
        'roam-border':    '#DDDBD5',
        'roam-divider':   '#E5E3DE',
        'roam-text':      '#0E0E0E',
        'roam-secondary': '#3A3A3A',
        'roam-muted':     '#888580',
        'roam-nav':       '#F8F7F4',
        'roam-coral':     '#0E0E0E',
        'roam-coral-soft':'#E8E7E3',
        'roam-eat':       '#0E0E0E',
        'roam-stay':      '#0E0E0E',
        'roam-do':        '#0E0E0E',
        'roam-today':     '#0E0E0E',
        'roam-accent':    '#0E0E0E',
        'roam-olive':     '#0E0E0E',
        'roam-olive-soft':'#E8E7E3',
        'roam-success':   '#2A6B3A',
        'roam-warning':   '#8A6020',
        'roam-error':     '#8A2820',
        /* Shadcn tokens */
        background:   'hsl(var(--background))',
        foreground:   'hsl(var(--foreground))',
        card: {
          DEFAULT:    'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        popover: {
          DEFAULT:    'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        primary: {
          DEFAULT:    'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT:    'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        muted: {
          DEFAULT:    'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT:    'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        destructive: {
          DEFAULT:    'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        border: 'hsl(var(--border))',
        input:  'hsl(var(--input))',
        ring:   'hsl(var(--ring))',
        chart: {
          '1': 'hsl(var(--chart-1))',
          '2': 'hsl(var(--chart-2))',
          '3': 'hsl(var(--chart-3))',
          '4': 'hsl(var(--chart-4))',
          '5': 'hsl(var(--chart-5))',
        },
        sidebar: {
          DEFAULT:            'hsl(var(--sidebar-background))',
          foreground:         'hsl(var(--sidebar-foreground))',
          primary:            'hsl(var(--sidebar-primary))',
          'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
          accent:             'hsl(var(--sidebar-accent))',
          'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
          border:             'hsl(var(--sidebar-border))',
          ring:               'hsl(var(--sidebar-ring))',
        },
      },
      borderRadius: {
        lg:   'var(--radius)',
        md:   'calc(var(--radius) - 2px)',
        sm:   'calc(var(--radius) - 4px)',
        '4xl': '2rem',
      },
      boxShadow: {
        'roam-soft':  '0 1px 2px rgba(20,20,19,0.04), 0 4px 16px rgba(20,20,19,0.05)',
        'roam-card':  '0 2px 6px rgba(20,20,19,0.04), 0 8px 24px rgba(255,120,73,0.06)',
        'roam-pop':   '0 8px 28px rgba(20,20,19,0.10), 0 2px 8px rgba(20,20,19,0.05)',
      },
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to:   { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to:   { height: '0' },
        },
        'fade-in-up': {
          '0%':   { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'scale-press': {
          '0%':   { transform: 'scale(1)' },
          '50%':  { transform: 'scale(0.96)' },
          '100%': { transform: 'scale(1)' },
        },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up':   'accordion-up 0.2s ease-out',
        'fade-in-up':     'fade-in-up 0.4s cubic-bezier(0.22, 1, 0.36, 1) both',
        'scale-press':    'scale-press 0.18s ease-out',
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
