import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';

const LOGO_URL = 'https://media.base44.com/images/public/6ac017d1ab58cd4458f90038/872b6c8a4_3.png';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const {
      confirmationCode, venueName, tier, dateLabel, timeLabel, partyLabel,
      pickupLabel, total, currency,
      customerName, customerPhone, customerEmail, flightNumber, luggageCount,
    } = body;

    const ownerEmail = secrets.get('NOTIFICATION_EMAIL');

    const rows = [
      ['Código', confirmationCode || '-'],
      ['Experiencia', venueName || '-'],
      ['Modalidad', tier || '-'],
      ['Fecha', dateLabel || '-'],
      ['Hora', timeLabel || '-'],
      ['Grupo', partyLabel || '-'],
      ['Recogida', pickupLabel || '-'],
      ['Nombre', customerName || '-'],
      ['Teléfono', customerPhone || '-'],
      ['Correo', customerEmail || '-'],
    ];
    if (flightNumber) rows.push(['Número de vuelo', flightNumber]);
    if (luggageCount !== '' && luggageCount != null) rows.push(['Equipaje', String(luggageCount)]);
    rows.push(['Total', `${currency === 'USD' ? '$' : '€'}${Number(total || 0).toLocaleString()}`]);

    const detailRows = rows.map(([k, v]) =>
      '<tr>' +
        '<td style="padding:10px 0;font-size:13px;color:#72706A;width:160px;vertical-align:top;border-bottom:1px solid #ECEAE5">' + k + '</td>' +
        '<td style="padding:10px 0;font-size:14px;color:#141413;vertical-align:top;border-bottom:1px solid #ECEAE5;font-weight:600">' + v + '</td>' +
      '</tr>'
    ).join('');

    const html =
      '<div style="font-family:Inter,Arial,sans-serif;max-width:520px;margin:0 auto;background:#FFFFFF">' +
      // Logo
      '<div style="text-align:center;padding:36px 24px 20px">' +
        `<img src="${LOGO_URL}" alt="Jac Tour and Transfers" style="height:48px;border-radius:10px" />` +
      '</div>' +
      // Title
      '<div style="padding:0 24px;text-align:center">' +
        '<h2 style="margin:0 0 6px;color:#141413;font-size:22px;font-weight:700;letter-spacing:-0.02em">¡Reserva confirmada!</h2>' +
        '<p style="margin:0;color:#888580;font-size:13px">Gracias por reservar con Jac Tour and Transfers.</p>' +
      '</div>' +
      // Details card
      '<div style="margin:24px;padding:0">' +
        '<table style="width:100%;border-collapse:collapse">' + detailRows + '</table>' +
      '</div>' +
      // Cancellation policy
      '<div style="margin:8px 24px 24px;padding:18px 20px;background:#F8F7F4;border:1px solid #ECEAE5;border-radius:14px">' +
        '<p style="margin:0 0 8px;color:#141413;font-size:13px;font-weight:700">Política de cancelación</p>' +
        '<p style="margin:0;color:#3A3A3A;font-size:12px;line-height:1.6">' +
          'La solicitud de reembolso se aprueba en su 100% si se realiza con al menos <strong>24 horas de anticipación</strong> al inicio del tour o servicio. ' +
          'Si faltan menos de 24 horas, no procede devolución alguna; solo se reembolsará el depósito o cantidad ya pagada cuando la solicitud cumpla el plazo de 24 horas.' +
        '</p>' +
      '</div>' +
      // Footer
      '<div style="padding:0 24px 32px;text-align:center">' +
        '<p style="margin:0;color:#888580;font-size:11px;line-height:1.6">Jac Tour and Transfers · Punta Cana, República Dominicana</p>' +
        '<p style="margin:6px 0 0;color:#BAB8B2;font-size:10px">Este correo es generado automáticamente. Si tienes dudas, contáctanos por WhatsApp.</p>' +
      '</div>' +
      '</div>';

    const subject = `Confirmación de reserva · ${confirmationCode || ''} · ${venueName || ''}`;

    // Send to customer
    if (customerEmail) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: customerEmail,
        subject,
        html,
        from_name: 'Jac Tour and Transfers',
      });
    }

    // Send to owner
    if (ownerEmail) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: ownerEmail,
        subject: `[Nueva reserva] ${subject}`,
        html,
        from_name: 'Jac Tour and Transfers',
      });
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}