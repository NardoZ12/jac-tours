import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { getAccessToken, PAYPAL_BASE } from '../../shared/paypal.ts';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { amount, description, returnUrl, cancelUrl, cardFields } = body;

    if (!amount || !description) {
      return Response.json({ error: 'amount and description are required' }, { status: 400 });
    }

    const origin = new URL(req.url).origin;
    const token = await getAccessToken();

    // cardFields = true → order paid with card data typed on our page (no PayPal account needed).
    // Otherwise → redirect flow to PayPal in guest mode.
    const paymentSource = cardFields
      ? { card: { attributes: { verification: { method: 'SCA_WHEN_REQUIRED' } } } }
      : {
          paypal: {
            experience_context: {
              brand_name: 'Jac Tour and Transfers',
              return_url: returnUrl || `${origin}/paypal/return`,
              cancel_url: cancelUrl || `${origin}/paypal/return`,
              user_action: 'PAY_NOW',
              landing_page: 'GUEST_CHECKOUT',
              shipping_preference: 'NO_SHIPPING',
            },
          },
        };

    const res = await fetch(`${PAYPAL_BASE}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [{
          amount: { currency_code: 'USD', value: Number(amount).toFixed(2) },
          description: String(description).slice(0, 127),
        }],
        payment_source: paymentSource,
      }),
    });

    const order = await res.json();
    if (!res.ok) {
      return Response.json({ error: order.message || 'PayPal order creation failed', details: order }, { status: 400 });
    }

    const approveUrl = order.links?.find((l) => l.rel === 'payer-action' || l.rel === 'approve')?.href;
    return Response.json({ orderId: order.id, approveUrl });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}