import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';
import { getAccessToken, PAYPAL_BASE } from '../../shared/paypal.ts';

/**
 * Captures a PayPal order after the buyer approves it on PayPal.
 * Called from the /paypal/return page with the order ID (token).
 * Sends the booking ticket email + WhatsApp notification on success.
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { orderId, booking } = body;

    if (!orderId) {
      return Response.json({ error: 'orderId is required' }, { status: 400 });
    }

    const token = await getAccessToken();

    const res = await fetch(`${PAYPAL_BASE}/v2/checkout/orders/${orderId}/capture`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    const capture = await res.json();
    if (!res.ok) {
      const declined = capture.details?.some((d) => d.issue === 'INSTRUMENT_DECLINED');
      const error = declined
        ? 'Tu tarjeta fue rechazada. Intenta con otra tarjeta.'
        : capture.message || 'PayPal capture failed';
      return Response.json({ error, details: capture }, { status: 400 });
    }

    const status = capture.status; // COMPLETED / PENDING / DECLINED
    const cardLast4 = capture.payment_source?.card?.last_digits;
    const payerEmail = capture.payer?.email_address || (cardLast4 ? `Tarjeta •••• ${cardLast4}` : '-');
    const amount = capture.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.value || '-';

    // Send booking ticket + WhatsApp only on successful capture
    if (status === 'COMPLETED' && booking) {
      void base44.asServiceRole.integrations.Core.SendEmail({
        to: booking.customerEmail,
        subject: `Confirmación de pago · ${booking.confirmationCode || ''} · ${booking.venueName || ''}`,
        html: buildPaymentEmail(booking, amount, payerEmail),
        from_name: 'Jac Tour and Transfers',
      }).catch(() => {});

      const ownerEmail = secrets.get('NOTIFICATION_EMAIL');
      if (ownerEmail) {
        void base44.asServiceRole.integrations.Core.SendEmail({
          to: ownerEmail,
          subject: `[Pago confirmado] ${booking.confirmationCode || ''} · ${booking.venueName || ''}`,
          html: buildPaymentEmail(booking, amount, payerEmail),
          from_name: 'Jac Tour and Transfers',
        }).catch(() => {});
      }

      void base44.asServiceRole.functions.invoke('sendBookingWhatsApp', booking).catch(() => {});
    }

    return Response.json({ ok: true, status, amount, payerEmail, orderId });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function buildPaymentEmail(booking, amount, payerEmail) {
  const rows = [
    ['Código', booking.confirmationCode || '-'],
    ['Experiencia', booking.venueName || '-'],
    ['Modalidad', booking.tier || '-'],
    ['Fecha', booking.dateLabel || '-'],
    ['Hora', booking.timeLabel || '-'],
    ['Grupo', booking.partyLabel || '-'],
    ['Recogida', booking.pickupLabel || '-'],
    ['Nombre', booking.customerName || '-'],
    ['Teléfono', booking.customerPhone || '-'],
    ['Correo', booking.customerEmail || '-'],
    ['Pagado', `$${amount} USD`],
    ['Método de pago', payerEmail],
  ];
  const detailRows = rows.map(([k, v]) =>
    '<tr><td style="padding:10px 0;font-size:13px;color:#72706A;width:160px;vertical-align:top;border-bottom:1px solid #ECEAE5">' + k + '</td>' +
    '<td style="padding:10px 0;font-size:14px;color:#141413;vertical-align:top;border-bottom:1px solid #ECEAE5;font-weight:600">' + v + '</td></tr>'
  ).join('');

  return '<div style="font-family:Inter,Arial,sans-serif;max-width:520px;margin:0 auto;background:#FFFFFF">' +
    '<div style="text-align:center;padding:36px 24px 20px"><h2 style="margin:0;color:#141413;font-size:22px;font-weight:700">¡Pago confirmado!</h2></div>' +
    '<div style="margin:24px"><table style="width:100%;border-collapse:collapse">' + detailRows + '</table></div>' +
    '<div style="margin:8px 24px 24px;padding:18px 20px;background:#F8F7F4;border:1px solid #ECEAE5;border-radius:14px">' +
    '<p style="margin:0 0 8px;color:#141413;font-size:13px;font-weight:700">Política de cancelación</p>' +
    '<p style="margin:0;color:#3A3A3A;font-size:12px;line-height:1.6">Reembolso del 100% si se solicita con al menos <strong>24 horas de anticipación</strong> al inicio del tour o servicio.</p></div>' +
    '<div style="padding:0 24px 32px;text-align:center"><p style="margin:0;color:#888580;font-size:11px">Jac Tour and Transfers · Punta Cana, República Dominicana</p></div></div>';
}