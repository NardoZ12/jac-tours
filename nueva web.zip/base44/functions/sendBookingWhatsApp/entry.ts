import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';

/**
 * Sends a WhatsApp notification (Meta Cloud API) to the business owner
 * with the full order detail when a cart reservation is confirmed.
 *
 * Required secrets (set in the app dashboard → Secrets):
 *   WHATSAPP_ACCESS_TOKEN     — permanent System User token (whatsapp_business_messaging)
 *   WHATSAPP_PHONE_NUMBER_ID  — sender phone number ID from Meta for Developers
 *   WHATSAPP_RECIPIENT_PHONE  — owner's WhatsApp number, intl format without '+'
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const {
      confirmationCode, venueName, tier, dateLabel, timeLabel, partyLabel,
      pickupLabel, total, currency,
      customerName, customerPhone, customerEmail,
      paymentOption, depositAmount, dueAtPickup, payNow, itemsList,
    } = body;

    const token = secrets.get('WHATSAPP_ACCESS_TOKEN');
    const phoneNumberId = secrets.get('WHATSAPP_PHONE_NUMBER_ID');
    const recipient = secrets.get('WHATSAPP_RECIPIENT_PHONE');

    if (!token || !phoneNumberId || !recipient) {
      return Response.json({ error: 'Faltan secretos de WhatsApp (WHATSAPP_ACCESS_TOKEN, WHATSAPP_PHONE_NUMBER_ID o WHATSAPP_RECIPIENT_PHONE). Configúralos en el panel.' }, { status: 500 });
    }

    const cur = currency === 'USD' ? '$' : '€';
    const lines = [
      '🎉 *Nueva reserva confirmada*',
      `Código: ${confirmationCode || '-'}`,
      '',
      `*Experiencia:* ${venueName || '-'}`,
      tier ? `*Modalidad:* ${tier}` : '',
      `*Fecha:* ${dateLabel || '-'}`,
      `*Hora:* ${timeLabel || '-'}`,
      `*Grupo:* ${partyLabel || '-'}`,
      pickupLabel ? `*Recogida:* ${pickupLabel}` : '',
      '',
      '*Cliente*',
      `Nombre: ${customerName || '-'}`,
      `Teléfono: ${customerPhone || '-'}`,
      customerEmail ? `Correo: ${customerEmail}` : '',
      '',
      '*Detalle del pedido*',
      itemsList || '-',
      '',
      `*Total:* ${cur}${Number(total || 0).toLocaleString()}`,
      paymentOption === 'deposit'
        ? `Pago ahora (30%): ${cur}${Number(depositAmount || 0).toLocaleString()}\nRestante al recoger: ${cur}${Number(dueAtPickup || 0).toLocaleString()}`
        : `Pagado: ${cur}${Number(payNow || 0).toLocaleString()}`,
    ].filter(Boolean).join('\n');

    const apiRes = await fetch(
      `https://graph.facebook.com/v20.0/${phoneNumberId}/messages`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: recipient,
          type: 'text',
          text: { body: lines },
        }),
      }
    );

    const data = await apiRes.json();
    if (!apiRes.ok) {
      return Response.json({ error: data?.error?.message || 'Error enviando WhatsApp' }, { status: 502 });
    }

    return Response.json({ ok: true, messageId: data?.messages?.[0]?.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}