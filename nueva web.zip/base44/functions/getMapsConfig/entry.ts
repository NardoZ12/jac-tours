import { secrets } from 'base44:runtime';

export default async function(req) {
  try {
    const apiKey = secrets.get('GOOGLE_MAPS_API_KEY');
    return Response.json({ google_maps_api_key: apiKey || '' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}