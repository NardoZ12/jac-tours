import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { type, yacht, embark, date, time, guests, extras, source } = body;

    const recipient = secrets.get('NOTIFICATION_EMAIL');
    if (!recipient) {
      return Response.json({ error: 'NOTIFICATION_EMAIL not configured' }, { status: 500 });
    }

    const extrasList = Array.isArray(extras) ? extras : [];
    const rows = [
      ['Tipo', type || 'Yate'],
      ['Yate / Servicio', yacht || '-'],
      ['Embarque', embark || '-'],
      ['Fecha', date || 'Por definir'],
      ['Hora', time || '-'],
      ['Invitados', guests != null ? String(guests) : '-'],
    ];
    if (extrasList.length) rows.push(['Extras', extrasList.join(', ')]);

    const html =
      '<div style="font-family:Inter,Arial,sans-serif;max-width:520px">' +
      '<h2 style="margin:0 0 16px;color:#141413">Nueva solicitud de cotización 📩</h2>' +
      '<table style="width:100%;border-collapse:collapse;font-size:14px;color:#3A3A3A">' +
      rows.map(([k, v]) =>
        '<tr><td style="padding:6px 0;font-weight:600;color:#141413;width:160px;vertical-align:top">' + k + '</td>' +
        '<td style="padding:6px 0">' + v + '</td></tr>'
      ).join('') +
      '</table>' +
      '<p style="margin-top:18px;color:#888;font-size:12px">Enviado desde: ' + (source || 'Yates') + '</p>' +
      '</div>';

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: recipient,
      subject: 'Nueva cotización - ' + (yacht || type || 'Yate'),
      html,
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}