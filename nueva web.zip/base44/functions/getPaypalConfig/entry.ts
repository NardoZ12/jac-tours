import { secrets } from 'base44:runtime';

/** Returns the public PayPal client ID needed to load the card fields on the page. */
export default async function(req) {
  try {
    return Response.json({ clientId: secrets.get('PAYPAL_CLIENT_ID') || '' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}