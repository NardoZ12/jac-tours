import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';
import { getAccessToken, PAYPAL_BASE } from '../../shared/paypal.ts';

export default async function(req) {
  try {
    const rawBody = await req.text();
    const webhookId = secrets.get('PAYPAL_WEBHOOK_ID');

    if (!webhookId) {
      return Response.json({ error: 'PAYPAL_WEBHOOK_ID not configured' }, { status: 500 });
    }

    const headers = req.headers;
    const token = await getAccessToken();

    // Verify webhook signature with PayPal
    const verifyRes = await fetch(`${PAYPAL_BASE}/v1/notifications/verify-webhook-signature`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        auth_algo: headers.get('paypal-auth-algo'),
        cert_url: headers.get('paypal-cert-url'),
        transmission_id: headers.get('paypal-transmission-id'),
        transmission_sig: headers.get('paypal-transmission-sig'),
        transmission_time: headers.get('paypal-transmission-time'),
        webhook_id: webhookId,
        webhook_event: JSON.parse(rawBody),
      }),
    });

    const verification = await verifyRes.json();
    if (verification.verification_status !== 'SUCCESS') {
      return Response.json({ error: 'Invalid webhook signature' }, { status: 401 });
    }

    const event = JSON.parse(rawBody);
    const resource = event.resource || {};

    // Notify the admin of every verified PayPal event
    const base44 = createClientFromRequest(req);
    const recipient = secrets.get('NOTIFICATION_EMAIL');
    if (recipient) {
      const amount = resource.amount?.value || resource.gross_amount?.value || '-';
      const currency = resource.amount?.currency_code || resource.gross_amount?.currency_code || '';
      const payerEmail = resource.payer?.email_address || resource.payer_info?.email_address || '-';
      const orderId = resource.id || resource.supplementary?.related_ids?.order_id || '-';

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: recipient,
        subject: `PayPal · ${event.event_type}`,
        html:
          '<div style="font-family:Inter,Arial,sans-serif;max-width:520px">' +
          '<h2 style="margin:0 0 12px;color:#141413">Notificación de PayPal 💳</h2>' +
          '<table style="width:100%;border-collapse:collapse;font-size:14px;color:#3A3A3A">' +
          `<tr><td style="padding:6px 0;font-weight:600;color:#141413;width:140px">Evento</td><td style="padding:6px 0">${event.event_type || '-'}</td></tr>` +
          `<tr><td style="padding:6px 0;font-weight:600;color:#141413">Orden ID</td><td style="padding:6px 0">${orderId}</td></tr>` +
          `<tr><td style="padding:6px 0;font-weight:600;color:#141413">Monto</td><td style="padding:6px 0">${amount} ${currency}</td></tr>` +
          `<tr><td style="padding:6px 0;font-weight:600;color:#141413">Pagador</td><td style="padding:6px 0">${payerEmail}</td></tr>` +
          '</table></div>',
      });
    }

    return Response.json({ ok: true, eventType: event.event_type });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}